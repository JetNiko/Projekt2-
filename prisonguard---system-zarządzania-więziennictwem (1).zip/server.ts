import express from 'express';
import { createServer as createViteServer } from 'vite';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import db from './src/db.js';
import dotenv from 'dotenv';
import path from 'path';

dotenv.config();

const JWT_SECRET = process.env.JWT_SECRET || 'prison-guard-secret-key-2026';

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '50mb' }));

  // Seed Admin User if not exists
  try {
    const adminExists = db.prepare('SELECT * FROM users WHERE username = ?').get('admin');
    if (!adminExists) {
      console.log('Tworzenie konta administratora...');
      const hashedPassword = await bcrypt.hash('admin123', 10);
      const adminRole = db.prepare('SELECT id FROM roles WHERE name = ?').get('Admin') as { id: number } | undefined;
      
      if (!adminRole) {
        console.error('BŁĄD: Rola "Admin" nie istnieje w bazie danych!');
        // Spróbujmy pobrać jakąkolwiek rolę jako fallback lub rzućmy błąd
        throw new Error('Rola Admin nie została znaleziona. Upewnij się, że baza danych została poprawnie zainicjalizowana.');
      }

      const result = db.prepare('INSERT INTO users (username, password, full_name, role_id, badge_number) VALUES (?, ?, ?, ?, ?)')
        .run('admin', hashedPassword, 'System Administrator', adminRole.id, 'ADM-001');
        
      const adminId = result.lastInsertRowid;

      // Seed Announcements
      const insertAnn = db.prepare('INSERT INTO announcements (title, content, type, author_id) VALUES (?, ?, ?, ?)');
      insertAnn.run('Nowe Procedury Bezpieczeństwa', 'Od jutra obowiązują nowe procedury kontroli cel na oddziale C.', 'procedure', adminId);
      insertAnn.run('ALARM: Próba przemytu', 'Wykryto próbę przemytu na punkcie kontrolnym. Wzmocnić czujność.', 'warning', adminId);

      // Seed Messages
      const insertMsg = db.prepare('INSERT INTO messages (sender_id, receiver_id, content) VALUES (?, ?, ?)');
      insertMsg.run(adminId, adminId, 'Proszę o przygotowanie raportu z dyżuru nocnego.');
      console.log('Konto administratora utworzone pomyślnie.');
    }
  } catch (err) {
    console.error('Błąd podczas inicjalizacji administratora:', err);
  }

  // Auth Middleware
  const authenticateToken = (req: any, res: any, next: any) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) return res.status(401).json({ message: 'Unauthorized' });

    jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
      if (err) return res.status(403).json({ message: 'Forbidden' });
      req.user = user;
      next();
    });
  };

  // --- API Routes ---
  app.get('/api/health', (req, res) => {
    try {
      const result = db.prepare('SELECT 1 as connected').get() as { connected: number };
      res.json({ status: 'ok', database: result.connected === 1 ? 'connected' : 'error' });
    } catch (err: any) {
      res.status(500).json({ status: 'error', database: 'disconnected', message: err.message });
    }
  });

  // Login
  app.post('/api/auth/login', async (req, res) => {
    try {
      const { username, password } = req.body;
      const user = db.prepare(`
        SELECT u.*, r.name as role_name, r.permissions 
        FROM users u 
        JOIN roles r ON u.role_id = r.id 
        WHERE u.username = ?
      `).get(username) as any;

      if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(401).json({ message: 'Nieprawidłowy login lub hasło' });
      }

      const token = jwt.sign(
        { id: user.id, username: user.username, role: user.role_name, permissions: JSON.parse(user.permissions) },
        JWT_SECRET,
        { expiresIn: '8h' }
      );

      db.prepare('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?').run(user.id);
      db.prepare('INSERT INTO logs (user_id, action, details) VALUES (?, ?, ?)')
        .run(user.id, 'LOGIN', `User ${username} logged in`);

      res.json({
        token,
        user: {
          id: user.id,
          username: user.username,
          fullName: user.full_name,
          role: user.role_name,
          permissions: JSON.parse(user.permissions)
        }
      });
    } catch (err) {
      console.error('Błąd logowania:', err);
      res.status(500).json({ message: 'Błąd serwera podczas logowania' });
    }
  });

  // Dashboard Stats
  app.get('/api/stats', authenticateToken, (req, res) => {
    try {
      const inmateCount = db.prepare('SELECT COUNT(*) as count FROM inmates').get() as any;
      const staffOnShift = db.prepare('SELECT COUNT(*) as count FROM schedules WHERE shift_start <= CURRENT_TIMESTAMP AND shift_end >= CURRENT_TIMESTAMP').get() as any;
      const activeAlarms = db.prepare("SELECT COUNT(*) as count FROM incidents WHERE threat_level IN ('high', 'critical') AND date >= date('now', '-1 day')").get() as any;
      const recentIncidents = db.prepare('SELECT * FROM incidents ORDER BY date DESC LIMIT 5').all();
      const announcements = db.prepare('SELECT * FROM announcements ORDER BY created_at DESC LIMIT 5').all();

      res.json({
        inmateCount: inmateCount?.count || 0,
        staffOnShift: staffOnShift?.count || 0,
        activeAlarms: activeAlarms?.count || 0,
        recentIncidents: recentIncidents || [],
        announcements: announcements || []
      });
    } catch (err: any) {
      console.error('Błąd pobierania statystyk:', err);
      res.status(500).json({ 
        error: 'Błąd serwera',
        inmateCount: 0,
        staffOnShift: 0,
        activeAlarms: 0,
        recentIncidents: [],
        announcements: []
      });
    }
  });

  // Inmates
  app.get('/api/inmates', authenticateToken, (req, res) => {
    const inmates = db.prepare(`
      SELECT i.*, c.cell_number, w.name as ward_name 
      FROM inmates i 
      LEFT JOIN cells c ON i.cell_id = c.id 
      LEFT JOIN wards w ON c.ward_id = w.id
    `).all();
    res.json(inmates);
  });

  app.get('/api/inmates/:id', authenticateToken, (req, res) => {
    const inmate = db.prepare('SELECT * FROM inmates WHERE id = ?').get(req.params.id) as any;
    if (!inmate) return res.status(404).json({ message: 'Inmate not found' });
    const behavior = db.prepare('SELECT * FROM behavior_history WHERE inmate_id = ? ORDER BY date DESC').all(req.params.id);
    const medical = db.prepare('SELECT * FROM medical_records WHERE inmate_id = ? ORDER BY date DESC').all(req.params.id);
    res.json({ ...inmate, behavior, medical });
  });

  app.post('/api/inmates', authenticateToken, (req, res) => {
    if ((req as any).user.role !== 'Admin' && (req as any).user.role !== 'Administrative') {
      return res.status(403).json({ message: 'Brak uprawnień do przyjmowania osadzonych' });
    }
    
    const { first_name, last_name, inmate_number, birth_date, citizenship, height, weight, eye_color, crime_type, security_level, cell_id } = req.body;
    
    try {
      const result = db.prepare(`
        INSERT INTO inmates (first_name, last_name, inmate_number, birth_date, citizenship, height, weight, eye_color, crime_type, security_level, cell_id, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
      `).run(first_name, last_name, inmate_number, birth_date, citizenship, height || null, weight || null, eye_color || null, crime_type, security_level, cell_id || null);
      
      db.prepare('INSERT INTO logs (user_id, action, details) VALUES (?, ?, ?)')
        .run((req as any).user.id, 'INMATE_ADMIT', `Przyjęto nowego osadzonego: ${first_name} ${last_name} (${inmate_number})`);
        
      res.json({ id: result.lastInsertRowid });
    } catch (err: any) {
      console.error(err);
      res.status(500).json({ error: 'Błąd podczas przyjmowania osadzonego: ' + err.message });
    }
  });

  app.put('/api/inmates/:id', authenticateToken, (req, res) => {
    if ((req as any).user.role !== 'Admin') return res.status(403).json({ message: 'Brak uprawnień' });
    const { first_name, last_name, inmate_number, birth_date, citizenship, height, weight, eye_color, crime_type, security_level } = req.body;
    try {
      db.prepare(`
        UPDATE inmates 
        SET first_name = ?, last_name = ?, inmate_number = ?, birth_date = ?, citizenship = ?, height = ?, weight = ?, eye_color = ?, crime_type = ?, security_level = ?
        WHERE id = ?
      `).run(first_name, last_name, inmate_number, birth_date, citizenship, height || null, weight || null, eye_color || null, crime_type, security_level, req.params.id);
      
      db.prepare('INSERT INTO logs (user_id, action, details) VALUES (?, ?, ?)')
        .run((req as any).user.id, 'INMATE_UPDATE', `Zaktualizowano profil osadzonego ${inmate_number}`);
        
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: 'Błąd aktualizacji' });
    }
  });

  app.delete('/api/inmates/:id', authenticateToken, (req, res) => {
    if ((req as any).user.role !== 'Admin') return res.status(403).json({ message: 'Brak uprawnień' });
    try {
      const inmateId = req.params.id;
      // Delete related records first
      db.prepare('DELETE FROM behavior_history WHERE inmate_id = ?').run(inmateId);
      db.prepare('DELETE FROM medical_records WHERE inmate_id = ?').run(inmateId);
      db.prepare('DELETE FROM inmates WHERE id = ?').run(inmateId);
      
      db.prepare('INSERT INTO logs (user_id, action, details) VALUES (?, ?, ?)')
        .run((req as any).user.id, 'INMATE_DELETE', `Usunięto profil osadzonego ID: ${inmateId}`);
        
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: 'Błąd usuwania osadzonego' });
    }
  });

  app.put('/api/inmates/:id/biometrics', authenticateToken, (req, res) => {
    const { photo_url, fingerprint_url } = req.body;
    const inmateId = req.params.id;
    
    if (photo_url !== undefined) {
      db.prepare('UPDATE inmates SET photo_url = ? WHERE id = ?').run(photo_url, inmateId);
    }
    if (fingerprint_url !== undefined) {
      db.prepare('UPDATE inmates SET fingerprint_url = ? WHERE id = ?').run(fingerprint_url, inmateId);
    }
    
    db.prepare('INSERT INTO logs (user_id, action, details) VALUES (?, ?, ?)')
      .run((req as any).user.id, 'UPDATE_BIOMETRICS', `Updated biometrics for inmate ${inmateId}`);
      
    res.json({ success: true });
  });

  app.get('/api/inmates/:id/pdf', authenticateToken, (req, res) => {
    const inmateId = req.params.id;
    const inmate = db.prepare(`
      SELECT i.*, c.cell_number, w.name as ward_name 
      FROM inmates i 
      LEFT JOIN cells c ON i.cell_id = c.id 
      LEFT JOIN wards w ON c.ward_id = w.id
      WHERE i.id = ?
    `).get(inmateId) as any;
    
    if (!inmate) return res.status(404).json({ message: 'Inmate not found' });
    
    const behavior = db.prepare('SELECT * FROM behavior_history WHERE inmate_id = ? ORDER BY date DESC LIMIT 10').all(inmateId) as any[];
    const medical = db.prepare('SELECT * FROM medical_records WHERE inmate_id = ? ORDER BY date DESC LIMIT 10').all(inmateId) as any[];
    
    // Generate simulated PDF text
    let output = "%PDF-1.4\n";
    output += "%% SYSTEM PRISONGUARD - FORMULARZ OSADZONEGO\n";
    output += "============================================================\n";
    output += "DOKUMENTACJA OFICJALNA JEDNOSTKI PENITENCJARNEJ\n";
    output += "Data wygenerowania: " + new Date().toISOString().replace('T', ' ').substring(0, 19) + "\n";
    output += "============================================================\n\n";

    output += "DANE OSOBOWE:\n";
    output += "------------------------------------------------------------\n";
    output += "Imię i Nazwisko: " + (inmate.last_name || '').toUpperCase() + " " + (inmate.first_name || '') + "\n";
    output += "Numer Inmate ID: " + (inmate.inmate_number || '') + "\n";
    output += "Data Urodzenia:  " + (inmate.birth_date || '') + "\n";
    output += "Obywatelstwo:    " + (inmate.citizenship || '') + "\n";
    output += "Wzrost/Waga:     " + (inmate.height || '---') + " cm / " + (inmate.weight || '---') + " kg\n";
    output += "Kolor Oczu:      " + (inmate.eye_color || '---') + "\n";
    output += "------------------------------------------------------------\n\n";

    output += "INFORMACJE O WYROKU:\n";
    output += "------------------------------------------------------------\n";
    output += "Typ Przestępstwa: " + (inmate.crime_type || '') + "\n";
    output += "Poziom Bezp.:     " + (inmate.security_level || '').toUpperCase() + "\n";
    output += "Lokalizacja:      " + (inmate.cell_number || 'NIEPRZYPISANY') + "\n";
    output += "------------------------------------------------------------\n\n";

    output += "HISTORIA ZACHOWANIA (Ostatnie wpisy):\n";
    if (behavior && behavior.length > 0) {
      behavior.slice(0, 5).forEach(entry => {
        output += "[" + entry.date + "] " + (entry.type || '').toUpperCase() + ": " + entry.description + "\n";
      });
    } else {
      output += "Brak odnotowanej historii.\n";
    }

    output += "\n============================================================\n";
    output += "PODPIS NACZELNIKA JEDNOSTKI: ................................\n";
    output += "PIECZĘĆ URZĘDOWA\n";
    output += "%% EOF\n";

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="formularz_osadzonego_${inmate.inmate_number}.pdf"`);
    res.send(output);
  });

  // Incidents
  app.get('/api/incidents', authenticateToken, (req, res) => {
    const user = (req as any).user;
    if (user.role === 'Admin') {
      res.json(db.prepare('SELECT * FROM incidents ORDER BY date DESC').all());
    } else {
      res.json(db.prepare('SELECT * FROM incidents WHERE reporter_id = ? ORDER BY date DESC').all(user.id));
    }
  });

  app.post('/api/incidents', authenticateToken, (req, res) => {
    const { location, description, threat_level, category, involved_inmates } = req.body;
    const userId = (req as any).user.id;
    const result = db.prepare(`
      INSERT INTO incidents (date, location, description, threat_level, category, reporter_id, involved_inmates)
      VALUES (CURRENT_TIMESTAMP, ?, ?, ?, ?, ?, ?)
    `).run(location, description, threat_level, category, userId, JSON.stringify(involved_inmates));

    db.prepare('INSERT INTO logs (user_id, action, details) VALUES (?, ?, ?)')
      .run(userId, 'INCIDENT_REPORT', `Reported ${category} at ${location}`);

    // Add to reports for Admin
    db.prepare('INSERT INTO reports (sender_id, type, content) VALUES (?, ?, ?)').run(
      userId, 
      'incident', 
      `Zgłoszono incydent: ${category} w ${location}. Poziom: ${threat_level}. Opis: ${description}`
    );

    res.json({ id: result.lastInsertRowid });
  });

  // Staff & Schedules
  app.get('/api/staff', authenticateToken, (req, res) => {
    const staff = db.prepare(`
      SELECT u.id, u.username, u.full_name, u.badge_number, u.department, r.name as role 
      FROM users u 
      JOIN roles r ON u.role_id = r.id
    `).all();
    res.json(staff);
  });

  app.get('/api/staff/:id', authenticateToken, (req, res) => {
    const user = db.prepare(`
      SELECT u.id, u.username, u.full_name, u.badge_number, u.department, r.name as role 
      FROM users u 
      JOIN roles r ON u.role_id = r.id 
      WHERE u.id = ?
    `).get(req.params.id) as any;
    if (!user) return res.status(404).json({ message: 'User not found' });
    const logs = db.prepare('SELECT * FROM logs WHERE user_id = ? ORDER BY timestamp DESC LIMIT 50').all(req.params.id);
    
    const schedules = db.prepare('SELECT shift_start, shift_end FROM schedules WHERE user_id = ?').all(req.params.id);
    let totalWorkHours = 0;
    schedules.forEach((s: any) => {
      const start = new Date(s.shift_start).getTime();
      const end = new Date(s.shift_end).getTime();
      if (!isNaN(start) && !isNaN(end)) {
        totalWorkHours += (end - start) / (1000 * 60 * 60);
      }
    });

    res.json({ ...user, logs, totalWorkHours: Math.round(totalWorkHours * 10) / 10 });
  });

  app.post('/api/staff', authenticateToken, async (req, res) => {
    if ((req as any).user.role !== 'Admin') return res.status(403).json({ message: 'Brak uprawnień' });
    const { username, password, full_name, role_id, badge_number, department } = req.body;
    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const result = db.prepare('INSERT INTO users (username, password, full_name, role_id, badge_number, department) VALUES (?, ?, ?, ?, ?, ?)')
        .run(username, hashedPassword, full_name, role_id, badge_number, department);
      db.prepare('INSERT INTO logs (user_id, action, details) VALUES (?, ?, ?)')
        .run((req as any).user.id, 'CREATE_STAFF', `Utworzono profil pracownika: ${username}`);
      res.json({ id: result.lastInsertRowid });
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.put('/api/staff/:id', authenticateToken, async (req, res) => {
    if ((req as any).user.role !== 'Admin') return res.status(403).json({ message: 'Brak uprawnień' });
    const { username, password, full_name, role_id, badge_number, department } = req.body;
    try {
      if (password) {
        const hashedPassword = await bcrypt.hash(password, 10);
        db.prepare('UPDATE users SET username = ?, password = ?, full_name = ?, role_id = ?, badge_number = ?, department = ? WHERE id = ?')
          .run(username, hashedPassword, full_name, role_id, badge_number, department, req.params.id);
      } else {
        db.prepare('UPDATE users SET username = ?, full_name = ?, role_id = ?, badge_number = ?, department = ? WHERE id = ?')
          .run(username, full_name, role_id, badge_number, department, req.params.id);
      }
      db.prepare('INSERT INTO logs (user_id, action, details) VALUES (?, ?, ?)')
        .run((req as any).user.id, 'UPDATE_STAFF', `Zaktualizowano profil pracownika: ${username}`);
      res.json({ success: true });
    } catch (e: any) {
      res.status(400).json({ message: e.message });
    }
  });

  app.delete('/api/staff/:id', authenticateToken, (req, res) => {
    if ((req as any).user.role !== 'Admin') return res.status(403).json({ message: 'Brak uprawnień' });
    try {
      const staffId = req.params.id;
      // Prevent deleting self
      if (staffId == (req as any).user.id) {
        return res.status(400).json({ message: 'Nie możesz usunąć własnego konta' });
      }
      
      // Delete related records
      db.prepare('DELETE FROM schedules WHERE user_id = ?').run(staffId);
      db.prepare('DELETE FROM logs WHERE user_id = ?').run(staffId);
      db.prepare('DELETE FROM users WHERE id = ?').run(staffId);
      
      db.prepare('INSERT INTO logs (user_id, action, details) VALUES (?, ?, ?)')
        .run((req as any).user.id, 'DELETE_STAFF', `Usunięto profil pracownika ID: ${staffId}`);
        
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: 'Błąd usuwania pracownika' });
    }
  });

  app.get('/api/roles', authenticateToken, (req, res) => {
    res.json(db.prepare('SELECT id, name FROM roles').all());
  });

  app.get('/api/users', authenticateToken, (req, res) => {
    res.json(db.prepare('SELECT id, full_name, username FROM users').all());
  });

  app.get('/api/notifications', authenticateToken, (req, res) => {
    const incidents = db.prepare(`SELECT id, category as title, date as time, 'incident' as type FROM incidents ORDER BY date DESC LIMIT 5`).all();
    const messages = db.prepare(`SELECT id, content as title, sent_at as time, 'message' as type FROM messages WHERE receiver_id = ? ORDER BY sent_at DESC LIMIT 5`).all((req as any).user.id);
    const notifs = [...incidents, ...messages].sort((a: any, b: any) => new Date(b.time).getTime() - new Date(a.time).getTime()).slice(0, 5);
    res.json(notifs);
  });

  // Visits
  app.get('/api/visits', authenticateToken, (req, res) => {
    const visits = db.prepare(`
      SELECT v.*, i.first_name, i.last_name, i.inmate_number 
      FROM visits v 
      JOIN inmates i ON v.inmate_id = i.id 
      ORDER BY v.visit_date DESC, v.visit_time DESC
    `).all();
    res.json(visits);
  });

  app.post('/api/visits', authenticateToken, (req, res) => {
    const { inmate_id, visitor_name, relationship, visit_date, visit_time, notes } = req.body;
    const result = db.prepare(`
      INSERT INTO visits (inmate_id, visitor_name, relationship, visit_date, visit_time, notes)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(inmate_id, visitor_name, relationship, visit_date, visit_time, notes);
    res.json({ id: result.lastInsertRowid });
  });

  // Schedules
  app.get('/api/schedules', authenticateToken, (req, res) => {
    const schedules = db.prepare(`
      SELECT s.*, u.full_name 
      FROM schedules s 
      JOIN users u ON s.user_id = u.id 
      ORDER BY s.shift_start ASC
    `).all();
    res.json(schedules);
  });

  app.post('/api/schedules', authenticateToken, (req, res) => {
    const { user_id, shift_start, shift_end, type } = req.body;
    db.prepare('INSERT INTO schedules (user_id, shift_start, shift_end, type) VALUES (?, ?, ?, ?)').run(user_id, shift_start, shift_end, type);
    res.json({ success: true });
  });

  // Reports
  app.get('/api/reports', authenticateToken, (req, res) => {
    const user = (req as any).user;
    if (user.role === 'Admin') {
      const reports = db.prepare(`
        SELECT r.*, u.full_name as sender_name 
        FROM reports r 
        JOIN users u ON r.sender_id = u.id 
        ORDER BY r.created_at DESC
      `).all();
      res.json(reports);
    } else {
      const reports = db.prepare(`
        SELECT r.*, u.full_name as sender_name 
        FROM reports r 
        JOIN users u ON r.sender_id = u.id 
        WHERE r.sender_id = ?
        ORDER BY r.created_at DESC
      `).all(user.id);
      res.json(reports);
    }
  });

  app.post('/api/reports', authenticateToken, (req, res) => {
    const { type, content } = req.body;
    db.prepare('INSERT INTO reports (sender_id, type, content) VALUES (?, ?, ?)').run((req as any).user.id, type, content);
    res.json({ success: true });
  });

  // Messages
  app.get('/api/messages', authenticateToken, (req, res) => {
    const userId = (req as any).user.id;
    const messages = db.prepare(`
      SELECT m.*, u.full_name as sender_name 
      FROM messages m 
      JOIN users u ON m.sender_id = u.id 
      WHERE m.receiver_id = ? OR m.sender_id = ?
      ORDER BY m.sent_at DESC
    `).all(userId, userId);
    res.json(messages);
  });

  app.post('/api/messages', authenticateToken, (req, res) => {
    const { receiver_id, content } = req.body;
    const result = db.prepare(`
      INSERT INTO messages (sender_id, receiver_id, content)
      VALUES (?, ?, ?)
    `).run((req as any).user.id, receiver_id, content);
    res.json({ id: result.lastInsertRowid });
  });

  // Cells
  app.get('/api/cells', authenticateToken, (req, res) => {
    const cells = db.prepare(`
      SELECT c.*, w.name as ward_name, (SELECT COUNT(*) FROM inmates WHERE cell_id = c.id) as current_occupancy
      FROM cells c
      JOIN wards w ON c.ward_id = w.id
    `).all();
    res.json(cells);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve('dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve('dist/index.html'));
    });
  }

  const PORT = 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Błąd podczas uruchamiania serwera:', err);
});

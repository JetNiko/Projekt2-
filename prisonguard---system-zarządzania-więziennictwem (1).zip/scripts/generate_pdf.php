<?php
/**
 * Skrypt PHP do generowania "PDF" (wersja tekstowa dla demonstracji)
 * 
 * W rzeczywistym środowisku użylibyśmy biblioteki FPDF lub TCPDF.
 * Ten skrypt przyjmuje dane osadzonego jako argumenty JSON.
 */

if ($argc < 2) {
    die("Błąd: Brak danych wejściowych.\n");
}

$data = json_decode($argv[1], true);

if (!$data) {
    die("Błąd: Nieprawidłowy format danych JSON.\n");
}

// Symulacja struktury PDF (nagłówek)
echo "%PDF-1.4\n";
echo "%% SYSTEM PRISONGUARD - FORMULARZ OSADZONEGO\n";
echo str_repeat("=", 60) . "\n";
echo "DOKUMENTACJA OFICJALNA JEDNOSTKI PENITENCJARNEJ\n";
echo "Data wygenerowania: " . date('Y-m-d H:i:s') . "\n";
echo str_repeat("=", 60) . "\n\n";

echo "DANE OSOBOWE:\n";
echo "------------------------------------------------------------\n";
echo "Imię i Nazwisko: " . strtoupper($data['last_name']) . " " . $data['first_name'] . "\n";
echo "Numer Inmate ID: " . $data['inmate_number'] . "\n";
echo "Data Urodzenia:  " . $data['birth_date'] . "\n";
echo "Obywatelstwo:    " . $data['citizenship'] . "\n";
echo "Wzrost/Waga:     " . ($data['height'] ?? '---') . " cm / " . ($data['weight'] ?? '---') . " kg\n";
echo "Kolor Oczu:      " . ($data['eye_color'] ?? '---') . "\n";
echo "------------------------------------------------------------\n\n";

echo "INFORMACJE O WYROKU:\n";
echo "------------------------------------------------------------\n";
echo "Typ Przestępstwa: " . $data['crime_type'] . "\n";
echo "Poziom Bezp.:     " . strtoupper($data['security_level']) . "\n";
echo "Lokalizacja:      " . ($data['cell_number'] ?? 'NIEPRZYPISANY') . "\n";
echo "------------------------------------------------------------\n\n";

echo "HISTORIA ZACHOWANIA (Ostatnie wpisy):\n";
if (!empty($data['behavior'])) {
    foreach (array_slice($data['behavior'], 0, 5) as $entry) {
        echo "[" . $entry['date'] . "] " . strtoupper($entry['type']) . ": " . $entry['description'] . "\n";
    }
} else {
    echo "Brak odnotowanej historii.\n";
}

echo "\n" . str_repeat("=", 60) . "\n";
echo "PODPIS NACZELNIKA JEDNOSTKI: ................................\n";
echo "PIECZĘĆ URZĘDOWA\n";
echo "%% EOF\n";
?>

<?php
/**
 * Skrypt PHP do generowania raportu tekstowego (Przykład użycia PHP w projekcie)
 * 
 * Ten skrypt demonstruje funkcję przetwarzania danych osadzonych.
 * W rzeczywistym systemie mógłby być wywoływany przez serwer Node.js
 * do generowania zaawansowanych raportów PDF lub eksportu danych.
 */

function generateInmateReport($inmates) {
    $report = "RAPORT SYSTEMU PRISONGUARD - EKSPORT DANYCH\n";
    $report .= "Data wygenerowania: " . date('Y-m-d H:i:s') . "\n";
    $report .= str_repeat("=", 50) . "\n\n";

    foreach ($inmates as $inmate) {
        $report .= "OSADZONY: " . strtoupper($inmate['last_name']) . " " . $inmate['first_name'] . "\n";
        $report .= "NUMER ID: " . $inmate['inmate_number'] . "\n";
        $report .= "STATUS: " . $inmate['status'] . "\n";
        $report .= str_repeat("-", 30) . "\n";
    }

    return $report;
}

// Przykładowe dane (w rzeczywistości mogłyby pochodzić z argumentów linii komend lub bazy)
$sampleInmates = [
    ['first_name' => 'Jan', 'last_name' => 'Kowalski', 'inmate_number' => '2026/001', 'status' => 'active'],
    ['first_name' => 'Adam', 'last_name' => 'Nowak', 'inmate_number' => '2026/002', 'status' => 'released']
];

echo generateInmateReport($sampleInmates);
?>

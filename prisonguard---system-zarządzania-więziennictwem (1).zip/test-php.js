import { exec } from 'child_process';
exec('php -v', (error, stdout, stderr) => {
  if (error) {
    console.log('PHP NOT FOUND');
  } else {
    console.log('PHP FOUND: ' + stdout);
  }
});

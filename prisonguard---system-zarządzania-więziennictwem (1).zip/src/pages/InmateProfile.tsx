import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  User as UserIcon, 
  Calendar, 
  Shield, 
  MapPin, 
  FileText, 
  AlertCircle,
  Award,
  Stethoscope,
  Clock,
  Fingerprint,
  Edit2,
  X
} from 'lucide-react';
import { motion } from 'motion/react';
import { Inmate } from '../types';

export default function InmateProfile() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editData, setEditData] = useState<any>({});

  const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
  const isAdmin = currentUser.role === 'Admin';

  useEffect(() => {
    fetchInmate();
  }, [id]);

  const fetchInmate = async () => {
    try {
      const response = await fetch(`/api/inmates/${id}`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await response.json();
      setData(data);
      setEditData(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch(`/api/inmates/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(editData)
      });
      if (response.ok) {
        setShowEditModal(false);
        fetchInmate();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Czy na pewno chcesz usunąć profil tego osadzonego? Tej operacji nie można cofnąć.')) return;
    try {
      const response = await fetch(`/api/inmates/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      if (response.ok) {
        navigate('/inmates');
      } else {
        alert('Błąd podczas usuwania profilu');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: 'photo' | 'fingerprint') => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64String = reader.result as string;
      
      try {
        const response = await fetch(`/api/inmates/${id}/biometrics`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          },
          body: JSON.stringify({
            [type === 'photo' ? 'photo_url' : 'fingerprint_url']: base64String
          })
        });
        
        if (response.ok) {
          setData((prev: any) => ({
            ...prev,
            [type === 'photo' ? 'photo_url' : 'fingerprint_url']: base64String
          }));
        }
      } catch (err) {
        console.error('Upload failed', err);
      }
    };
    reader.readAsDataURL(file);
  };

  if (loading) return <div className="font-mono text-xs uppercase opacity-50">Pobieranie profilu...</div>;
  if (!data) return <div className="font-mono text-xs uppercase opacity-50 text-red-600">Błąd: Nie znaleziono osadzonego</div>;

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {showEditModal && isAdmin && (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-6 backdrop-blur-sm">
          <div className="bg-[#E4E3E0] w-full max-w-2xl p-12 border-t-8 border-[#141414] relative max-h-[90vh] overflow-y-auto">
            <button onClick={() => setShowEditModal(false)} className="absolute top-6 right-6 p-2 hover:bg-[#141414]/5 rounded-full transition-colors">
              <X className="w-6 h-6" />
            </button>
            <h3 className="text-3xl font-bold tracking-tighter uppercase mb-8">Edytuj Profil Osadzonego</h3>
            <form className="space-y-6" onSubmit={handleEditSubmit}>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Imię</label>
                  <input type="text" value={editData.first_name || ''} onChange={e => setEditData({...editData, first_name: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" required />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Nazwisko</label>
                  <input type="text" value={editData.last_name || ''} onChange={e => setEditData({...editData, last_name: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" required />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Numer Osadzonego</label>
                  <input type="text" value={editData.inmate_number || ''} onChange={e => setEditData({...editData, inmate_number: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" required />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Data Urodzenia</label>
                  <input type="date" value={editData.birth_date || ''} onChange={e => setEditData({...editData, birth_date: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" required />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Obywatelstwo</label>
                  <input type="text" value={editData.citizenship || ''} onChange={e => setEditData({...editData, citizenship: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" required />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Wzrost (cm)</label>
                  <input type="number" value={editData.height || ''} onChange={e => setEditData({...editData, height: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Waga (kg)</label>
                  <input type="number" value={editData.weight || ''} onChange={e => setEditData({...editData, weight: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Kolor Oczu</label>
                  <input type="text" value={editData.eye_color || ''} onChange={e => setEditData({...editData, eye_color: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Typ Przestępstwa</label>
                  <input type="text" value={editData.crime_type || ''} onChange={e => setEditData({...editData, crime_type: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" required />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Poziom Bezpieczeństwa</label>
                  <select value={editData.security_level || ''} onChange={e => setEditData({...editData, security_level: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" required>
                    <option value="low">Niski</option>
                    <option value="medium">Średni</option>
                    <option value="high">Wysoki</option>
                  </select>
                </div>
              </div>
              <button type="submit" className="w-full bg-[#141414] text-[#E4E3E0] py-5 font-bold uppercase tracking-widest hover:bg-black transition-all">
                ZAPISZ ZMIANY
              </button>
            </form>
          </div>
        </div>
      )}

      <div className="flex justify-between items-center">
        <Link to="/inmates" className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest opacity-50 hover:opacity-100 transition-opacity">
          <ArrowLeft className="w-4 h-4" /> Powrót do listy
        </Link>
        {isAdmin && (
          <div className="flex gap-4">
            <button 
              onClick={async () => {
                const response = await fetch(`/api/inmates/${id}/pdf`, {
                  headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
                });
                if (response.ok) {
                  const blob = await response.blob();
                  const url = window.URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `formularz_${data.inmate_number}.pdf`;
                  document.body.appendChild(a);
                  a.click();
                  a.remove();
                } else {
                  alert('Błąd podczas generowania PDF przez PHP');
                }
              }}
              className="px-4 py-2 bg-blue-600 text-white text-[10px] font-bold uppercase tracking-widest hover:bg-blue-700 transition-all flex items-center gap-2"
            >
              <FileText className="w-4 h-4" /> Pobierz Formularz PDF (PHP)
            </button>
            <button onClick={() => setShowEditModal(true)} className="px-4 py-2 bg-[#141414] text-[#E4E3E0] text-[10px] font-bold uppercase tracking-widest hover:bg-black transition-all flex items-center gap-2">
              <Edit2 className="w-4 h-4" /> Edytuj Profil
            </button>
            <button onClick={handleDelete} className="px-4 py-2 bg-red-600 text-white text-[10px] font-bold uppercase tracking-widest hover:bg-red-700 transition-all flex items-center gap-2">
              <X className="w-4 h-4" /> Usuń Profil
            </button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Basic Info */}
        <div className="space-y-8">
          <div className="bg-white border border-[#141414] p-8 text-center">
            <div className="flex flex-col gap-6 mb-6 text-left">
              {/* Photo */}
              <div className="flex items-center gap-4 bg-[#141414]/5 p-4 border border-[#141414]">
                <div className="w-24 h-32 bg-white border border-[#141414] flex items-center justify-center overflow-hidden shrink-0">
                  {data.photo_url ? (
                    <img src={data.photo_url} alt="Profile" className="w-full h-full object-cover" />
                  ) : (
                    <UserIcon className="w-10 h-10 opacity-10" />
                  )}
                </div>
                <div className="flex-1">
                  <h4 className="text-xs font-bold uppercase mb-2">Zdjęcie Profilowe</h4>
                  <label className="inline-block bg-[#141414] text-[#E4E3E0] px-4 py-2 text-[10px] font-bold uppercase tracking-widest cursor-pointer hover:bg-black transition-colors">
                    Wgraj Zdjęcie
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => handleFileUpload(e, 'photo')} />
                  </label>
                </div>
              </div>

              {/* Fingerprint */}
              <div className="flex items-center gap-4 bg-[#141414]/5 p-4 border border-[#141414]">
                <div className="w-24 h-32 bg-white border border-[#141414] flex items-center justify-center overflow-hidden shrink-0">
                  {data.fingerprint_url ? (
                    <img src={data.fingerprint_url} alt="Fingerprint" className="w-full h-full object-cover mix-blend-multiply p-1" />
                  ) : (
                    <Fingerprint className="w-10 h-10 opacity-10" />
                  )}
                </div>
                <div className="flex-1">
                  <h4 className="text-xs font-bold uppercase mb-2">Odcisk Palca</h4>
                  <label className="inline-block bg-[#141414] text-[#E4E3E0] px-4 py-2 text-[10px] font-bold uppercase tracking-widest cursor-pointer hover:bg-black transition-colors">
                    Wgraj Skan
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => handleFileUpload(e, 'fingerprint')} />
                  </label>
                </div>
              </div>
            </div>
            <h2 className="text-3xl font-bold tracking-tighter uppercase mb-1">{data.first_name} {data.last_name}</h2>
            <p className="text-sm font-mono uppercase tracking-widest opacity-50 mb-6">{data.inmate_number}</p>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-[#141414]/5 border border-[#141414]/10 text-center">
                <div className="text-[10px] font-mono uppercase opacity-50 mb-1">Poziom Bezp.</div>
                <div className="font-bold uppercase text-xs">{data.security_level}</div>
              </div>
              <div className="p-4 bg-[#141414]/5 border border-[#141414]/10 text-center">
                <div className="text-[10px] font-mono uppercase opacity-50 mb-1">Status</div>
                <div className="font-bold uppercase text-xs text-emerald-600">Aktywny</div>
              </div>
            </div>
          </div>

          <div className="bg-white border border-[#141414] p-8 space-y-6">
            <h3 className="text-sm font-bold uppercase tracking-widest border-b border-[#141414] pb-2">Dane Osobowe</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-mono uppercase opacity-50">Data Urodzenia</span>
                <span className="text-xs font-bold">{data.birth_date}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-mono uppercase opacity-50">Obywatelstwo</span>
                <span className="text-xs font-bold uppercase">{data.citizenship}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-mono uppercase opacity-50">Wzrost</span>
                <span className="text-xs font-bold uppercase">{data.height ? `${data.height} cm` : 'Brak danych'}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-mono uppercase opacity-50">Waga</span>
                <span className="text-xs font-bold uppercase">{data.weight ? `${data.weight} kg` : 'Brak danych'}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-mono uppercase opacity-50">Kolor Oczu</span>
                <span className="text-xs font-bold uppercase">{data.eye_color || 'Brak danych'}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-mono uppercase opacity-50">Typ Przestępstwa</span>
                <span className="text-xs font-bold uppercase">{data.crime_type}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Middle/Right Column: Details & History */}
        <div className="lg:col-span-2 space-y-8">
          {/* Sentence Info */}
          <div className="bg-[#141414] text-[#E4E3E0] p-8 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-2">
              <Calendar className="w-5 h-5 opacity-50" />
              <div className="text-[10px] font-mono uppercase opacity-50">Początek Kary</div>
              <div className="font-bold text-lg">{data.sentence_start_date || 'BRAK'}</div>
            </div>
            <div className="space-y-2">
              <Clock className="w-5 h-5 opacity-50" />
              <div className="text-[10px] font-mono uppercase opacity-50">Koniec Kary</div>
              <div className="font-bold text-lg">{data.sentence_end_date || 'BRAK'}</div>
            </div>
            <div className="space-y-2">
              <MapPin className="w-5 h-5 opacity-50" />
              <div className="text-[10px] font-mono uppercase opacity-50">Lokalizacja</div>
              <div className="font-bold text-lg">{data.cell_number || 'NIEPRZYPISANY'}</div>
            </div>
          </div>

          {/* Behavior History */}
          <div className="space-y-6">
            <div className="flex items-center justify-between border-b border-[#141414] pb-4">
              <h3 className="text-lg font-bold uppercase tracking-tight">Historia Zachowania</h3>
              <div className="flex gap-2">
                <button className="px-4 py-2 bg-[#141414] text-[#E4E3E0] text-[10px] font-bold uppercase tracking-widest hover:bg-black transition-all">Dodaj wpis</button>
              </div>
            </div>
            <div className="space-y-4">
              {data.behavior?.map((entry: any) => (
                <div key={entry.id} className="bg-white p-6 border border-[#141414] flex items-start gap-6">
                  <div className={`w-10 h-10 shrink-0 flex items-center justify-center border border-[#141414] ${
                    entry.type === 'punishment' ? 'bg-red-50 text-red-600' : 
                    entry.type === 'reward' ? 'bg-emerald-50 text-emerald-600' : 'bg-[#141414]/5'
                  }`}>
                    {entry.type === 'punishment' ? <AlertCircle className="w-5 h-5" /> : 
                     entry.type === 'reward' ? <Award className="w-5 h-5" /> : <FileText className="w-5 h-5" />}
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-2">
                      <div className="font-bold uppercase tracking-tight">{entry.type.replace('_', ' ')}</div>
                      <div className="text-[10px] font-mono uppercase opacity-50">{new Date(entry.date).toLocaleString()}</div>
                    </div>
                    <p className="text-xs opacity-70">{entry.description}</p>
                  </div>
                </div>
              ))}
              {(!data.behavior || data.behavior.length === 0) && (
                <div className="p-12 text-center border border-dashed border-[#141414]/20 text-xs font-mono uppercase opacity-50">Brak odnotowanej historii zachowania</div>
              )}
            </div>
          </div>

          {/* Medical Records */}
          <div className="space-y-6">
            <div className="flex items-center justify-between border-b border-[#141414] pb-4">
              <h3 className="text-lg font-bold uppercase tracking-tight">Dokumentacja Medyczna</h3>
              <Stethoscope className="w-5 h-5 opacity-30" />
            </div>
            <div className="space-y-4">
              {data.medical?.map((record: any) => (
                <div key={record.id} className="bg-white p-6 border border-[#141414] flex items-start gap-6">
                  <div className="w-10 h-10 shrink-0 flex items-center justify-center border border-[#141414] bg-blue-50 text-blue-600">
                    <Stethoscope className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-2">
                      <div className="font-bold uppercase tracking-tight">{record.diagnosis}</div>
                      <div className="text-[10px] font-mono uppercase opacity-50">{new Date(record.date).toLocaleDateString()}</div>
                    </div>
                    <p className="text-xs opacity-70 mb-2">{record.treatment}</p>
                    <div className="text-[10px] font-mono uppercase tracking-widest opacity-50">Leki: {record.prescriptions || 'Brak'}</div>
                  </div>
                </div>
              ))}
              {(!data.medical || data.medical.length === 0) && (
                <div className="p-12 text-center border border-dashed border-[#141414]/20 text-xs font-mono uppercase opacity-50">Brak wpisów medycznych</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

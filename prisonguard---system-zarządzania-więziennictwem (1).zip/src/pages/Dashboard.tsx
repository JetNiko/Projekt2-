import React, { useState, useEffect } from 'react';
import { 
  Users, 
  AlertTriangle, 
  Shield, 
  Clock, 
  ArrowUpRight,
  Bell,
  MessageSquare
} from 'lucide-react';
import { motion } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import { User, Incident, Announcement } from '../types';

interface DashboardStats {
  inmate_count: number;
  staff_on_shift: number;
  active_alarms: number;
  recent_incidents: Incident[];
  announcements: Announcement[];
}

export default function Dashboard({ user }: { user: User }) {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/stats', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      
      if (!response.ok) {
        throw new Error(`Błąd serwera: ${response.status}`);
      }
      
      const data = await response.json();
      setStats(data);
    } catch (err) {
      console.error('Błąd pobierania statystyk:', err);
      // Fallback stats to prevent crash
      setStats({
        inmateCount: 0,
        staffOnShift: 0,
        activeAlarms: 0,
        recentIncidents: [],
        announcements: []
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDailyReport = async () => {
    try {
      const response = await fetch('/api/reports', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          type: 'daily',
          content: `Raport dzienny z dnia ${new Date().toLocaleDateString()}. Stan osadzonych: ${stats.inmateCount}. Personel na zmianie: ${stats.staffOnShift}.`
        })
      });
      if (response.ok) {
        alert('Raport dzienny został wygenerowany i wysłany do administratora.');
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) return <div className="font-mono text-xs uppercase opacity-50">Inicjalizacja danych...</div>;

  const statCards = [
    { label: 'Liczba Osadzonych', value: stats.inmateCount, icon: Users, color: 'text-[#141414]' },
    { label: 'Personel na Zmianie', value: stats.staffOnShift, icon: Shield, color: 'text-emerald-600' },
    { label: 'Aktywne Alarmy', value: stats.activeAlarms, icon: AlertTriangle, color: 'text-red-600' },
    { label: 'Komunikaty', value: stats.announcements.length, icon: Bell, color: 'text-amber-600' },
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-4xl font-bold tracking-tighter uppercase mb-2">Witaj, {user.fullName.split(' ')[0]}</h2>
          <p className="text-sm font-mono uppercase tracking-widest opacity-50">Status: Operacyjny | Rola: {user.role}</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => navigate('/incidents')} className="px-6 py-3 bg-[#141414] text-[#E4E3E0] text-xs font-bold uppercase tracking-widest hover:bg-black transition-all">
            Zgłoś Incydent
          </button>
          <button onClick={handleDailyReport} className="px-6 py-3 bg-white border border-[#141414] text-[#141414] text-xs font-bold uppercase tracking-widest hover:bg-[#141414]/5 transition-all">
            Raport Dzienny
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white p-8 border border-[#141414] relative group hover:bg-[#141414] hover:text-[#E4E3E0] transition-all duration-300"
          >
            <stat.icon className={`w-8 h-8 mb-6 ${stat.color} group-hover:text-[#E4E3E0] transition-colors`} />
            <div className="text-4xl font-bold tracking-tighter mb-2">{stat.value}</div>
            <div className="text-[10px] font-mono uppercase tracking-widest opacity-50 group-hover:opacity-70">{stat.label}</div>
            <ArrowUpRight className="absolute top-6 right-6 w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Incidents */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between border-b border-[#141414] pb-4">
            <h3 className="text-lg font-bold uppercase tracking-tight">Ostatnie Zdarzenia</h3>
            <button className="text-[10px] font-mono uppercase tracking-widest hover:underline">Zobacz wszystkie</button>
          </div>
          <div className="space-y-4">
            {stats.recentIncidents.map((incident: Incident) => (
              <div key={incident.id} className="bg-white p-6 border border-[#141414] flex items-center justify-between group cursor-pointer hover:border-l-4 hover:border-l-[#141414] transition-all">
                <div className="flex items-center gap-6">
                  <div className={`w-12 h-12 flex items-center justify-center border border-[#141414] ${
                    incident.threat_level === 'critical' ? 'bg-red-600 text-white' : 
                    incident.threat_level === 'high' ? 'bg-orange-500 text-white' : 'bg-[#141414]/5'
                  }`}>
                    <AlertTriangle className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-bold uppercase tracking-tight">{incident.category.replace('_', ' ')}</div>
                    <div className="text-[10px] font-mono uppercase tracking-widest opacity-50">
                      {incident.location} • {new Date(incident.date).toLocaleString()}
                    </div>
                  </div>
                </div>
                <div className="text-xs font-mono uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
                  Szczegóły →
                </div>
              </div>
            ))}
            {stats.recentIncidents.length === 0 && (
              <div className="p-12 text-center border border-dashed border-[#141414]/20 text-xs font-mono uppercase opacity-50">
                Brak odnotowanych incydentów w ostatnim czasie
              </div>
            )}
          </div>
        </div>

        {/* Announcements */}
        <div className="space-y-6">
          <div className="flex items-center justify-between border-b border-[#141414] pb-4">
            <h3 className="text-lg font-bold uppercase tracking-tight">Komunikaty</h3>
            <Bell className="w-4 h-4 opacity-30" />
          </div>
          <div className="space-y-4">
            {stats.announcements.map((ann: Announcement) => (
              <div key={ann.id} className="bg-[#141414] text-[#E4E3E0] p-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-2 opacity-10">
                  <MessageSquare className="w-12 h-12" />
                </div>
                <div className="text-[10px] font-mono uppercase tracking-widest opacity-50 mb-2">
                  {new Date(ann.created_at).toLocaleDateString()} • {ann.type}
                </div>
                <h4 className="font-bold uppercase tracking-tight mb-2">{ann.title}</h4>
                <p className="text-xs opacity-70 line-clamp-2">{ann.content}</p>
              </div>
            ))}
            {stats.announcements.length === 0 && (
              <div className="p-12 text-center border border-dashed border-[#141414]/20 text-xs font-mono uppercase opacity-50">
                Brak nowych komunikatów
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { Search, Filter, Plus, ChevronRight, User as UserIcon, X, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Inmate } from '../types';

export default function Inmates() {
  const [inmates, setInmates] = useState<Inmate[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [showAdmitModal, setShowAdmitModal] = useState(false);
  const [newInmate, setNewInmate] = useState({
    first_name: '',
    last_name: '',
    inmate_number: '',
    birth_date: '',
    citizenship: 'Polska',
    crime_type: '',
    security_level: 'low'
  });

  useEffect(() => {
    fetchInmates();
  }, []);

  const fetchInmates = async () => {
    try {
      const response = await fetch('/api/inmates', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await response.json();
      setInmates(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleAdmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/inmates', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(newInmate)
      });
      if (response.ok) {
        setShowAdmitModal(false);
        fetchInmates();
        setNewInmate({
          first_name: '',
          last_name: '',
          inmate_number: '',
          birth_date: '',
          citizenship: 'Polska',
          crime_type: '',
          security_level: 'low'
        });
      } else {
        const error = await response.json();
        alert(error.message || 'Błąd podczas przyjmowania osadzonego');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleRelease = async (id: number, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!confirm('CZY NA PEWNO CHCESZ WYPISAĆ (USUNĄĆ) TEGO OSADZONEGO Z SYSTEMU?')) return;

    try {
      const response = await fetch(`/api/inmates/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      if (response.ok) {
        fetchInmates();
      } else {
        const error = await response.json();
        alert(error.message || 'Błąd podczas wypisywania osadzonego');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const filteredInmates = inmates.filter(i => 
    `${i.first_name} ${i.last_name} ${i.inmate_number}`.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-4xl font-bold tracking-tighter uppercase mb-2">Kartoteka Osadzonych</h2>
          <p className="text-sm font-mono uppercase tracking-widest opacity-50">Zarządzanie bazą danych osób przebywających w jednostce</p>
        </div>
        <button 
          onClick={() => setShowAdmitModal(true)}
          className="px-6 py-3 bg-[#141414] text-[#E4E3E0] text-xs font-bold uppercase tracking-widest hover:bg-black transition-all flex items-center gap-2"
        >
          <Plus className="w-4 h-4" /> Przyjmij Nowego Więźnia
        </button>
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 opacity-30" />
          <input
            type="text"
            placeholder="SZUKAJ PO NAZWISKU LUB NUMERZE ID..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-white border border-[#141414] py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-[#141414]/10 transition-all font-mono text-sm uppercase"
          />
        </div>
        <button className="px-8 py-4 bg-white border border-[#141414] flex items-center gap-3 text-xs font-bold uppercase tracking-widest hover:bg-[#141414]/5 transition-all">
          <Filter className="w-4 h-4" /> Filtry
        </button>
      </div>

      {/* Inmates List */}
      <div className="bg-white border border-[#141414] overflow-hidden">
        <div className="grid grid-cols-12 bg-[#141414] text-[#E4E3E0] p-4 text-[10px] font-mono uppercase tracking-widest">
          <div className="col-span-1">ID</div>
          <div className="col-span-3">Imię i Nazwisko</div>
          <div className="col-span-2">Oddział / Cela</div>
          <div className="col-span-2">Poziom Bezp.</div>
          <div className="col-span-2">Typ Przestępstwa</div>
          <div className="col-span-2 text-right">Akcje</div>
        </div>

        <div className="divide-y divide-[#141414]/10">
          {loading ? (
            <div className="p-12 text-center text-xs font-mono uppercase opacity-50">Pobieranie danych...</div>
          ) : filteredInmates.length === 0 ? (
            <div className="p-12 text-center text-xs font-mono uppercase opacity-50">Nie znaleziono osadzonych spełniających kryteria</div>
          ) : filteredInmates.map((inmate) => (
            <Link 
              key={inmate.id} 
              to={`/inmates/${inmate.id}`}
              className="grid grid-cols-12 p-6 hover:bg-[#141414]/5 transition-colors items-center group"
            >
              <div className="col-span-1 font-mono text-xs font-bold">{inmate.inmate_number}</div>
              <div className="col-span-3 flex items-center gap-3">
                <div className="w-10 h-10 bg-[#141414]/5 flex items-center justify-center border border-[#141414]/10">
                  <UserIcon className="w-5 h-5 opacity-30" />
                </div>
                <span className="font-bold uppercase tracking-tight">{inmate.first_name} {inmate.last_name}</span>
              </div>
              <div className="col-span-2">
                <div className="text-xs font-bold">{inmate.ward_name || 'BRAK'}</div>
                <div className="text-[10px] font-mono uppercase opacity-50">{inmate.cell_number || 'NIEPRZYPISANY'}</div>
              </div>
              <div className="col-span-2">
                <span className={`px-2 py-1 text-[10px] font-mono uppercase tracking-widest border ${
                  inmate.security_level === 'high' ? 'bg-red-50 border-red-200 text-red-700' :
                  inmate.security_level === 'medium' ? 'bg-amber-50 border-amber-200 text-amber-700' :
                  'bg-emerald-50 border-emerald-200 text-emerald-700'
                }`}>
                  {inmate.security_level}
                </span>
              </div>
              <div className="col-span-2 text-xs opacity-70 uppercase tracking-tight">{inmate.crime_type || 'BRAK DANYCH'}</div>
              <div className="col-span-2 flex justify-end gap-2">
                <button 
                  onClick={(e) => handleRelease(inmate.id, e)}
                  title="Wypisz więźnia"
                  className="p-2 text-red-600 hover:bg-red-50 border border-transparent hover:border-red-200 transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
                <ChevronRight className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Admit Modal */}
      {showAdmitModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#141414] w-full max-w-2xl overflow-hidden">
            <div className="bg-[#141414] text-[#E4E3E0] p-6 flex justify-between items-center">
              <h3 className="text-xl font-bold uppercase tracking-tighter">Przyjmowanie Nowego Więźnia</h3>
              <button onClick={() => setShowAdmitModal(false)} className="hover:opacity-70">
                <X className="w-6 h-6" />
              </button>
            </div>
            <form onSubmit={handleAdmit} className="p-8 space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-mono uppercase tracking-widest opacity-50">Imię</label>
                  <input
                    required
                    type="text"
                    value={newInmate.first_name}
                    onChange={(e) => setNewInmate({...newInmate, first_name: e.target.value})}
                    className="w-full border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-[#141414]/10"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-mono uppercase tracking-widest opacity-50">Nazwisko</label>
                  <input
                    required
                    type="text"
                    value={newInmate.last_name}
                    onChange={(e) => setNewInmate({...newInmate, last_name: e.target.value})}
                    className="w-full border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-[#141414]/10"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-mono uppercase tracking-widest opacity-50">Numer Inmate ID</label>
                  <input
                    required
                    type="text"
                    placeholder="np. 2026/005"
                    value={newInmate.inmate_number}
                    onChange={(e) => setNewInmate({...newInmate, inmate_number: e.target.value})}
                    className="w-full border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-[#141414]/10"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-mono uppercase tracking-widest opacity-50">Data Urodzenia</label>
                  <input
                    required
                    type="date"
                    value={newInmate.birth_date}
                    onChange={(e) => setNewInmate({...newInmate, birth_date: e.target.value})}
                    className="w-full border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-[#141414]/10"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-mono uppercase tracking-widest opacity-50">Typ Przestępstwa</label>
                <input
                  required
                  type="text"
                  value={newInmate.crime_type}
                  onChange={(e) => setNewInmate({...newInmate, crime_type: e.target.value})}
                  className="w-full border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-[#141414]/10"
                />
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-mono uppercase tracking-widest opacity-50">Poziom Bezpieczeństwa</label>
                  <select
                    value={newInmate.security_level}
                    onChange={(e) => setNewInmate({...newInmate, security_level: e.target.value})}
                    className="w-full border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-[#141414]/10"
                  >
                    <option value="low">Niski (Minimum)</option>
                    <option value="medium">Średni (Medium)</option>
                    <option value="high">Wysoki (Maximum)</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-mono uppercase tracking-widest opacity-50">Obywatelstwo</label>
                  <input
                    type="text"
                    value={newInmate.citizenship}
                    onChange={(e) => setNewInmate({...newInmate, citizenship: e.target.value})}
                    className="w-full border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-[#141414]/10"
                  />
                </div>
              </div>

              <div className="pt-6 flex gap-4">
                <button
                  type="button"
                  onClick={() => setShowAdmitModal(false)}
                  className="flex-1 py-4 border border-[#141414] text-xs font-bold uppercase tracking-widest hover:bg-[#141414]/5 transition-all"
                >
                  Anuluj
                </button>
                <button
                  type="submit"
                  className="flex-1 py-4 bg-[#141414] text-[#E4E3E0] text-xs font-bold uppercase tracking-widest hover:bg-black transition-all"
                >
                  Zatwierdź Przyjęcie
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

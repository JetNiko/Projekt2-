import { useState, useEffect } from "react";
import { LayoutDashboard, Users, Grid, Calendar, ShieldAlert, Search, Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

type Inmate = {
  id: number;
  first_name: string;
  last_name: string;
  block_id: number;
  block_name: string;
  cell_number: string;
  status: string;
  date_of_birth: string;
  sentence_end: string;
  crime: string;
  rehabilitation_plan: string;
};

type BlockStat = {
  name: string;
  capacity: number;
  current_occupancy: number;
};

type Routine = {
  id: number;
  activity_name: string;
  start_time: string;
  end_time: string;
};

export default function App() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [stats, setStats] = useState<{ totalInmates: number; blockStats: BlockStat[] } | null>(null);
  const [inmates, setInmates] = useState<Inmate[]>([]);
  const [blocks, setBlocks] = useState<any[]>([]);
  const [routines, setRoutines] = useState<Routine[]>([]);
  const [selectedBlockId, setSelectedBlockId] = useState<number>(1);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedInmate, setSelectedInmate] = useState<Inmate | null>(null);

  useEffect(() => {
    fetchStats();
    fetchInmates();
    fetchBlocks();
  }, []);

  useEffect(() => {
    if (activeTab === "routine") {
      fetchRoutine(selectedBlockId);
    }
  }, [activeTab, selectedBlockId]);

  const fetchStats = async () => {
    const res = await fetch("/api/stats");
    const data = await res.json();
    setStats(data);
  };

  const fetchInmates = async () => {
    const res = await fetch("/api/inmates");
    const data = await res.json();
    setInmates(data);
  };

  const fetchBlocks = async () => {
    const res = await fetch("/api/blocks");
    const data = await res.json();
    setBlocks(data);
  };

  const fetchRoutine = async (blockId: number) => {
    const res = await fetch(`/api/routines/${blockId}`);
    const data = await res.json();
    setRoutines(data);
  };

  const filteredInmates = inmates.filter(i => 
    `${i.first_name} ${i.last_name}`.toLowerCase().includes(searchQuery.toLowerCase()) ||
    i.cell_number.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar */}
      <div className="w-64 border-r border-black flex flex-col bg-[#E4E3E0]">
        <div className="p-8 border-bottom border-black">
          <h1 className="font-serif italic text-2xl tracking-tighter">PrisonOS</h1>
          <p className="text-[10px] uppercase tracking-widest opacity-50 font-mono">v1.0.4 - System Zarządzania</p>
        </div>
        
        <nav className="flex-1">
          <SidebarItem 
            icon={<LayoutDashboard size={18} />} 
            label="Panel Główny" 
            active={activeTab === "dashboard"} 
            onClick={() => setActiveTab("dashboard")} 
          />
          <SidebarItem 
            icon={<Users size={18} />} 
            label="Osadzeni" 
            active={activeTab === "inmates"} 
            onClick={() => setActiveTab("inmates")} 
          />
          <SidebarItem 
            icon={<Grid size={18} />} 
            label="Bloki Mieszkalne" 
            active={activeTab === "blocks"} 
            onClick={() => setActiveTab("blocks")} 
          />
          <SidebarItem 
            icon={<Calendar size={18} />} 
            label="Harmonogram" 
            active={activeTab === "routine"} 
            onClick={() => setActiveTab("routine")} 
          />
        </nav>

        <div className="p-4 border-t border-black">
          <div className="flex items-center gap-2 text-red-600 font-mono text-[10px] uppercase">
            <ShieldAlert size={14} />
            <span>Stan: Wysoki Alert</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto bg-[#E4E3E0] p-8 relative">
        <AnimatePresence mode="wait">
          {activeTab === "dashboard" && (
            <motion.div 
              key="dashboard"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-8"
            >
              <div className="flex justify-between items-end">
                <div>
                  <h2 className="font-serif italic text-4xl">Przegląd Systemu</h2>
                  <p className="text-xs uppercase tracking-widest opacity-50">Dane z dnia: {new Date().toLocaleDateString('pl-PL')}</p>
                </div>
                <div className="text-right">
                  <span className="text-6xl font-mono tracking-tighter">{stats?.totalInmates || 0}</span>
                  <p className="text-[10px] uppercase tracking-widest opacity-50">Całkowita liczba osadzonych</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {stats?.blockStats.map((block, idx) => (
                  <div key={idx} className="border border-black p-6 space-y-4">
                    <div className="flex justify-between items-start">
                      <h3 className="font-serif italic text-xl">{block.name}</h3>
                      <span className="font-mono text-xs opacity-50">0{idx + 1}</span>
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] uppercase font-mono">
                        <span>Obłożenie</span>
                        <span>{Math.round((block.current_occupancy / block.capacity) * 100)}%</span>
                      </div>
                      <div className="h-1 bg-black/10 w-full">
                        <div 
                          className="h-full bg-black transition-all duration-500" 
                          style={{ width: `${(block.current_occupancy / block.capacity) * 100}%` }}
                        />
                      </div>
                      <p className="text-[10px] font-mono opacity-50">{block.current_occupancy} / {block.capacity} miejsc</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="border border-black">
                <div className="p-4 border-b border-black flex justify-between items-center">
                  <span className="col-header">Ostatnie Incydenty</span>
                  <span className="text-[10px] uppercase font-mono opacity-50">Brak nowych zgłoszeń</span>
                </div>
                <div className="p-12 text-center opacity-30 italic font-serif">
                  Wszystkie systemy działają poprawnie. Ostatni raport bezpieczeństwa: 02:30 AM.
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === "inmates" && (
            <motion.div 
              key="inmates"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <div className="flex justify-between items-center">
                <h2 className="font-serif italic text-4xl">Rejestr Osadzonych</h2>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 opacity-30" size={16} />
                  <input 
                    type="text" 
                    placeholder="SZUKAJ (NAZWISKO / CELA)..."
                    className="bg-transparent border border-black pl-10 pr-4 py-2 text-xs font-mono focus:outline-none w-64"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>

              <div className="border border-black">
                <div className="data-row bg-black text-white cursor-default hover:bg-black">
                  <span className="col-header text-white/50">ID</span>
                  <span className="col-header text-white/50">Imię i Nazwisko</span>
                  <span className="col-header text-white/50">Blok / Cela</span>
                  <span className="col-header text-white/50">Status</span>
                </div>
                {filteredInmates.map((inmate) => (
                  <div 
                    key={inmate.id} 
                    className="data-row"
                    onClick={() => setSelectedInmate(inmate)}
                  >
                    <span className="data-value opacity-50">#{inmate.id}</span>
                    <span className="font-medium">{inmate.last_name}, {inmate.first_name}</span>
                    <span className="data-value">{inmate.block_name.split(' ')[1]} / {inmate.cell_number}</span>
                    <span className="text-[10px] uppercase font-mono flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-green-600" />
                      {inmate.status}
                    </span>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {activeTab === "blocks" && (
            <motion.div 
              key="blocks"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-8"
            >
              <h2 className="font-serif italic text-4xl">Bloki Mieszkalne</h2>
              <div className="grid grid-cols-1 gap-12">
                {stats?.blockStats.map((block, idx) => (
                  <div key={idx} className="space-y-4">
                    <div className="flex justify-between items-end border-b border-black pb-2">
                      <h3 className="font-serif italic text-2xl">{block.name}</h3>
                      <span className="font-mono text-xs uppercase opacity-50">Pojemność: {block.capacity}</span>
                    </div>
                    <div className="grid grid-cols-10 gap-2">
                      {Array.from({ length: block.capacity }).map((_, i) => {
                        const isOccupied = i < block.current_occupancy;
                        return (
                          <div 
                            key={i} 
                            className={`aspect-square border border-black/20 flex items-center justify-center text-[8px] font-mono ${isOccupied ? 'bg-black text-white' : 'opacity-20'}`}
                          >
                            {i + 1}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {activeTab === "routine" && (
            <motion.div 
              key="routine"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-8"
            >
              <div className="flex justify-between items-center">
                <h2 className="font-serif italic text-4xl">Harmonogram Dnia</h2>
                <select 
                  className="bg-transparent border border-black px-4 py-2 text-xs font-mono focus:outline-none"
                  value={selectedBlockId}
                  onChange={(e) => setSelectedBlockId(Number(e.target.value))}
                >
                  {blocks.map(b => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </select>
              </div>

              <div className="border border-black">
                {routines.map((item, idx) => (
                  <div key={idx} className="grid grid-cols-[150px_1fr] border-b border-black last:border-0">
                    <div className="p-6 border-r border-black font-mono text-xs flex flex-col justify-center">
                      <span className="opacity-50">OD: {item.start_time}</span>
                      <span>DO: {item.end_time}</span>
                    </div>
                    <div className="p-6 flex items-center justify-between">
                      <span className="font-serif italic text-xl">{item.activity_name}</span>
                      <span className="text-[10px] uppercase font-mono opacity-30">Status: Zaplanowane</span>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Inmate Detail Modal */}
        <AnimatePresence>
          {selectedInmate && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
              onClick={() => setSelectedInmate(null)}
            >
              <motion.div 
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="bg-[#E4E3E0] border border-black w-full max-w-2xl overflow-hidden shadow-2xl"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="p-8 border-b border-black flex justify-between items-start">
                  <div>
                    <span className="text-[10px] font-mono uppercase opacity-50 tracking-widest">Karta Osadzonego #{selectedInmate.id}</span>
                    <h2 className="font-serif italic text-4xl mt-1">{selectedInmate.first_name} {selectedInmate.last_name}</h2>
                  </div>
                  <button onClick={() => setSelectedInmate(null)} className="hover:rotate-90 transition-transform">
                    <X size={24} />
                  </button>
                </div>

                <div className="p-8 grid grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <DetailGroup label="Data Urodzenia" value={selectedInmate.date_of_birth} />
                    <DetailGroup label="Lokalizacja" value={`${selectedInmate.block_name} / Cela ${selectedInmate.cell_number}`} />
                    <DetailGroup label="Koniec Wyroku" value={selectedInmate.sentence_end} />
                    <DetailGroup label="Przestępstwo" value={selectedInmate.crime} />
                  </div>
                  <div className="space-y-6">
                    <div>
                      <span className="text-[10px] font-mono uppercase opacity-50 block mb-2">Plan Resocjalizacji</span>
                      <div className="p-4 border border-black/20 bg-black/5 font-serif italic text-sm leading-relaxed">
                        {selectedInmate.rehabilitation_plan}
                      </div>
                    </div>
                    <div className="pt-4">
                      <span className="text-[10px] font-mono uppercase opacity-50 block mb-2">Status Dyscyplinarny</span>
                      <div className="flex items-center gap-2 text-green-700 font-mono text-xs uppercase">
                        <div className="w-2 h-2 rounded-full bg-green-600 animate-pulse" />
                        Brak aktywnych naruszeń
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-black text-white flex justify-between items-center font-mono text-[10px] uppercase">
                  <span>Wydrukowano: {new Date().toLocaleString()}</span>
                  <span>Autoryzacja: System Centralny</span>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

function DetailGroup({ label, value }: { label: string, value: string }) {
  return (
    <div>
      <span className="text-[10px] font-mono uppercase opacity-50 block">{label}</span>
      <span className="font-medium text-lg">{value}</span>
    </div>
  );
}

function SidebarItem({ icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) {
  return (
    <div 
      className={`sidebar-item flex items-center gap-4 ${active ? 'active' : ''}`}
      onClick={onClick}
    >
      {icon}
      <span>{label}</span>
    </div>
  );
}

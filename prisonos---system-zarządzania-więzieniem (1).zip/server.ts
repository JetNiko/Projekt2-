import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("prison.db");

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS blocks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    capacity INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS inmates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    block_id INTEGER,
    cell_number TEXT,
    status TEXT DEFAULT 'active',
    date_of_birth TEXT,
    sentence_end TEXT,
    crime TEXT,
    rehabilitation_plan TEXT,
    FOREIGN KEY (block_id) REFERENCES blocks(id)
  );

  CREATE TABLE IF NOT EXISTS routines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    block_id INTEGER,
    activity_name TEXT NOT NULL,
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    FOREIGN KEY (block_id) REFERENCES blocks(id)
  );

  CREATE TABLE IF NOT EXISTS incidents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    inmate_id INTEGER,
    description TEXT NOT NULL,
    date TEXT NOT NULL,
    FOREIGN KEY (inmate_id) REFERENCES inmates(id)
  );
`);

// Seed Data if empty
const blockCount = db.prepare("SELECT count(*) as count FROM blocks").get() as { count: number };
if (blockCount.count === 0) {
  const insertBlock = db.prepare("INSERT INTO blocks (name, capacity) VALUES (?, ?)");
  insertBlock.run("Blok A (Maksymalny rygor)", 50);
  insertBlock.run("Blok B (Średni rygor)", 100);
  insertBlock.run("Blok C (Minimalny rygor)", 80);

  const insertInmate = db.prepare("INSERT INTO inmates (first_name, last_name, block_id, cell_number, date_of_birth, sentence_end, crime, rehabilitation_plan) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
  
  const sampleInmates = [
    ["Jan", "Kowalski", 1, "A-101", "1985-05-12", "2035-12-01", "Napad z bronią", "Program resocjalizacji przez pracę stolarską."],
    ["Adam", "Nowak", 1, "A-102", "1992-08-22", "2028-06-15", "Kradzież mienia", "Terapia uzależnień i nauka zawodu."],
    ["Piotr", "Wiśniewski", 2, "B-205", "1978-11-30", "2026-03-10", "Oszustwa podatkowe", "Praca w bibliotece więziennej."],
    ["Marek", "Zieliński", 3, "C-301", "1995-02-14", "2025-09-20", "Zakłócanie porządku", "Zajęcia sportowe i wolontariat."],
    ["Robert", "Lewandowski", 1, "A-103", "1988-01-05", "2040-01-01", "Zabójstwo", "Izolacja i terapia behawioralna."],
    ["Tomasz", "Wójcik", 2, "B-206", "1982-07-19", "2027-11-11", "Handel narkotykami", "Program 'Czysty start'."],
    ["Krzysztof", "Kamiński", 2, "B-207", "1990-12-25", "2029-04-05", "Włamanie", "Kurs informatyczny poziomu podstawowego."],
    ["Andrzej", "Włodarczyk", 3, "C-302", "1975-03-08", "2025-12-31", "Jazda pod wpływem", "Prace porządkowe na terenie zakładu."],
    ["Michał", "Lewczyk", 1, "A-104", "1998-09-15", "2032-05-20", "Rozbój", "Zajęcia z psychologiem."],
    ["Paweł", "Szymański", 3, "C-303", "1984-06-10", "2026-01-15", "Alimenty", "Praca w kuchni."],
    ["Jakub", "Dąbrowski", 2, "B-208", "1991-10-02", "2028-08-12", "Paserstwo", "Nauka języka angielskiego."],
    ["Marcin", "Kozłowski", 1, "A-105", "1980-04-25", "2045-03-18", "Terroryzm", "Ścisły nadzór psychologiczny."],
    ["Łukasz", "Mazur", 3, "C-304", "1993-11-12", "2025-10-05", "Drobna kradzież", "Zajęcia ogrodnicze."],
    ["Grzegorz", "Kwiatkowski", 2, "B-209", "1987-01-20", "2027-02-28", "Przemyt", "Program edukacyjny 'Horyzonty'."],
    ["Damian", "Krawczyk", 1, "A-106", "1996-05-30", "2038-07-14", "Podpalenie", "Terapia przeciwpożarowa."]
  ];

  sampleInmates.forEach(inmate => insertInmate.run(...inmate));

  const insertRoutine = db.prepare("INSERT INTO routines (block_id, activity_name, start_time, end_time) VALUES (?, ?, ?, ?)");
  [1, 2, 3].forEach(blockId => {
    insertRoutine.run(blockId, "Pobudka i apel", "06:00", "07:00");
    insertRoutine.run(blockId, "Śniadanie", "07:00", "08:00");
    insertRoutine.run(blockId, "Praca / Zajęcia", "08:00", "12:00");
    insertRoutine.run(blockId, "Obiad", "12:00", "13:00");
    insertRoutine.run(blockId, "Czas wolny / Spacerniak", "13:00", "16:00");
    insertRoutine.run(blockId, "Kolacja", "17:00", "18:00");
    insertRoutine.run(blockId, "Cisza nocna", "22:00", "06:00");
  });
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/stats", (req, res) => {
    const totalInmates = db.prepare("SELECT count(*) as count FROM inmates WHERE status = 'active'").get() as { count: number };
    const blockStats = db.prepare(`
      SELECT b.name, b.capacity, COUNT(i.id) as current_occupancy
      FROM blocks b
      LEFT JOIN inmates i ON b.id = i.block_id AND i.status = 'active'
      GROUP BY b.id
    `).all();
    res.json({ totalInmates: totalInmates.count, blockStats });
  });

  app.get("/api/inmates", (req, res) => {
    const inmates = db.prepare(`
      SELECT i.*, b.name as block_name 
      FROM inmates i 
      JOIN blocks b ON i.block_id = b.id
      ORDER BY i.last_name ASC
    `).all();
    res.json(inmates);
  });

  app.get("/api/blocks", (req, res) => {
    const blocks = db.prepare("SELECT * FROM blocks").all();
    res.json(blocks);
  });

  app.get("/api/routines/:blockId", (req, res) => {
    const routines = db.prepare("SELECT * FROM routines WHERE block_id = ? ORDER BY start_time ASC").all(req.params.blockId);
    res.json(routines);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();

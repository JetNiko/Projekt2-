-- Plik demonstracyjny SQL (dla PostgreSQL - np. pgAdmin)
-- Przedstawia strukturę bazy danych (ERD) dla aplikacji Prison.OS

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    role VARCHAR(20) NOT NULL, -- 'Admin', 'Manager', 'Strażnik'
    badge_number VARCHAR(20)
);

CREATE TABLE wards (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    security_level VARCHAR(20) NOT NULL
);

CREATE TABLE cells (
    id SERIAL PRIMARY KEY,
    ward_id INTEGER REFERENCES wards(id) ON DELETE CASCADE,
    cell_number VARCHAR(10) NOT NULL,
    capacity INTEGER NOT NULL DEFAULT 4,
    status VARCHAR(20) DEFAULT 'aktywna'
);

CREATE TABLE inmates (
    id SERIAL PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    prisoner_number VARCHAR(20) UNIQUE NOT NULL,
    cell_id INTEGER REFERENCES cells(id) ON DELETE SET NULL,
    security_level VARCHAR(20),
    behavior_score INTEGER DEFAULT 100,
    photo_url TEXT,
    fingerprint_url TEXT,
    routine TEXT,
    sentence_details TEXT
);

CREATE TABLE incidents (
    id SERIAL PRIMARY KEY,
    date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    location VARCHAR(100) NOT NULL,
    description TEXT,
    severity VARCHAR(20), -- 'Wysoka', 'Średnia', 'Niska'
    category VARCHAR(50)
);

CREATE TABLE visits (
    id SERIAL PRIMARY KEY,
    inmate_id INTEGER REFERENCES inmates(id) ON DELETE CASCADE,
    visitor_name VARCHAR(100) NOT NULL,
    relationship VARCHAR(50),
    date TIMESTAMP NOT NULL,
    status VARCHAR(20) DEFAULT 'Oczekująca'
);

CREATE TABLE messages (
    id SERIAL PRIMARY KEY,
    sender_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    sender_name VARCHAR(100),
    text TEXT NOT NULL,
    timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Indeksy do optymalizacji wyszukiwania
CREATE INDEX idx_inmates_prisoner_nr ON inmates(prisoner_number);
CREATE INDEX idx_cells_ward_id ON cells(ward_id);
CREATE INDEX idx_visits_inmate_id ON visits(inmate_id);
CREATE INDEX idx_messages_timestamp ON messages(timestamp DESC);

<?php
// Ten plik służy wyłącznie jako demonstracja (mock) dla prezentacji, 
// pokazująca jak wyglądałby eksport do PDF po stronie serwera w PHP.
// Właściwa aplikacja oparta jest na Node.js.

require('fpdf.php'); // Przykładowa biblioteka PDF w PHP

header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="raport_osadzeni.pdf"');

// Przykładowe połączenie z bazą danych PostgreSQL (PDO) dla demonstracji
// $dsn = "pgsql:host=localhost;port=5432;dbname=prison_db;user=postgres;password=haslo";
// $pdo = new PDO($dsn);

class PrisonReportPDF extends FPDF {
    function Header() {
        $this->SetFont('Arial', 'B', 15);
        $this->Cell(80);
        $this->Cell(30, 10, 'Raport Osadzonych - Prison.OS', 0, 0, 'C');
        $this->Ln(20);
    }
    
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Strona ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }
}

$pdf = new PrisonReportPDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

// Nagłówki tabeli
$pdf->SetFillColor(200, 200, 200);
$pdf->Cell(40, 10, 'Nr. Wiezna', 1, 0, 'C', true);
$pdf->Cell(50, 10, 'Imie i Nazwisko', 1, 0, 'C', true);
$pdf->Cell(40, 10, 'Poziom', 1, 0, 'C', true);
$pdf->Cell(40, 10, 'Cela', 1, 1, 'C', true);

// Przykładowe dane pobierane z bazy
/*
$stmt = $pdo->query("SELECT prisoner_number, first_name, last_name, security_level, cell_id FROM inmates");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $pdf->Cell(40, 10, $row['prisoner_number'], 1);
    $pdf->Cell(50, 10, $row['first_name'] . ' ' . $row['last_name'], 1);
    $pdf->Cell(40, 10, $row['security_level'], 1);
    $pdf->Cell(40, 10, $row['cell_id'], 1);
    $pdf->Ln();
}
*/

// Dodanie przykładowego wiersza dla demonstracji
$pdf->Cell(40, 10, 'INM-001', 1);
$pdf->Cell(50, 10, 'Jan Kowalski', 1);
$pdf->Cell(40, 10, 'Wysoki', 1);
$pdf->Cell(40, 10, '3', 1);
$pdf->Ln();

$pdf->Output('D', 'raport_osadzeni.pdf');
?>

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Routes, Route, Navigate, Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import React, { useState, useEffect } from 'react';
import { 
  Users, UserCheck, ShieldAlert, Grid, 
  UserPlus, FileText, Settings, LogOut, LayoutDashboard, MessageSquare 
} from 'lucide-react';
import { cn } from './lib/utils';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Inmates from './pages/Inmates';
import Staff from './pages/Staff';
import Wards from './pages/Wards';
import Incidents from './pages/Incidents';
import Visits from './pages/Visits';
import Reports from './pages/Reports';
import Chat from './pages/Chat';

// Auth State Provider Equivalent
export function ProtectedRoute({ children, allowedRoles }: { children: React.ReactNode, allowedRoles?: string[] }) {
  const token = localStorage.getItem('token');
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  if (!token) return <Navigate to="/login" />;
  if (allowedRoles && !allowedRoles.includes(user.role)) return <Navigate to="/" />;

  return <>{children}</>;
}

function Sidebar() {
  const location = useLocation();
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  const navItems = [
    { name: 'Dashboard', path: '/', icon: LayoutDashboard },
    { name: 'Osadzeni', path: '/inmates', icon: Users },
    { name: 'Personel', path: '/staff', icon: UserCheck, roles: ['Admin', 'Director'] },
    { name: 'Incydenty', path: '/incidents', icon: ShieldAlert },
    { name: 'Oddziały i Cele', path: '/wards', icon: Grid },
    { name: 'Widzenia', path: '/visits', icon: UserPlus },
    { name: 'Czat Wewnętrzny', path: '/chat', icon: MessageSquare },
    { name: 'Raporty', path: '/reports', icon: FileText },
  ];

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <div className="flex flex-col w-64 bg-zinc-950 border-r border-zinc-800 h-screen text-zinc-300">
      <div className="flex items-center h-16 px-6 font-bold text-lg text-white border-b border-zinc-800 gap-3">
        <div className="w-8 h-8 bg-amber-600 rounded flex items-center justify-center font-bold text-zinc-950 text-xs">PR</div>
        <div>
          <h1 className="text-sm font-bold text-white uppercase tracking-widest leading-none">Prison.OS</h1>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto py-6">
        <nav className="space-y-2 px-4">
          <div className="text-[10px] text-zinc-500 uppercase font-bold mb-4">Nawigacja</div>
          {navItems.filter(item => !item.roles || item.roles.includes(user.role)).map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.name}
                to={item.path}
                className={cn(
                  "flex items-center gap-3 text-sm px-4 py-3 rounded-lg transition-colors",
                  isActive 
                    ? "bg-zinc-900 border border-zinc-800 text-amber-500" 
                    : "hover:bg-zinc-900 text-zinc-300"
                )}
              >
                <Icon className="h-4 w-4" />
                {item.name}
              </Link>
            )
          })}
        </nav>
      </div>
      <div className="p-4 border-t border-zinc-800 flex items-center justify-between">
        <div className="flex items-center gap-3 text-sm">
          <div className="w-8 h-8 bg-zinc-700 rounded-full flex items-center justify-center text-xs text-white">
            {user.username ? user.username.slice(0,2).toUpperCase() : 'AD'}
          </div>
          <div>
            <p className="text-white font-bold text-xs">{user.name}</p>
            <p className="text-[10px] text-zinc-500 uppercase">{user.role}</p>
          </div>
        </div>
        <button onClick={handleLogout} className="p-2 text-zinc-500 hover:text-amber-500 rounded-lg hover:bg-zinc-800">
          <LogOut className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

function Layout() {
  return (
    <div className="flex h-screen bg-zinc-950 font-sans text-zinc-300 overflow-hidden">
      <Sidebar />
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <div className="flex-1 overflow-y-auto p-8 relative space-y-6">
          <Outlet />
        </div>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        
        <Route element={<ProtectedRoute><Layout /></ProtectedRoute>}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/inmates" element={<Inmates />} />
          <Route path="/staff" element={<Staff />} />
          <Route path="/wards" element={<Wards />} />
          <Route path="/incidents" element={<Incidents />} />
          <Route path="/visits" element={<Visits />} />
          <Route path="/chat" element={<Chat />} />
          <Route path="/reports" element={<Reports />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

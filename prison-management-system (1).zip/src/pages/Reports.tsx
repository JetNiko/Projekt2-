import { useState, useEffect } from 'react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Download } from 'lucide-react';

export default function Reports() {
  const [inmates, setInmates] = useState<any[]>([]);
  const [incidents, setIncidents] = useState<any[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      const auth = { headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }};
      const resInmates = await fetch('/api/inmates', auth);
      if (resInmates.ok) setInmates(await resInmates.json());

      const resIncidents = await fetch('/api/incidents', auth);
      if (resIncidents.ok) setIncidents(await resIncidents.json());
    };
    fetchData();
  }, []);

  const exportInmatesPDF = () => {
    const doc = new jsPDF() as any;
    doc.text("Raport: Lista Osadzonych", 14, 15);
    
    const tableColumn = ["Nr.", "Imię", "Nazwisko", "Poziom BZ", "Cela"];
    const tableRows = inmates.map(i => [i.prisoner_number, i.first_name, i.last_name, i.security_level, i.cell_id.toString()]);

    autoTable(doc, { head: [tableColumn], body: tableRows, startY: 20 });
    doc.save("raport_osadzeni.pdf");
  };

  const exportIncidentsPDF = () => {
    const doc = new jsPDF() as any;
    doc.text("Raport: Lista Incydentow", 14, 15);
    
    const tableColumn = ["Data", "Lokalizacja", "Kategoria", "Waga", "Opis"];
    const tableRows = incidents.map(i => [i.date, i.location, i.category, i.severity, i.description]);

    autoTable(doc, { head: [tableColumn], body: tableRows, startY: 20 });
    doc.save("raport_incydenty.pdf");
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col mb-6"> 
        <span className="text-[10px] uppercase tracking-[0.2em] text-zinc-500">Dokumentacja</span>
        <h1 className="text-2xl font-medium text-white">Generowanie Raportów</h1>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bento-card flex flex-col items-center text-center p-8">
          <div className="p-4 bg-zinc-800 text-amber-500 rounded-full mb-4">
            <Download className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-white mb-2">Raport Osadzonych (PDF)</h3>
          <p className="text-zinc-500 mb-6 text-xs">Oficjalny raport do druku dla administracji więziennej ze wszystkimi więźniami i ich szczegółami.</p>
          <button onClick={exportInmatesPDF} className="px-6 py-2 bg-amber-600 text-zinc-950 font-bold uppercase text-[10px] tracking-wider rounded border border-amber-500 hover:bg-amber-500 transition-colors w-full max-w-[200px]">Pobierz PDF</button>
        </div>

        <div className="bento-card flex flex-col items-center text-center p-8">
          <div className="p-4 bg-zinc-800 text-red-500 rounded-full mb-4">
            <Download className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-white mb-2">Raport Incydentów (PDF)</h3>
          <p className="text-zinc-500 mb-6 text-xs">Raport dla przełożonych zawierający listę wszystkich zdarzeń oraz incydentów dyscyplinarnych.</p>
          <button onClick={exportIncidentsPDF} className="px-6 py-2 bg-zinc-800 border border-zinc-700 text-white font-bold uppercase text-[10px] tracking-wider rounded hover:bg-zinc-700 transition-colors w-full max-w-[200px]">Pobierz PDF</button>
        </div>
      </div>
    </div>
  );
}

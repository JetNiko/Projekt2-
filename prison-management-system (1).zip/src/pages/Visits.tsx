import { useState, useEffect } from 'react';

export default function Visits() {
  const [visits, setVisits] = useState<any[]>([]);

  useEffect(() => {
    const fetchVisits = async () => {
      const res = await fetch('/api/visits', { headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }});
      if (res.ok) setVisits(await res.json());
    };
    fetchVisits();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex flex-col mb-6"> 
        <span className="text-[10px] uppercase tracking-[0.2em] text-zinc-500">Logi</span>
        <h1 className="text-2xl font-medium text-white">Rejestr Widzeń</h1>
      </div>
      <div className="bento-card p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-zinc-950 text-zinc-500 text-[10px] uppercase tracking-wider border-b border-zinc-800">
              <tr>
                <th className="px-6 py-4 font-bold">Data</th>
                <th className="px-6 py-4 font-bold">Osadzony</th>
                <th className="px-6 py-4 font-bold">Odwiedzający</th>
                <th className="px-6 py-4 font-bold">Relacja</th>
                <th className="px-6 py-4 font-bold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800 bg-zinc-900">
              {visits.map(v => (
                <tr key={v.id} className="hover:bg-zinc-800/50 transition-colors">
                  <td className="px-6 py-4 text-xs text-zinc-400 mono">{new Date(v.date).toLocaleString()}</td>
                  <td className="px-6 py-4 text-sm font-bold text-white">{v.first_name} {v.last_name}</td>
                  <td className="px-6 py-4 text-sm text-zinc-300">{v.visitor_name}</td>
                  <td className="px-6 py-4 text-xs text-zinc-500">{v.relationship}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 text-[10px] font-bold uppercase tracking-wider rounded border ${v.status === 'Zatwierdzone' ? 'bg-green-500/10 text-green-500 border-green-500/30' : 'bg-amber-500/10 text-amber-500 border-amber-500/30'}`}>
                      {v.status}
                    </span>
                  </td>
                </tr>
              ))}
              {visits.length === 0 && <tr><td colSpan={5} className="p-6 text-center text-zinc-500 text-sm">Brak zaplanowanych widzeń</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

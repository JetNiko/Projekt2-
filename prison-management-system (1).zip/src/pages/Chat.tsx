import React, { useState, useEffect, useRef } from 'react';
import { Send } from 'lucide-react';

export default function Chat() {
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const fetchMessages = async () => {
    try {
      const res = await fetch('/api/messages', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await res.json();
      setMessages(data);
    } catch(e) { console.error(e); }
  };

  useEffect(() => {
    fetchMessages();
    const interval = setInterval(fetchMessages, 3000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    try {
      await fetch('/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ text: newMessage })
      });
      setNewMessage('');
      fetchMessages();
    } catch(e) { console.error(e); }
  };

  const currentUserId = JSON.parse(atob(localStorage.getItem('token')!.split('.')[1])).id;

  return (
    <div className="flex flex-col h-full space-y-6 max-h-[calc(100vh-6rem)]">
      <div className="flex flex-col mb-2 shrink-0"> 
        <span className="text-[10px] uppercase tracking-[0.2em] text-zinc-500">Komunikacja</span>
        <h1 className="text-2xl font-medium text-white">Czat Wewnętrzny</h1>
      </div>

      <div className="bento-card p-0 flex flex-col flex-1 overflow-hidden h-full">
        <div className="flex-1 p-6 overflow-y-auto space-y-4">
          {messages.map((msg, idx) => {
            const isMe = msg.sender_id === currentUserId;
            return (
              <div key={idx} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                <span className="text-[10px] text-zinc-500 mb-1 px-1">{msg.sender_name} • {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                <div className={`px-4 py-2 rounded max-w-[70%] text-sm ${isMe ? 'bg-amber-600 text-zinc-950 font-medium' : 'bg-zinc-800 text-zinc-200 border border-zinc-700'}`}>
                  {msg.text}
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>
        
        <form onSubmit={handleSend} className="p-4 border-t border-zinc-800 bg-zinc-900 flex gap-4 shrink-0">
          <input
            type="text"
            className="flex-1 bg-zinc-950 border border-zinc-800 rounded px-4 focus:outline-none focus:border-amber-500 text-white"
            placeholder="Napisz wiadomość..."
            value={newMessage}
            onChange={e => setNewMessage(e.target.value)}
          />
          <button type="submit" className="p-3 bg-amber-600 text-zinc-950 rounded hover:bg-amber-500 transition-colors flex items-center justify-center">
            <Send className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
}

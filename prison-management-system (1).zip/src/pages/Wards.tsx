import { useState, useEffect } from 'react';

export default function Wards() {
  const [wards, setWards] = useState<any[]>([]);

  useEffect(() => {
    const fetchWards = async () => {
      const res = await fetch('/api/wards', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      if (res.ok) setWards(await res.json());
    };
    fetchWards();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex flex-col mb-6"> 
        <span className="text-[10px] uppercase tracking-[0.2em] text-zinc-500">Mapa</span>
        <h1 className="text-2xl font-medium text-white">Infrastruktura (Oddziały i Cele)</h1>
      </div>
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {wards.map(ward => (
          <div key={ward.id} className="bento-card p-0 overflow-hidden relative">
            <div className="p-4 border-b border-zinc-800 flex justify-between items-center bg-zinc-900">
              <div>
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">{ward.name}</h2>
                <p className="text-[10px] text-zinc-500 uppercase mt-1">Zagrożenie: {ward.security_level}</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Liczba cel: {ward.cells?.length || 0}</p>
              </div>
            </div>
            <div className="p-4 grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
              {ward.cells?.map((cell: any) => (
                <div key={cell.id} className={`border rounded p-3 text-center transition-colors 
                  ${ward.security_level === 'Izolatka' || ward.security_level === 'Krytyczny' ? 'bg-zinc-800/50 border-zinc-700' :
                  ward.security_level === 'Wysoki' ? 'border-red-900/30 bg-zinc-900' :
                  'bg-zinc-900 border-zinc-800 hover:border-amber-500/50'}`}>
                  <p className="font-bold text-white text-sm mono">{cell.cell_number}</p>
                  <p className="text-[10px] text-zinc-500 mt-1 uppercase">Poj: {cell.capacity}</p>
                  <span className={`inline-block mt-2 px-2 py-0.5 text-[8px] rounded uppercase font-bold tracking-wider
                    ${cell.status === 'aktywna' ? 'bg-green-500/10 text-green-500 border border-green-500/30' : 'bg-red-500/10 text-red-500 border border-red-500/30'}  
                  `}>
                    {cell.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

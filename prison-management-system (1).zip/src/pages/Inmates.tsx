import React, { useState, useEffect } from 'react';
import { Search, Plus, X, Edit, Trash2, UserMinus, Image as ImageIcon } from 'lucide-react';

export default function Inmates() {
  const [inmates, setInmates] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedInmate, setSelectedInmate] = useState<any>(null);
  const [isEditing, setIsEditing] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    first_name: '', last_name: '', prisoner_number: '', cell_id: 1, 
    security_level: 'Niski', routine: '', sentence_details: ''
  });

  const fetchInmates = async () => {
    const res = await fetch('/api/inmates', {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    });
    if (res.ok) setInmates(await res.json());
  };

  useEffect(() => { fetchInmates(); }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/inmates', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}` 
      },
      body: JSON.stringify(formData)
    });
    if (res.ok) {
      setShowAddForm(false);
      fetchInmates();
    }
  };

  const handleDelete = async (id: number) => {
    if(!confirm('Czy na pewno chcesz usunąć dane tego osadzonego?')) return;
    const res = await fetch(`/api/inmates/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    });
    if (res.ok) {
      setSelectedInmate(null);
      fetchInmates();
    }
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch(`/api/inmates/${selectedInmate.id}`, {
      method: 'PUT',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}` 
      },
      body: JSON.stringify(formData)
    });
    if (res.ok) {
      setIsEditing(false);
      setSelectedInmate(await res.json());
      fetchInmates();
    }
  };

  const handleRelease = async (id: number) => {
    if(!confirm('Czy na pewno chcesz zwolnić tego osadzonego z odbywania wyroku?')) return;
    const res = await fetch(`/api/inmates/${id}`, {
      method: 'PUT',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}` 
      },
      body: JSON.stringify({ routine: 'Zwolniony', security_level: 'Brak', sentence_details: 'Zwolniony' })
    });
    if (res.ok) {
      setSelectedInmate(await res.json());
      fetchInmates();
    }
  };

  const [photoUrlInput, setPhotoUrlInput] = useState('');

  const handleAddPhoto = async (id: number) => {
    const url = prompt('Wprowadź adres URL zdjęcia osadzonego:', photoUrlInput);
    if(url) {
      const res = await fetch(`/api/inmates/${id}`, {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}` 
        },
        body: JSON.stringify({ photo_url: url })
      });
      if(res.ok) {
        setSelectedInmate(await res.json());
        fetchInmates();
      }
    }
  };

  const filtered = inmates.filter(i => 
    (i.first_name + ' ' + i.last_name).toLowerCase().includes(search.toLowerCase()) ||
    i.prisoner_number.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-6">
        <div className="flex flex-col"> 
          <span className="text-[10px] uppercase tracking-[0.2em] text-zinc-500">Lista</span>
          <h1 className="text-2xl font-medium text-white">Zarządzanie Osadzonymi</h1>
        </div>
        <button 
          onClick={() => setShowAddForm(true)}
          className="flex items-center px-4 py-2 bg-amber-600 text-zinc-950 font-bold uppercase text-[10px] tracking-wider rounded border border-amber-500 hover:bg-amber-500 transition-colors"
        >
          <Plus className="w-4 h-4 mr-2" /> Dodaj Osadzonego
        </button>
      </div>

      <div className="bento-card p-0 overflow-hidden">
        <div className="p-4 border-b border-zinc-800 flex bg-zinc-900">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
            <input 
              type="text"
              placeholder="Szukaj więźnia..."
              className="w-full pl-10 pr-4 py-2 bg-zinc-950 border border-zinc-800 rounded text-sm text-white placeholder-zinc-500 focus:ring-1 focus:ring-amber-500 focus:outline-none"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-zinc-950 text-zinc-500 text-[10px] uppercase tracking-wider border-b border-zinc-800">
                <th className="px-6 py-4 font-bold">Nr Rejestru</th>
                <th className="px-6 py-4 font-bold">Imię i Nazwisko</th>
                <th className="px-6 py-4 font-bold">Cele</th>
                <th className="px-6 py-4 font-bold">Poziom Bezpieczeństwa</th>
                <th className="px-6 py-4 font-bold">Rutyna</th>
                <th className="px-6 py-4 font-bold">Zachowanie</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800 bg-zinc-900">
              {filtered.map(inmate => (
                <tr key={inmate.id} onClick={() => { setSelectedInmate(inmate); setFormData(inmate); }} className="hover:bg-zinc-800/50 transition-colors cursor-pointer">
                  <td className="px-6 py-4 font-mono text-sm text-amber-500">{inmate.prisoner_number}</td>
                  <td className="px-6 py-4 text-sm font-bold text-white">{inmate.first_name} {inmate.last_name}</td>
                  <td className="px-6 py-4 text-xs text-zinc-400">Cela {inmate.cell_id}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider border 
                      ${inmate.security_level === 'Wysoki' ? 'bg-red-500/10 border-red-500/30 text-red-500' : 
                      inmate.security_level === 'Średni' ? 'bg-amber-500/10 border-amber-500/30 text-amber-500' : 
                      inmate.security_level === 'Izolatka' ? 'bg-zinc-800 border-zinc-600 text-white' :
                      'bg-green-500/10 border-green-500/30 text-green-500'}`}>
                      {inmate.security_level}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-zinc-400 text-xs">{inmate.routine}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <div className="w-full bg-zinc-950 border border-zinc-800 rounded h-1.5 mr-2">
                        <div className="bg-amber-500 h-1.5 rounded" style={{ width: `${inmate.behavior_score}%` }}></div>
                      </div>
                      <span className="text-[10px] font-bold text-zinc-400">{inmate.behavior_score}</span>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={6} className="px-6 py-8 text-center text-zinc-500 text-sm">Brak wyników</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Profile/Detail View Modal */}
      {selectedInmate && !isEditing && (
        <div className="fixed inset-0 bg-zinc-950/80 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
          <div className="bento-card max-w-3xl w-full p-0">
            <div className="flex justify-between items-center p-6 border-b border-zinc-800">
              <h2 className="text-lg font-bold text-white uppercase tracking-wider">Karta Osadzonego</h2>
              <button onClick={() => setSelectedInmate(null)} className="text-zinc-500 hover:text-white transition-colors"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 flex flex-col md:flex-row gap-8">
              <div className="flex flex-col items-center space-y-4">
                <div className="w-40 h-40 bg-zinc-900 border border-zinc-800 rounded flex flex-col items-center justify-center overflow-hidden">
                  {selectedInmate.photo_url ? (
                    <img src={selectedInmate.photo_url} alt="Profile" className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-zinc-600 text-[10px] uppercase tracking-widest font-bold">Brak Zdjęcia</span>
                  )}
                </div>
                <div className="flex flex-col space-y-2 w-full">
                  <button onClick={() => handleAddPhoto(selectedInmate.id)} className="text-[10px] w-full text-center uppercase tracking-wider font-bold text-amber-500 hover:text-amber-400 flex items-center justify-center bg-amber-500/10 border border-amber-500/30 p-2 rounded">
                    <ImageIcon className="w-3 h-3 mr-1" /> Własny URL (Zdjęcie)
                  </button>
                </div>
              </div>
              <div className="flex-1 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-[10px] uppercase text-zinc-500 font-bold tracking-wider">Imię i Nazwisko</p>
                    <p className="text-white text-lg font-medium">{selectedInmate.first_name} {selectedInmate.last_name}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase text-zinc-500 font-bold tracking-wider">Nr Rejestru</p>
                    <p className="text-amber-500 font-mono">{selectedInmate.prisoner_number}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase text-zinc-500 font-bold tracking-wider">Wyrok</p>
                    <p className="text-zinc-300 text-sm">{selectedInmate.sentence_details}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase text-zinc-500 font-bold tracking-wider">Zabezpieczenie</p>
                    <p className="text-zinc-300 text-sm">{selectedInmate.security_level}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase text-zinc-500 font-bold tracking-wider">Cela</p>
                    <p className="text-zinc-300 text-sm">{selectedInmate.cell_id}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase text-zinc-500 font-bold tracking-wider">Rutyna</p>
                    <p className="text-zinc-300 text-sm">{selectedInmate.routine}</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="p-4 border-t border-zinc-800 bg-zinc-900 flex justify-between">
               <div className="flex gap-2">
                 <button onClick={() => setIsEditing(true)} className="flex items-center px-3 py-1.5 bg-zinc-800 text-zinc-300 border border-zinc-700 rounded text-[10px] uppercase tracking-wider font-bold hover:text-white">
                   <Edit className="w-3 h-3 mr-1" /> Edytuj
                 </button>
                 <button onClick={() => handleDelete(selectedInmate.id)} className="flex items-center px-3 py-1.5 bg-red-500/10 text-red-500 border border-red-500/30 rounded text-[10px] uppercase tracking-wider font-bold hover:bg-red-500/20">
                   <Trash2 className="w-3 h-3 mr-1" /> Usuń
                 </button>
               </div>
               <button onClick={() => handleRelease(selectedInmate.id)} className="flex items-center px-4 py-1.5 bg-emerald-500/10 text-emerald-500 border border-emerald-500/30 rounded text-[10px] uppercase tracking-wider font-bold hover:bg-emerald-500/20">
                 <UserMinus className="w-3 h-3 mr-2" /> Zwolnij z wyroku
               </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {isEditing && selectedInmate && (
        <div className="fixed inset-0 bg-zinc-950/80 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
          <div className="bento-card max-w-2xl w-full p-0">
            <div className="flex justify-between items-center p-6 border-b border-zinc-800">
              <h2 className="text-lg font-bold text-white uppercase tracking-wider">Edycja osadzonego</h2>
              <button onClick={() => setIsEditing(false)} className="text-zinc-500 hover:text-white transition-colors"><X className="w-5 h-5" /></button>
            </div>
            <form className="p-6 space-y-4" onSubmit={handleUpdate}>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Imię</label>
                  <input type="text" required className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white focus:outline-none focus:border-amber-500" 
                    value={formData.first_name} onChange={e => setFormData({...formData, first_name: e.target.value})} />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Nazwisko</label>
                  <input type="text" required className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white focus:outline-none focus:border-amber-500"
                    value={formData.last_name} onChange={e => setFormData({...formData, last_name: e.target.value})} />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Numer Więźnia (np. INM-015)</label>
                  <input type="text" required className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white font-mono focus:outline-none focus:border-amber-500"
                    value={formData.prisoner_number} onChange={e => setFormData({...formData, prisoner_number: e.target.value})} />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Poziom Bezpieczeństwa</label>
                  <select className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white focus:outline-none focus:border-amber-500"
                    value={formData.security_level} onChange={e => setFormData({...formData, security_level: e.target.value})}>
                    <option>Niski</option>
                    <option>Średni</option>
                    <option>Wysoki</option>
                    <option>Izolatka</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Szczegóły wyroku</label>
                <input type="text" required className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white focus:outline-none focus:border-amber-500"
                  value={formData.sentence_details} onChange={e => setFormData({...formData, sentence_details: e.target.value})} />
              </div>
              <div>
                <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Rutyna / Praca</label>
                <input type="text" required className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white focus:outline-none focus:border-amber-500"
                  value={formData.routine} onChange={e => setFormData({...formData, routine: e.target.value})} />
              </div>
              <div className="pt-6 flex justify-end gap-3 border-t border-zinc-800 mt-6">
                <button type="button" onClick={() => setIsEditing(false)} className="px-4 py-2 border border-zinc-700 bg-zinc-900 rounded text-zinc-300 hover:text-white uppercase font-bold text-[10px] tracking-wider">Anuluj</button>
                <button type="submit" className="px-4 py-2 bg-amber-600 text-zinc-950 border border-amber-500 rounded font-bold uppercase text-[10px] tracking-wider hover:bg-amber-500">Zapisz Zmiany</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-zinc-950/80 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
          <div className="bento-card max-w-2xl w-full p-0">
            <div className="flex justify-between items-center p-6 border-b border-zinc-800">
              <h2 className="text-lg font-bold text-white uppercase tracking-wider">Rejestracja nowego osadzonego</h2>
              <button onClick={() => setShowAddForm(false)} className="text-zinc-500 hover:text-white transition-colors"><X className="w-5 h-5" /></button>
            </div>
            <form className="p-6 space-y-4" onSubmit={handleAdd}>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Imię</label>
                  <input type="text" required className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white focus:outline-none focus:border-amber-500" 
                    value={formData.first_name} onChange={e => setFormData({...formData, first_name: e.target.value})} />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Nazwisko</label>
                  <input type="text" required className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white focus:outline-none focus:border-amber-500"
                    value={formData.last_name} onChange={e => setFormData({...formData, last_name: e.target.value})} />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Numer Więźnia (np. INM-015)</label>
                  <input type="text" required className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white font-mono focus:outline-none focus:border-amber-500"
                    value={formData.prisoner_number} onChange={e => setFormData({...formData, prisoner_number: e.target.value})} />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Poziom Bezpieczeństwa</label>
                  <select className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white focus:outline-none focus:border-amber-500"
                    value={formData.security_level} onChange={e => setFormData({...formData, security_level: e.target.value})}>
                    <option>Niski</option>
                    <option>Średni</option>
                    <option>Wysoki</option>
                    <option>Izolatka</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Szczegóły wyroku</label>
                <input type="text" required className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white focus:outline-none focus:border-amber-500" placeholder="np. Napad, 10 lat"
                  value={formData.sentence_details} onChange={e => setFormData({...formData, sentence_details: e.target.value})} />
              </div>
              <div>
                <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Rutyna / Praca</label>
                <input type="text" required className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white focus:outline-none focus:border-amber-500" placeholder="np. Praca w pralni (9:00 - 15:00)"
                  value={formData.routine} onChange={e => setFormData({...formData, routine: e.target.value})} />
              </div>
              <div className="pt-6 flex justify-end gap-3 border-t border-zinc-800 mt-6">
                <button type="button" onClick={() => setShowAddForm(false)} className="px-4 py-2 border border-zinc-700 bg-zinc-900 rounded text-zinc-300 hover:text-white uppercase font-bold text-[10px] tracking-wider">Anuluj</button>
                <button type="submit" className="px-4 py-2 bg-amber-600 text-zinc-950 border border-amber-500 rounded font-bold uppercase text-[10px] tracking-wider hover:bg-amber-500">Zapisz Osadzonego</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

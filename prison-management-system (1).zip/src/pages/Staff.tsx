import React, { useState, useEffect } from 'react';
import { Plus, Trash2, FileDown, X, Edit } from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

export default function Staff() {
  const [staff, setStaff] = useState<any[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({ username: '', password: '', name: '', role: 'Strażnik', badge_number: '' });
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  const fetchStaff = async () => {
    const res = await fetch('/api/staff', { headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }});
    if (res.ok) setStaff(await res.json());
  };

  useEffect(() => {
    fetchStaff();
  }, []);

  const handleAddStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    const isUpdating = isEditing && editingId;
    const url = isUpdating ? `/api/staff/${editingId}` : '/api/staff';
    const method = isUpdating ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify(formData)
    });
    if (res.ok) {
      setShowAddForm(false);
      setIsEditing(false);
      setEditingId(null);
      setFormData({ username: '', password: '', name: '', role: 'Strażnik', badge_number: '' });
      fetchStaff();
    }
  };

  const handleEdit = (staffMember: any) => {
    setIsEditing(true);
    setEditingId(staffMember.id);
    setFormData(staffMember);
    setShowAddForm(true);
  };

  const handleDelete = async (id: number) => {
    if(!confirm('Czy na pewno chcesz usunąć tego pracownika?')) return;
    const res = await fetch(`/api/staff/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    });
    if (res.ok) fetchStaff();
  };

  const downloadPDF = () => {
    const doc = new jsPDF();
    doc.text('Lista Personelu - Prison.OS', 14, 20);
    
    const tableData = staff.map(s => [s.username, s.name, s.badge_number, s.role]);
    
    autoTable(doc, {
      head: [['Nazwa uzytkownika', 'Imie i Nazwisko', 'Odznaka', 'Rola']],
      body: tableData,
      startY: 30,
    });
    
    doc.save('kadry-raport.pdf');
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-6">
        <div className="flex flex-col"> 
          <span className="text-[10px] uppercase tracking-[0.2em] text-zinc-500">Zasoby ludzkie</span>
          <h1 className="text-2xl font-medium text-white">Personel i Użytkownicy</h1>
        </div>
        <div className="flex gap-4">
          <button onClick={downloadPDF} className="flex items-center px-4 py-2 bg-zinc-800 text-white font-bold uppercase text-[10px] tracking-wider rounded border border-zinc-700 hover:bg-zinc-700 transition-colors">
            <FileDown className="w-4 h-4 mr-2" /> Pobierz listę do PDF
          </button>
          {user.role === 'Admin' && (
            <button onClick={() => setShowAddForm(true)} className="flex items-center px-4 py-2 bg-amber-600 text-zinc-950 font-bold uppercase text-[10px] tracking-wider rounded border border-amber-500 hover:bg-amber-500 transition-colors">
              <Plus className="w-4 h-4 mr-2" /> Dodaj Pracownika
            </button>
          )}
        </div>
      </div>

      <div className="bento-card p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-zinc-950 text-zinc-500 text-[10px] uppercase tracking-wider border-b border-zinc-800">
              <tr>
                <th className="px-6 py-4 font-bold">Nazwa użytkownika</th>
                <th className="px-6 py-4 font-bold">Imię i Nazwisko</th>
                <th className="px-6 py-4 font-bold">Odznaka</th>
                <th className="px-6 py-4 font-bold">Rola (Uprawnienia)</th>
                {user.role === 'Admin' && <th className="px-6 py-4 font-bold text-right">Akcje</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800 bg-zinc-900">
              {staff.map(member => (
                <tr key={member.id} className="hover:bg-zinc-800/50 transition-colors">
                  <td className="px-6 py-4 text-sm font-bold text-white">{member.username}</td>
                  <td className="px-6 py-4 text-sm text-zinc-300">{member.name}</td>
                  <td className="px-6 py-4 font-mono text-xs text-amber-500">{member.badge_number}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 text-[10px] font-bold uppercase tracking-wider rounded border ${member.role === 'Admin' ? 'bg-amber-500/10 border-amber-500/30 text-amber-500' : 'bg-zinc-800 border-zinc-700 text-zinc-300'}`}>
                      {member.role}
                    </span>
                  </td>
                  {user.role === 'Admin' && (
                    <td className="px-6 py-4 text-right flex justify-end gap-2">
                       {member.username !== 'ADMIN123' && (
                         <button onClick={() => handleEdit(member)} className="p-1.5 bg-zinc-800 text-zinc-300 hover:text-white rounded border border-zinc-700 transition-colors">
                           <Edit className="w-4 h-4" />
                         </button>
                       )}
                      {member.username !== user.username && member.username !== 'ADMIN123' && (
                        <button onClick={() => handleDelete(member.id)} className="p-1.5 bg-red-500/10 text-red-500 hover:bg-red-500/20 rounded border border-red-500/30 transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Staff Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-zinc-950/80 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
          <div className="bento-card max-w-xl w-full p-0">
            <div className="flex justify-between items-center p-6 border-b border-zinc-800">
              <h2 className="text-lg font-bold text-white uppercase tracking-wider">{isEditing ? 'Edytuj Pracownika' : 'Dodaj Pracownika'}</h2>
              <button onClick={() => { setShowAddForm(false); setIsEditing(false); setFormData({ username: '', password: '', name: '', role: 'Strażnik', badge_number: '' }); }} className="text-zinc-500 hover:text-white transition-colors"><X className="w-5 h-5" /></button>
            </div>
            <form className="p-6 space-y-4" onSubmit={handleAddStaff}>
              <div>
                <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Nazwa użytkownika</label>
                <input type="text" required className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white focus:outline-none focus:border-amber-500" 
                  value={formData.username} onChange={e => setFormData({...formData, username: e.target.value})} />
              </div>
              <div>
                <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Hasło</label>
                <input type="password" required className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white focus:outline-none focus:border-amber-500" 
                  value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} />
              </div>
              <div>
                <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Imię i Nazwisko</label>
                <input type="text" required className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white focus:outline-none focus:border-amber-500" 
                  value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Odznaka</label>
                  <input type="text" required className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white font-mono focus:outline-none focus:border-amber-500" 
                    value={formData.badge_number} onChange={e => setFormData({...formData, badge_number: e.target.value})} />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Uprawnienia</label>
                  <select className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white focus:outline-none focus:border-amber-500"
                    value={formData.role} onChange={e => setFormData({...formData, role: e.target.value})}>
                    <option>Strażnik</option>
                    <option>Manager</option>
                    <option>Admin</option>
                  </select>
                </div>
              </div>
              <div className="pt-6 flex justify-end gap-3 border-t border-zinc-800 mt-6">
                <button type="button" onClick={() => { setShowAddForm(false); setIsEditing(false); setFormData({ username: '', password: '', name: '', role: 'Strażnik', badge_number: '' }); }} className="px-4 py-2 border border-zinc-700 bg-zinc-900 rounded text-zinc-300 hover:text-white uppercase font-bold text-[10px] tracking-wider">Anuluj</button>
                <button type="submit" className="px-4 py-2 bg-amber-600 text-zinc-950 border border-amber-500 rounded font-bold uppercase text-[10px] tracking-wider hover:bg-amber-500">{isEditing ? 'Zapisz zmiany' : 'Dodaj konto'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

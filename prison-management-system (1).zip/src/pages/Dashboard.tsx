import React, { useEffect, useState } from 'react';
import { Users, ShieldAlert, BadgeInfo, Zap } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function Dashboard() {
  const [stats, setStats] = useState({ totalInmates: 0, activeStaff: 0, recentIncidents: 0, cellCapacity: 0 });
  const [incidents, setIncidents] = useState<any[]>([]);

  useEffect(() => {
    const fetchStats = async () => {
      const headers = { 'Authorization': `Bearer ${localStorage.getItem('token')}` };
      const resStats = await fetch('/api/stats', { headers });
      if (resStats.ok) setStats(await resStats.json());
      
      const resInc = await fetch('/api/incidents', { headers });
      if (resInc.ok) {
        const inc = await resInc.json();
        setIncidents(inc.slice(0, 5)); // Last 5 incidents
      }
    };
    fetchStats();
  }, []);

  const chartData = [
    { name: 'Pon', incidents: 2 },
    { name: 'Wto', incidents: 0 },
    { name: 'Śro', incidents: 1 },
    { name: 'Czw', incidents: 4 },
    { name: 'Pią', incidents: 0 },
    { name: 'Sob', incidents: 2 },
    { name: 'Nie', incidents: 1 },
  ];

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center mb-6">
        <div className="flex flex-col"> 
          <span className="text-[10px] uppercase tracking-[0.2em] text-zinc-500">Status Systemu</span>
          <div className="flex items-center gap-3">
            <h2 className="text-2xl font-medium text-white">Pulpit Dowodzenia</h2>
            <div className="px-2 py-1 bg-zinc-900 border border-zinc-800 rounded text-[10px] text-zinc-400 mono uppercase">Token JWT: Aktywny</div>
          </div>
        </div>
        <div className="flex gap-4">
          <div className="flex items-center gap-6 px-6 py-3 bg-zinc-900 border border-zinc-800 rounded-xl">
             <div className="text-center">
               <p className="text-[10px] uppercase text-zinc-500">Osadzeni</p>
               <p className="text-xl font-bold text-white">{stats.totalInmates}</p>
             </div>
             <div className="w-px h-8 bg-zinc-800"></div>
             <div className="text-center">
               <p className="text-[10px] uppercase text-zinc-500">Personel</p>
               <p className="text-xl font-bold text-white">{stats.activeStaff}</p>
             </div>
             <div className="w-px h-8 bg-zinc-800"></div>
             <div className="text-center">
               <p className="text-[10px] uppercase text-zinc-500">Zajętość</p>
               <p className="text-xl font-bold text-amber-500">{stats.cellCapacity}%</p>
             </div>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Main Chart */}
        <div className="lg:col-span-2 bento-card">
          <h2 className="text-xs uppercase font-bold tracking-wider text-zinc-400 mb-4">Aktywność incydentów (Tydzień)</h2>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#27272a" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#71717a'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#71717a'}} />
                <Tooltip contentStyle={{ backgroundColor: '#18181b', borderRadius: '0.5rem', border: '1px solid #27272a', color: '#d4d4d8', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.5)' }} />
                <Line type="monotone" dataKey="incidents" stroke="#f59e0b" strokeWidth={3} dot={{r: 4, fill: '#f59e0b', stroke: '#18181b'}} activeDot={{r: 6}} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Tablica Najnowszych Wydarzeń */}
        <div className="bento-card">
          <h2 className="text-xs uppercase font-bold tracking-wider text-zinc-400 mb-4">Ostatnie Incydenty (Statystyka: {stats.recentIncidents})</h2>
          <div className="space-y-4">
            {incidents.length === 0 ? (
              <p className="text-zinc-500 text-sm">Brak nowych incydentów.</p>
            ) : (
              incidents.map((inc) => (
                <div key={inc.id} className="p-3 bg-red-500/10 border-l-2 border-red-500 w-full flex flex-col gap-1 rounded-r">
                  <div className="flex justify-between text-[10px]">
                    <span className="font-bold uppercase text-red-500">{inc.category}</span>
                    <span className="mono text-zinc-400">{new Date(inc.date).toLocaleDateString()}</span>
                  </div>
                  <p className="text-xs text-white line-clamp-2">{inc.description} <span className="text-zinc-500">({inc.location})</span></p>
                </div>
              ))
            )}
          </div>
        </div>

      </div>
    </div>
  );
}

function StatCard({ title, value, icon }: { title: string, value: string | number, icon: React.ReactNode }) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200 flex items-center">
      <div className="p-4 bg-slate-50 rounded-full mr-4">
        {icon}
      </div>
      <div>
        <p className="text-sm font-medium text-slate-500">{title}</p>
        <p className="text-2xl font-bold text-slate-900">{value}</p>
      </div>
    </div>
  );
}

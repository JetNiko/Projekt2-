import React, { useState, useEffect } from 'react';
import { Plus } from 'lucide-react';

export default function Incidents() {
  const [incidents, setIncidents] = useState<any[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    date: new Date().toISOString().slice(0,16), location: '', description: '', severity: 'Niski', category: 'Złamanie regulaminu'
  });

  const fetchIncidents = async () => {
    const res = await fetch('/api/incidents', { headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }});
    if (res.ok) setIncidents(await res.json());
  };

  useEffect(() => { fetchIncidents(); }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/incidents', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('token')}` },
      body: JSON.stringify(formData)
    });
    if (res.ok) {
      setShowForm(false);
      fetchIncidents();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-6">
        <div className="flex flex-col"> 
          <span className="text-[10px] uppercase tracking-[0.2em] text-zinc-500">Logi</span>
          <h1 className="text-2xl font-medium text-white">Rejestr Incydentów</h1>
        </div>
        <button onClick={() => setShowForm(true)} className="flex items-center px-4 py-2 bg-red-500/10 border border-red-500/50 text-red-500 font-bold uppercase text-[10px] tracking-wider rounded hover:bg-red-500/20 transition-colors">
          <Plus className="w-4 h-4 mr-2" /> Zgłoś Incydent
        </button>
      </div>

      {showForm && (
        <form className="bento-card" onSubmit={handleSubmit}>
          <h2 className="text-xs uppercase font-bold tracking-wider text-zinc-400 mb-4">Nowe Zgłoszenie</h2>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Data i czas</label>
              <input type="datetime-local" className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white focus:outline-none focus:border-red-500" value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} required/>
            </div>
            <div>
              <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Lokalizacja</label>
              <input type="text" className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white focus:outline-none focus:border-red-500" value={formData.location} onChange={e => setFormData({...formData, location: e.target.value})} required/>
            </div>
            <div>
              <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Kategoria</label>
              <select className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white focus:outline-none focus:border-red-500" value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})}>
                <option>Złamanie regulaminu</option>
                <option>Bójka</option>
                <option>Przemyt</option>
                <option>Agresja wobec personelu</option>
                <option>Próba ucieczki</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Poziom Zagrożenia</label>
              <select className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white focus:outline-none focus:border-red-500" value={formData.severity} onChange={e => setFormData({...formData, severity: e.target.value})}>
                <option>Niski</option><option>Średni</option><option>Wysoki</option><option>Krytyczny</option>
              </select>
            </div>
          </div>
          <div className="mt-4">
            <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Opis szczegółowy</label>
            <textarea className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded text-white focus:outline-none focus:border-red-500" rows={3} value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} required></textarea>
          </div>
          <div className="flex justify-end gap-3 mt-6 pt-6 border-t border-zinc-800">
            <button type="button" onClick={() => setShowForm(false)} className="px-4 py-2 border border-zinc-700 bg-zinc-900 rounded text-zinc-300 hover:text-white uppercase font-bold text-[10px] tracking-wider">Anuluj</button>
            <button type="submit" className="px-4 py-2 bg-red-600 text-white rounded font-bold uppercase text-[10px] tracking-wider hover:bg-red-500">Zapisz Incydent</button>
          </div>
        </form>
      )}

      <div className="bento-card p-0 overflow-hidden divide-y divide-zinc-800 bg-zinc-900">
        {incidents.map((inc) => (
          <div key={inc.id} className="p-4 hover:bg-zinc-800/50 flex items-start transition-colors">
            <div className={`w-2 h-14 rounded-l mr-4 ${inc.severity === 'Krytyczny' ? 'bg-red-700' : inc.severity === 'Wysoki' ? 'bg-red-500' : inc.severity === 'Średni' ? 'bg-amber-500' : 'bg-zinc-500'}`}></div>
            <div className="flex-1">
              <div className="flex justify-between items-start">
                <h3 className="text-xs uppercase font-bold tracking-wider text-white">{inc.category}</h3>
                <span className="text-[10px] text-zinc-500 mono">{new Date(inc.date).toLocaleString()}</span>
              </div>
              <p className="text-xs text-zinc-400 mt-1"><span className="text-zinc-600">Lokalizacja:</span> {inc.location}</p>
              <p className="text-sm text-zinc-300 mt-2">{inc.description}</p>
            </div>
          </div>
        ))}
        {incidents.length === 0 && <div className="p-8 text-center text-zinc-500">Brak zarejestrowanych incydentów.</div>}
      </div>
    </div>
  );
}

import express from 'express';
import { createServer as createViteServer } from 'vite';
import jwt from 'jsonwebtoken';
import path from 'path';
import fs from 'fs/promises';

const PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'prison-management-secret';

const DB_FILE = path.join(process.cwd(), 'database.json');

let data: any = {
  users: [],
  inmates: [],
  cells: [],
  wards: [],
  incidents: [],
  visits: []
};

async function saveDB() {
  await fs.writeFile(DB_FILE, JSON.stringify(data, null, 2));
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // Initialize JSON Database
  try {
    const file = await fs.readFile(DB_FILE, 'utf-8');
    data = JSON.parse(file);
    if (!data.messages) data.messages = [];
  } catch (e) {
    // Generate initial data
    data.messages = [];
    data.users.push({ id: 1, username: 'ADMIN123', password: 'ADMIN123', name: 'Główny Administrator', role: 'Admin', badge_number: '0000' });
    
    data.wards.push({ id: 1, name: 'Blok A', security_level: 'Niski' });
    data.wards.push({ id: 2, name: 'Blok B', security_level: 'Średni' });
    data.wards.push({ id: 3, name: 'Blok C', security_level: 'Wysoki' });
    data.wards.push({ id: 4, name: 'Izolatka', security_level: 'Krytyczny' });

    for(let w=1; w<=4; w++) {
      for(let c=1; c<=10; c++) {
         data.cells.push({ id: data.cells.length + 1, ward_id: w, cell_number: `${w}${c.toString().padStart(2, '0')}`, capacity: w===4 ? 1 : 4, status: 'aktywna' });
      }
    }

    const firstNames = ['Jan', 'Piotr', 'Krzysztof', 'Andrzej', 'Tomasz', 'Paweł', 'Michał', 'Maciej', 'Marcin', 'Jakub'];
    const lastNames = ['Kowalski', 'Nowak', 'Wiśniewski', 'Wójcik', 'Kowalczyk', 'Kamiński', 'Lewandowski', 'Zieliński', 'Szymański', 'Woźniak'];
    
    for (let i = 1; i <= 40; i++) {
      data.inmates.push({ 
        id: i, 
        first_name: firstNames[i % firstNames.length], 
        last_name: lastNames[(i * 3) % lastNames.length], 
        prisoner_number: `INM-${i.toString().padStart(3, '0')}`, 
        cell_id: i, 
        security_level: i % 7 === 0 ? 'Izolatka' : (i % 3 === 0 ? 'Wysoki' : 'Średni'), 
        behavior_score: Math.floor(Math.random() * 40) + 60, 
        routine: 'Standardowy wpis', 
        sentence_details: 'Przestępstwo, ' + (Math.floor(Math.random() * 10) + 1) + ' lat',
        photo_url: '',
        fingerprint_url: ''
      });
    }

    await saveDB();
  }

  // --- API Routes ---

  // Auth Middleware
  const authenticateToken = (req: any, res: any, next: any) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (token == null) return res.sendStatus(401);

    jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
      if (err) return res.sendStatus(403);
      req.user = user;
      next();
    });
  };

  // Login
  app.post('/api/auth/login', async (req, res) => {
    const { username, password } = req.body;
    const user = data.users.find((u: any) => u.username === username && u.password === password);
    
    if (user) {
      const token = jwt.sign({ id: user.id, username: user.username, role: user.role, name: user.name }, JWT_SECRET);
      res.json({ token, user: { id: user.id, name: user.name, role: user.role } });
    } else {
      res.status(401).json({ error: 'Nieprawidłowe dane logowania' });
    }
  });

  // Dashboard Stats
  app.get('/api/stats', authenticateToken, async (req, res) => {
    const inmatesCount = data.inmates.length;
    const staffCount = data.users.filter((u: any) => u.role !== 'Admin').length;
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const incidentsCount = data.incidents.filter((i: any) => new Date(i.date) >= oneDayAgo).length;
    
    res.json({
      totalInmates: inmatesCount,
      activeStaff: staffCount,
      recentIncidents: incidentsCount,
      cellCapacity: 92 // Mocked
    });
  });

  // Wards & Cells
  app.get('/api/wards', authenticateToken, async (req, res) => {
    const wards = data.wards.map((w: any) => ({
      ...w,
      cells: data.cells.filter((c: any) => c.ward_id === w.id)
    }));
    res.json(wards);
  });

  // Inmates
  app.get('/api/inmates', authenticateToken, async (req, res) => {
    res.json(data.inmates);
  });

  app.post('/api/inmates', authenticateToken, async (req, res) => {
    const id = data.inmates.length > 0 ? Math.max(...data.inmates.map((i: any) => i.id)) + 1 : 1;
    const newInmate = { id, behavior_score: 100, ...req.body };
    data.inmates.push(newInmate);
    await saveDB();
    res.json({ id });
  });

  app.put('/api/inmates/:id', authenticateToken, async (req, res) => {
    const id = parseInt(req.params.id);
    const index = data.inmates.findIndex((i: any) => i.id === id);
    if (index === -1) return res.status(404).json({ error: 'Nie znaleziono' });
    
    data.inmates[index] = { ...data.inmates[index], ...req.body };
    await saveDB();
    res.json(data.inmates[index]);
  });

  app.delete('/api/inmates/:id', authenticateToken, async (req, res) => {
    const id = parseInt(req.params.id);
    data.inmates = data.inmates.filter((i: any) => i.id !== id);
    await saveDB();
    res.json({ success: true });
  });

  // Users (Staff)
  app.get('/api/staff', authenticateToken, async (req, res) => {
    const staff = data.users.map(({ id, username, name, role, badge_number }: any) => ({ id, username, name, role, badge_number }));
    res.json(staff);
  });

  app.post('/api/staff', authenticateToken, async (req: any, res: any) => {
    if (req.user.role !== 'Admin') return res.status(403).json({error: 'Brak uprawnień'});
    const id = data.users.length > 0 ? Math.max(...data.users.map((u: any) => u.id)) + 1 : 1;
    data.users.push({ id, ...req.body });
    await saveDB();
    res.json({ id });
  });

  app.put('/api/staff/:id', authenticateToken, async (req: any, res: any) => {
    if (req.user.role !== 'Admin') return res.status(403).json({error: 'Brak uprawnień'});
    const id = parseInt(req.params.id);
    const index = data.users.findIndex((u: any) => u.id === id);
    if (index === -1) return res.status(404).json({ error: 'Nie znaleziono' });
    
    // update fields
    data.users[index] = { ...data.users[index], ...req.body };
    await saveDB();
    res.json(data.users[index]);
  });

  app.delete('/api/staff/:id', authenticateToken, async (req: any, res: any) => {
    if (req.user.role !== 'Admin') return res.status(403).json({error: 'Brak uprawnień'});
    const id = parseInt(req.params.id);
    data.users = data.users.filter((u: any) => u.id !== id);
    await saveDB();
    res.json({ success: true });
  });

  // Photo Generation removed from backend per rules

  // Messages (Chat)
  app.get('/api/messages', authenticateToken, async (req: any, res: any) => {
    res.json(data.messages || []);
  });

  app.post('/api/messages', authenticateToken, async (req: any, res: any) => {
    const id = data.messages && data.messages.length > 0 ? Math.max(...data.messages.map((m: any) => m.id)) + 1 : 1;
    const newMessage = { id, sender_name: req.user.name, sender_id: req.user.id, ...req.body, timestamp: new Date().toISOString() };
    if (!data.messages) data.messages = [];
    data.messages.push(newMessage);
    await saveDB();
    res.json(newMessage);
  });

  // Incidents
  app.get('/api/incidents', authenticateToken, async (req, res) => {
    const sorted = [...data.incidents].sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime());
    res.json(sorted);
  });

  app.post('/api/incidents', authenticateToken, async (req, res) => {
    const id = data.incidents.length > 0 ? Math.max(...data.incidents.map((i: any) => i.id)) + 1 : 1;
    data.incidents.push({ id, ...req.body });
    await saveDB();
    res.json({ id });
  });

  // Visits
  app.get('/api/visits', authenticateToken, async (req, res) => {
    const visits = data.visits.map((v: any) => {
      const inmate = data.inmates.find((i: any) => i.id === Number(v.inmate_id));
      return {
        ...v,
        first_name: inmate?.first_name || 'Nieznany',
        last_name: inmate?.last_name || 'Osadzony'
      };
    });
    res.json(visits);
  });

  app.post('/api/visits', authenticateToken, async (req, res) => {
    const id = data.visits.length > 0 ? Math.max(...data.visits.map((i: any) => i.id)) + 1 : 1;
    data.visits.push({ id, ...req.body });
    await saveDB();
    res.json({ id });
  });


  // --- Vite Middleware ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Production serving
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(console.error);

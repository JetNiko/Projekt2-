# PrisonGuard - Wersja PHP

Ta wersja systemu została przygotowana tak, aby backend działał w języku PHP z bazą danych SQLite.

## Wymagania
- PHP 7.4 lub nowszy
- Rozszerzenie PHP SQLite3 (zazwyczaj włączone domyślnie)
- Node.js (tylko do zbudowania frontendu)

## Instrukcja uruchomienia

### 1. Zbuduj frontend (React)
Ponieważ interfejs jest napisany w React, musisz go skompilować do plików statycznych, które PHP będzie mógł serwować:
```bash
npm install
npm run build
```

### 2. Uruchom serwer PHP
Możesz użyć wbudowanego serwera PHP:
```bash
php -S localhost:8000 router.php
```

### 3. Korzystaj z aplikacji
Otwórz przeglądarkę i wejdź na: **http://localhost:8000**

## Struktura plików PHP
- `api/db.php`: Konfiguracja bazy danych SQLite i inicjalizacja tabel.
- `api/login.php`: Obsługa logowania.
- `api/stats.php`: Pobieranie statystyk do pulpitu.
- `api/inmates.php`: Lista osadzonych.
- `router.php`: Główny plik sterujący, który łączy frontend z backendem PHP.

## Dane logowania
- **Admin**: ADMIN / admin123
- **Strażnik**: GUARD / guard123
- **Medyk**: MEDICAL / med123

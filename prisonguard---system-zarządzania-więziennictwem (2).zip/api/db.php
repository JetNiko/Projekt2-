<?php
// api/db.php
$db_file = __DIR__ . '/../prison.db';
$db = new PDO('sqlite:' . $db_file);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Initialize Database
$db->exec("
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    employeeId TEXT UNIQUE,
    password TEXT,
    name TEXT,
    role TEXT,
    department TEXT
  );

  CREATE TABLE IF NOT EXISTS inmates (
    id TEXT PRIMARY KEY,
    firstName TEXT,
    lastName TEXT,
    inmateNumber TEXT UNIQUE,
    dateOfBirth TEXT,
    citizenship TEXT,
    sentence TEXT,
    sentenceLength TEXT,
    startDate TEXT,
    endDate TEXT,
    crimeType TEXT,
    cellNumber TEXT,
    wardId TEXT,
    securityLevel TEXT,
    status TEXT
  );

  CREATE TABLE IF NOT EXISTS incidents (
    id TEXT PRIMARY KEY,
    date TEXT,
    time TEXT,
    location TEXT,
    category TEXT,
    threatLevel TEXT,
    status TEXT,
    description TEXT
  );
");

// Seed initial data if empty
$stmt = $db->query("SELECT count(*) as count FROM users");
$userCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

if ($userCount == 0) {
    $stmt = $db->prepare("INSERT INTO users (id, employeeId, password, name, role, department) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute(['1', 'ADMIN', 'admin123', 'Jan Kowalski', 'ADMIN', 'Administracja']);
    $stmt->execute(['2', 'GUARD', 'guard123', 'Adam Nowak', 'GUARD', 'Ochrona']);
    $stmt->execute(['3', 'MEDICAL', 'med123', 'Anna Wiśniewska', 'MEDICAL', 'Służba Zdrowia']);
}

$stmt = $db->query("SELECT count(*) as count FROM inmates");
$inmateCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

if ($inmateCount == 0) {
    $stmt = $db->prepare("INSERT INTO inmates (id, firstName, lastName, inmateNumber, cellNumber, wardId, securityLevel, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute(['1', 'Jan', 'Kowalski', '2024/001', 'A-102', 'Oddział A', 'MEDIUM', 'ACTIVE']);
    $stmt->execute(['2', 'Adam', 'Nowak', '2023/154', 'B-205', 'Oddział B', 'HIGH', 'ACTIVE']);
}
?>

<?php
// api/stats.php
header('Content-Type: application/json');
require_once 'db.php';

$inmatesCount = $db->query("SELECT count(*) as count FROM inmates")->fetch(PDO::FETCH_ASSOC)['count'];
$staffCount = $db->query("SELECT count(*) as count FROM users")->fetch(PDO::FETCH_ASSOC)['count'];
$today = date('Y-m-d');
$incidentsToday = $db->prepare("SELECT count(*) as count FROM incidents WHERE date = ?");
$incidentsToday->execute([$today]);
$incidentsTodayCount = $incidentsToday->fetch(PDO::FETCH_ASSOC)['count'];

echo json_encode([
    'inmates' => (int)$inmatesCount,
    'staff' => (int)$staffCount,
    'incidentsToday' => (int)$incidentsTodayCount,
    'activeAlarms' => 0
]);
?>

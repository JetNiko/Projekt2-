<?php
// api/login.php
header('Content-Type: application/json');
require_once 'db.php';

$input = json_decode(file_get_contents('php://input'), true);
$employeeId = $input['employeeId'] ?? '';
$password = $input['password'] ?? '';

$stmt = $db->prepare("SELECT * FROM users WHERE employeeId = ? AND password = ?");
$stmt->execute([$employeeId, $password]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
    unset($user['password']);
    echo json_encode($user);
} else {
    http_response_code(401);
    echo json_encode(['error' => 'Nieprawidłowy login lub hasło']);
}
?>

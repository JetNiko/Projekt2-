<?php
// api/inmates.php
header('Content-Type: application/json');
require_once 'db.php';

$inmates = $db->query("SELECT * FROM inmates")->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($inmates);
?>

-- Struktura bazy danych przygotowana specjalnie dla pgAdmin (PostgreSQL)
-- Możesz wkleić ten kod w "Query Tool" w pgAdmin, wykonać go, 
-- a następnie użyć narzędzia "ERD Tool" (Generate ERD), aby zobaczyć schemat graficzny.

CREATE TABLE users (
    id VARCHAR(50) PRIMARY KEY,
    employeeId VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(150) NOT NULL,
    role VARCHAR(50) NOT NULL,
    department VARCHAR(100)
);

CREATE TABLE wards (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    capacity INT
);

CREATE TABLE cells (
    id VARCHAR(50) PRIMARY KEY,
    wardId VARCHAR(50) REFERENCES wards(id),
    cellNumber VARCHAR(20) UNIQUE NOT NULL,
    capacity INT DEFAULT 2,
    isSpecial BOOLEAN DEFAULT FALSE
);

CREATE TABLE inmates (
    id VARCHAR(50) PRIMARY KEY,
    firstName VARCHAR(100) NOT NULL,
    lastName VARCHAR(100) NOT NULL,
    inmateNumber VARCHAR(50) UNIQUE NOT NULL,
    dateOfBirth DATE,
    citizenship VARCHAR(50),
    sentence TEXT,
    sentenceLength VARCHAR(50),
    startDate DATE,
    endDate DATE,
    crimeType VARCHAR(255),
    cellNumber VARCHAR(20),
    wardId VARCHAR(50),
    securityLevel VARCHAR(20),
    status VARCHAR(20) DEFAULT 'ACTIVE'
);

CREATE TABLE incidents (
    id VARCHAR(50) PRIMARY KEY,
    date DATE NOT NULL,
    time TIME NOT NULL,
    location VARCHAR(255),
    category VARCHAR(50),
    threatLevel VARCHAR(20),
    status VARCHAR(20) DEFAULT 'REPORTED',
    description TEXT
);

CREATE TABLE medical_records (
    id VARCHAR(50) PRIMARY KEY,
    inmateId VARCHAR(50) REFERENCES inmates(id),
    date DATE NOT NULL,
    diagnosis VARCHAR(255),
    doctorId VARCHAR(50) REFERENCES users(id),
    status VARCHAR(50)
);

import React from 'react';
import { 
  HelpCircle, 
  Book, 
  Phone, 
  Mail, 
  ShieldCheck,
  ExternalLink,
  MessageCircle
} from 'lucide-react';
import { motion } from 'motion/react';

const Help: React.FC = () => {
  const categories = [
    {
      title: 'Podstawy Systemu',
      icon: Book,
      links: [
        'Jak dodać nowego osadzonego?',
        'Zarządzanie celami i oddziałami',
        'Raportowanie incydentów - krok po kroku',
        'Zasady bezpieczeństwa danych'
      ]
    },
    {
      title: 'Wsparcie Techniczne',
      icon: Phone,
      links: [
        'Kontakt z administratorem IT',
        'Zgłaszanie błędów w systemie',
        'Problemy z logowaniem',
        'Aktualizacja oprogramowania'
      ]
    },
    {
      title: 'Procedury i Regulaminy',
      icon: ShieldCheck,
      iconColor: 'text-emerald-500',
      links: [
        'Regulamin jednostki penitencjarnej',
        'Procedury alarmowe (Kod Czerwony)',
        'Zasady wydawania przepustek',
        'Standardy opieki medycznej'
      ]
    }
  ];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-slate-900">Centrum Pomocy</h2>
        <p className="text-slate-500">Znajdź odpowiedzi na pytania lub skontaktuj się ze wsparciem.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {categories.map((cat, idx) => (
          <motion.div
            key={cat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm"
          >
            <div className={`p-3 rounded-xl bg-slate-50 w-fit mb-4 ${cat.iconColor || 'text-blue-500'}`}>
              <cat.icon size={24} />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-4">{cat.title}</h3>
            <ul className="space-y-3">
              {cat.links.map((link, lIdx) => (
                <li key={lIdx}>
                  <button className="text-sm text-slate-600 hover:text-emerald-600 flex items-center gap-2 transition-colors text-left">
                    <ChevronRight size={14} className="text-slate-300" />
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>

      <div className="bg-slate-900 rounded-2xl p-8 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-[80px] -mr-32 -mt-32"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="max-w-xl">
            <h3 className="text-2xl font-bold mb-2">Potrzebujesz natychmiastowej pomocy?</h3>
            <p className="text-slate-400">
              Nasz zespół wsparcia technicznego jest dostępny 24/7 dla spraw krytycznych. 
              W przypadku awarii systemu zagrażającej bezpieczeństwu, użyj przycisku alarmowego.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
            <button className="flex items-center justify-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-500 rounded-xl font-bold transition-all">
              <MessageCircle size={20} />
              Czat ze wsparciem
            </button>
            <button className="flex items-center justify-center gap-2 px-6 py-3 bg-slate-800 hover:bg-slate-700 rounded-xl font-bold transition-all">
              <Mail size={20} />
              Wyślij zgłoszenie
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <h3 className="text-lg font-bold text-slate-900 mb-6">Często Zadawane Pytania (FAQ)</h3>
        <div className="space-y-4">
          {[
            { q: 'Jak zresetować hasło do systemu?', a: 'Hasło może zostać zresetowane tylko przez administratora IT po weryfikacji tożsamości pracownika.' },
            { q: 'Gdzie znajdę historię transferów osadzonego?', a: 'Historia transferów znajduje się w profilu osadzonego w zakładce "Historia".' },
            { q: 'Jak wygenerować raport miesięczny incydentów?', a: 'Administratorzy i dyrekcja mają dostęp do modułu raportowania w zakładce "Statystyki".' },
          ].map((item, idx) => (
            <div key={idx} className="p-4 rounded-xl bg-slate-50 border border-slate-100">
              <p className="font-bold text-slate-900 mb-1">{item.q}</p>
              <p className="text-sm text-slate-600">{item.a}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

import { ChevronRight } from 'lucide-react';
export default Help;

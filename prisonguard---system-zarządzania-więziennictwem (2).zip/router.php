<?php
// router.php
// This script is intended for use with the PHP built-in web server:
// php -S localhost:8000 router.php

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// Route API requests to the api folder
if (strpos($uri, '/api/') === 0) {
    $file = __DIR__ . $uri;
    if (file_exists($file)) {
        require_once $file;
        exit;
    }
}

// Serve static files from the dist folder (after build)
// If dist doesn't exist, we assume we are in development and want to serve from root (though React needs build)
$dist_path = __DIR__ . '/dist' . $uri;
if (file_exists($dist_path) && !is_dir($dist_path)) {
    return false; // serve as-is
}

// Fallback to index.html for SPA routing
if (file_exists(__DIR__ . '/dist/index.html')) {
    readfile(__DIR__ . '/dist/index.html');
    exit;
}

// If dist doesn't exist, show a message
echo "<h1>System PrisonGuard</h1>";
echo "<p>Backend PHP jest gotowy.</p>";
echo "<p>Aby zobaczyć interfejs, musisz najpierw zbudować projekt React komendą: <code>npm run build</code></p>";
echo "<p>Następnie odśwież tę stronę.</p>";
?>

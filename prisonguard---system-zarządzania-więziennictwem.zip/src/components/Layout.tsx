import React, { useState, useEffect, useRef } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  AlertTriangle, 
  UserCog, 
  Grid, 
  LogOut, 
  Bell, 
  Shield,
  Menu,
  X,
  Calendar,
  MessageSquare,
  Stethoscope,
  Clock
} from 'lucide-react';
import { User } from '../types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface LayoutProps {
  user: User;
  onLogout: () => void;
}

export default function Layout({ user, onLogout }: LayoutProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 30000); // Check every 30s
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const fetchNotifications = async () => {
    try {
      const response = await fetch('/api/notifications', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      if (response.ok) {
        setNotifications(await response.json());
      }
    } catch (err) {
      console.error(err);
    }
  };

  const navItems = [
    { name: 'Panel Główny', path: '/', icon: LayoutDashboard },
    { name: 'Osadzeni', path: '/inmates', icon: Users },
    { name: 'Incydenty', path: '/incidents', icon: AlertTriangle },
    { name: 'Personel', path: '/staff', icon: UserCog },
    { name: 'Cele i Oddziały', path: '/cells', icon: Grid },
    { name: 'Wizyty', path: '/visits', icon: Calendar },
    { name: 'Komunikacja', path: '/communication', icon: MessageSquare },
  ];

  if (user.role === 'Admin') {
    navItems.push({ name: 'Grafik', path: '/schedule', icon: Clock });
  }

  return (
    <div className="flex h-screen bg-[#E4E3E0] text-[#141414] font-sans selection:bg-[#141414] selection:text-[#E4E3E0]">
      {/* Sidebar */}
      <aside 
        className={cn(
          "bg-[#141414] text-[#E4E3E0] transition-all duration-300 flex flex-col border-r border-[#141414]",
          isSidebarOpen ? "w-64" : "w-20"
        )}
      >
        <div className="p-6 flex items-center gap-3 border-b border-[#E4E3E0]/10">
          <Shield className="w-8 h-8 text-[#E4E3E0]" />
          {isSidebarOpen && <span className="font-bold text-xl tracking-tighter">PRISONGUARD</span>}
        </div>

        <nav className="flex-1 py-6">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex items-center gap-4 px-6 py-4 transition-colors relative group",
                  isActive ? "bg-[#E4E3E0] text-[#141414]" : "hover:bg-[#E4E3E0]/5"
                )}
              >
                <item.icon className="w-5 h-5 shrink-0" />
                {isSidebarOpen && <span className="font-medium">{item.name}</span>}
                {!isSidebarOpen && (
                  <div className="absolute left-full ml-2 px-2 py-1 bg-[#141414] text-[#E4E3E0] text-xs rounded opacity-0 group-hover:opacity-100 pointer-events-none z-50 whitespace-nowrap">
                    {item.name}
                  </div>
                )}
              </Link>
            );
          })}
        </nav>

        <div className="p-6 border-t border-[#E4E3E0]/10">
          <button
            onClick={onLogout}
            className={cn(
              "flex items-center gap-4 w-full px-0 py-2 text-[#E4E3E0]/60 hover:text-[#E4E3E0] transition-colors",
              !isSidebarOpen && "justify-center"
            )}
          >
            <LogOut className="w-5 h-5" />
            {isSidebarOpen && <span className="font-medium">Wyloguj</span>}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-20 bg-white border-b border-[#141414] flex items-center justify-between px-8">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 hover:bg-[#141414]/5 rounded-lg transition-colors"
            >
              {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <h1 className="text-sm font-mono uppercase tracking-widest opacity-50">
              {navItems.find(i => i.path === location.pathname)?.name || 'System'}
            </h1>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3 px-4 py-2 bg-[#141414]/5 rounded-full">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
              <span className="text-xs font-mono font-bold uppercase tracking-tighter">
                {user.fullName} ({user.role})
              </span>
            </div>
            <div className="relative" ref={notifRef}>
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className="relative p-2 hover:bg-[#141414]/5 rounded-lg transition-colors"
              >
                <Bell className="w-5 h-5" />
                {notifications.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-600 text-white text-[10px] font-bold flex items-center justify-center rounded-full border-2 border-white">
                    {notifications.length}
                  </span>
                )}
              </button>
              
              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-white border border-[#141414] shadow-2xl z-50">
                  <div className="p-4 border-b border-[#141414] bg-[#141414] text-[#E4E3E0] flex justify-between items-center">
                    <h3 className="text-xs font-bold uppercase tracking-widest">Powiadomienia</h3>
                    <span className="text-[10px] font-mono opacity-50">{notifications.length} nowych</span>
                  </div>
                  <div className="max-h-96 overflow-y-auto">
                    {notifications.length === 0 ? (
                      <div className="p-8 text-center text-xs font-mono uppercase opacity-50">Brak nowych powiadomień</div>
                    ) : (
                      notifications.map((notif, idx) => (
                        <div key={idx} className="p-4 border-b border-[#141414]/10 hover:bg-[#141414]/5 transition-colors cursor-pointer" onClick={() => {
                          setShowNotifications(false);
                          navigate(notif.type === 'incident' ? '/incidents' : '/communication');
                        }}>
                          <div className="flex items-center gap-2 mb-1">
                            {notif.type === 'incident' ? <AlertTriangle className="w-3 h-3 text-red-500" /> : <MessageSquare className="w-3 h-3 text-blue-500" />}
                            <span className="text-[10px] font-bold uppercase tracking-widest">{notif.type === 'incident' ? 'Nowy Incydent' : 'Nowa Wiadomość'}</span>
                          </div>
                          <p className="text-sm font-medium mb-2 line-clamp-2">{notif.title}</p>
                          <div className="flex items-center gap-1 text-[10px] font-mono opacity-50">
                            <Clock className="w-3 h-3" />
                            {new Date(notif.time).toLocaleString()}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 overflow-y-auto p-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Inmates from './pages/Inmates';
import InmateProfile from './pages/InmateProfile';
import Incidents from './pages/Incidents';
import Staff from './pages/Staff';
import Cells from './pages/Cells';
import Visits from './pages/Visits';
import Communication from './pages/Communication';
import Schedule from './pages/Schedule';
import Layout from './components/Layout';
import { User } from './types';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const storedUser = localStorage.getItem('user');
    if (token && storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  const handleLogin = (token: string, userData: User) => {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(userData));
    setUser(userData);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
  };

  if (loading) return <div className="h-screen w-screen flex items-center justify-center bg-zinc-950 text-white">Ładowanie systemu...</div>;

  return (
    <Router>
      <Routes>
        <Route path="/login" element={user ? <Navigate to="/" /> : <Login onLogin={handleLogin} />} />
        
        <Route element={user ? <Layout user={user} onLogout={handleLogout} /> : <Navigate to="/login" />}>
          <Route path="/" element={<Dashboard user={user!} />} />
          <Route path="/inmates" element={<Inmates />} />
          <Route path="/inmates/:id" element={<InmateProfile />} />
          <Route path="/incidents" element={<Incidents />} />
          <Route path="/staff" element={<Staff />} />
          <Route path="/cells" element={<Cells />} />
          <Route path="/visits" element={<Visits />} />
          <Route path="/communication" element={<Communication />} />
          <Route path="/schedule" element={user?.role === 'Admin' ? <Schedule /> : <Navigate to="/" />} />
        </Route>

        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </Router>
  );
}

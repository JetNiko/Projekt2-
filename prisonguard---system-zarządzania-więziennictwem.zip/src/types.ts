export interface User {
  id: number;
  username: string;
  fullName: string;
  role: string;
  permissions: string[];
  badgeNumber?: string;
  department?: string;
  contact?: string;
}

export interface Inmate {
  id: number;
  first_name: string;
  last_name: string;
  inmate_number: string;
  birth_date: string;
  citizenship: string;
  photo_url?: string;
  fingerprint_url?: string;
  sentence_details?: string;
  sentence_duration_months?: number;
  sentence_start_date?: string;
  sentence_end_date?: string;
  crime_type?: string;
  cell_id?: number;
  cell_number?: string;
  ward_name?: string;
  security_level?: string;
}

export interface Incident {
  id: number;
  date: string;
  location: string;
  description: string;
  threat_level: 'low' | 'medium' | 'high' | 'critical';
  category: 'fight' | 'escape' | 'smuggling' | 'regulation_violation' | 'health_hazard';
  reporter_id: number;
  involved_inmates?: string; // JSON string
}

export interface Announcement {
  id: number;
  title: string;
  content: string;
  type: 'general' | 'procedure' | 'warning';
  author_id: number;
  created_at: string;
}

export interface Cell {
  id: number;
  ward_id: number;
  ward_name: string;
  cell_number: string;
  capacity: number;
  current_occupancy: number;
  status: 'active' | 'locked' | 'special';
}

export interface Visit {
  id: number;
  inmate_id: number;
  visitor_name: string;
  relationship: string;
  visit_date: string;
  visit_time: string;
  verification_status: 'pending' | 'approved' | 'rejected';
  notes?: string;
}

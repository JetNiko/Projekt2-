import React, { useState, useEffect } from 'react';
import { Calendar, Plus, User as UserIcon, Clock } from 'lucide-react';

export default function Schedule() {
  const [schedules, setSchedules] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const token = localStorage.getItem('token');
      const [schedRes, usersRes] = await Promise.all([
        fetch('/api/schedules', { headers: { 'Authorization': `Bearer ${token}` } }),
        fetch('/api/users', { headers: { 'Authorization': `Bearer ${token}` } })
      ]);
      setSchedules(await schedRes.json());
      setUsers(await usersRes.json());
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    try {
      const response = await fetch('/api/schedules', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          user_id: formData.get('user_id'),
          shift_start: formData.get('shift_start'),
          shift_end: formData.get('shift_end'),
          type: formData.get('type')
        })
      });

      if (response.ok) {
        setShowForm(false);
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {showForm && (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-6 backdrop-blur-sm">
          <div className="bg-[#E4E3E0] w-full max-w-md p-12 border-t-8 border-[#141414] relative">
            <button onClick={() => setShowForm(false)} className="absolute top-6 right-6 p-2 hover:bg-[#141414]/5 rounded-full transition-colors">
              <Plus className="w-6 h-6 rotate-45" />
            </button>
            <h3 className="text-3xl font-bold tracking-tighter uppercase mb-8">Nowa Zmiana</h3>
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div>
                <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Pracownik</label>
                <select name="user_id" className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" required>
                  <option value="">Wybierz pracownika...</option>
                  {users.map(u => (
                    <option key={u.id} value={u.id}>{u.full_name} ({u.username})</option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Początek Zmiany</label>
                  <input type="datetime-local" name="shift_start" className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" required />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Koniec Zmiany</label>
                  <input type="datetime-local" name="shift_end" className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" required />
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Typ Zmiany</label>
                <select name="type" className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" required>
                  <option value="regular">Regularna</option>
                  <option value="overtime">Nadgodziny</option>
                  <option value="on_call">Dyżur</option>
                </select>
              </div>
              <button type="submit" className="w-full bg-[#141414] text-[#E4E3E0] py-5 font-bold uppercase tracking-widest hover:bg-black transition-all">
                Zapisz Grafik
              </button>
            </form>
          </div>
        </div>
      )}

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-4xl font-bold tracking-tighter uppercase mb-2">Grafik Personelu</h2>
          <p className="text-sm font-mono uppercase tracking-widest opacity-50">Zarządzanie zmianami i czasem pracy</p>
        </div>
        <button 
          onClick={() => setShowForm(true)}
          className="px-6 py-3 bg-[#141414] text-[#E4E3E0] text-xs font-bold uppercase tracking-widest hover:bg-black transition-all flex items-center gap-2"
        >
          <Plus className="w-4 h-4" /> Dodaj Zmianę
        </button>
      </div>

      <div className="bg-white border border-[#141414]">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[#141414] bg-[#141414]/5">
                <th className="p-4 text-[10px] font-mono uppercase tracking-widest opacity-50">Pracownik</th>
                <th className="p-4 text-[10px] font-mono uppercase tracking-widest opacity-50">Początek</th>
                <th className="p-4 text-[10px] font-mono uppercase tracking-widest opacity-50">Koniec</th>
                <th className="p-4 text-[10px] font-mono uppercase tracking-widest opacity-50">Typ</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={4} className="p-8 text-center text-xs font-mono uppercase opacity-50">Ładowanie...</td></tr>
              ) : schedules.length === 0 ? (
                <tr><td colSpan={4} className="p-8 text-center text-xs font-mono uppercase opacity-50 border-t border-dashed border-[#141414]/20">Brak zaplanowanych zmian</td></tr>
              ) : schedules.map((sched) => (
                <tr key={sched.id} className="border-b border-[#141414]/10 hover:bg-[#141414]/5 transition-colors">
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-[#141414]/10 flex items-center justify-center">
                        <UserIcon className="w-4 h-4 opacity-50" />
                      </div>
                      <span className="font-bold uppercase text-xs">{sched.full_name}</span>
                    </div>
                  </td>
                  <td className="p-4 text-xs font-mono uppercase">{new Date(sched.shift_start).toLocaleString()}</td>
                  <td className="p-4 text-xs font-mono uppercase">{new Date(sched.shift_end).toLocaleString()}</td>
                  <td className="p-4">
                    <span className={`px-2 py-1 text-[10px] font-bold uppercase tracking-widest ${
                      sched.type === 'regular' ? 'bg-emerald-100 text-emerald-700' :
                      sched.type === 'overtime' ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'
                    }`}>
                      {sched.type}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

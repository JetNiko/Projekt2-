import React, { useState, useEffect } from 'react';
import { Stethoscope, Search, Filter, FileText, Activity, Pill } from 'lucide-react';

export default function Medical() {
  const [records, setRecords] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // In a real app, this would fetch all medical records (restricted to medical staff)
    // For now, we'll just show a placeholder or fetch if we had an endpoint
    setLoading(false);
  }, []);

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-4xl font-bold tracking-tighter uppercase mb-2">System Medyczny</h2>
          <p className="text-sm font-mono uppercase tracking-widest opacity-50">Dokumentacja medyczna, wizyty lekarskie i farmakoterapia</p>
        </div>
        <div className="flex gap-2">
          <button className="px-6 py-3 bg-blue-600 text-white text-xs font-bold uppercase tracking-widest hover:bg-blue-700 transition-all flex items-center gap-2">
            <PlusIcon className="w-4 h-4" /> Nowa Wizyta Medyczna
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-8 border border-[#141414] flex items-center gap-6">
          <Activity className="w-10 h-10 text-blue-600" />
          <div>
            <div className="text-3xl font-bold tracking-tighter">4</div>
            <div className="text-[10px] font-mono uppercase tracking-widest opacity-50">Dzisiejsze konsultacje</div>
          </div>
        </div>
        <div className="bg-white p-8 border border-[#141414] flex items-center gap-6">
          <Pill className="w-10 h-10 text-amber-600" />
          <div>
            <div className="text-3xl font-bold tracking-tighter">18</div>
            <div className="text-[10px] font-mono uppercase tracking-widest opacity-50">Wydawanie leków</div>
          </div>
        </div>
        <div className="bg-white p-8 border border-[#141414] flex items-center gap-6">
          <FileText className="w-10 h-10 text-[#141414]" />
          <div>
            <div className="text-3xl font-bold tracking-tighter">142</div>
            <div className="text-[10px] font-mono uppercase tracking-widest opacity-50">Aktywne karty pacjenta</div>
          </div>
        </div>
      </div>

      <div className="bg-white border border-[#141414] p-12 text-center space-y-4">
        <Stethoscope className="w-16 h-16 mx-auto opacity-10" />
        <h3 className="text-xl font-bold uppercase tracking-tight">Dostęp Ograniczony</h3>
        <p className="text-sm opacity-50 max-w-md mx-auto">
          Moduł medyczny zawiera wrażliwe dane osobowe i medyczne. 
          Dostęp do pełnej dokumentacji mają wyłącznie lekarze, psycholodzy i uprawniony personel medyczny.
        </p>
        <div className="pt-6">
          <button className="px-8 py-4 bg-[#141414] text-[#E4E3E0] text-xs font-bold uppercase tracking-widest hover:bg-black transition-all">
            Autoryzuj Dostęp Medyczny
          </button>
        </div>
      </div>
    </div>
  );
}

function PlusIcon({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M5 12h14"/><path d="M12 5v14"/></svg>
  );
}

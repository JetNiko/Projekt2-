import React, { useState, useEffect } from 'react';
import { MessageSquare, Bell, Send, User as UserIcon, CheckCircle2 } from 'lucide-react';
import { Announcement } from '../types';

export default function Communication() {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [reports, setReports] = useState<any[]>([]);
  const [messages, setMessages] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [newMessage, setNewMessage] = useState('');
  const [selectedReceiver, setSelectedReceiver] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);

  const currentUser = JSON.parse(localStorage.getItem('user') || '{}');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const token = localStorage.getItem('token');
      const [annRes, msgRes, usersRes, reportsRes] = await Promise.all([
        fetch('/api/stats', { headers: { 'Authorization': `Bearer ${token}` } }),
        fetch('/api/messages', { headers: { 'Authorization': `Bearer ${token}` } }),
        fetch('/api/users', { headers: { 'Authorization': `Bearer ${token}` } }),
        fetch('/api/reports', { headers: { 'Authorization': `Bearer ${token}` } })
      ]);
      const annData = await annRes.json();
      const msgData = await msgRes.json();
      const usersData = await usersRes.json();
      const reportsData = await reportsRes.json();
      setAnnouncements(annData.announcements);
      setMessages(msgData);
      setUsers(usersData.filter((u: any) => u.id !== currentUser.id));
      setReports(reportsData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedReceiver) return;
    try {
      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ receiver_id: selectedReceiver, content: newMessage })
      });
      if (response.ok) {
        setNewMessage('');
        setShowSuccess(true);
        setTimeout(() => setShowSuccess(false), 3000);
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-4xl font-bold tracking-tighter uppercase mb-2">Komunikacja</h2>
          <p className="text-sm font-mono uppercase tracking-widest opacity-50">Wewnętrzny system wymiany informacji i ogłoszeń</p>
        </div>
        <button className="px-6 py-3 bg-[#141414] text-[#E4E3E0] text-xs font-bold uppercase tracking-widest hover:bg-black transition-all flex items-center gap-2">
          <Send className="w-4 h-4" /> Nowa Wiadomość
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Column: Announcements or Reports */}
        <div className="space-y-6">
          {currentUser.role === 'Admin' ? (
            <>
              <div className="flex items-center justify-between border-b border-[#141414] pb-4">
                <h3 className="text-lg font-bold uppercase tracking-tight">Raporty Pracowników</h3>
                <Bell className="w-5 h-5 opacity-30" />
              </div>
              <div className="space-y-4 max-h-[600px] overflow-y-auto">
                {reports.map((rep) => (
                  <div key={rep.id} className="bg-white p-8 border border-[#141414] relative overflow-hidden group">
                    <div className="absolute top-0 left-0 w-1 h-full bg-emerald-600" />
                    <div className="flex justify-between items-start mb-2">
                      <div className="text-[10px] font-mono uppercase tracking-widest opacity-50">
                        {new Date(rep.created_at).toLocaleString()} • {rep.type}
                      </div>
                      <div className="text-[10px] font-bold uppercase tracking-widest">
                        Od: {rep.sender_name}
                      </div>
                    </div>
                    <p className="text-sm opacity-70 leading-relaxed">{rep.content}</p>
                  </div>
                ))}
                {reports.length === 0 && (
                  <div className="p-12 text-center border border-dashed border-[#141414]/20 text-xs font-mono uppercase opacity-50">Brak raportów</div>
                )}
              </div>
            </>
          ) : (
            <>
              <div className="flex items-center justify-between border-b border-[#141414] pb-4">
                <h3 className="text-lg font-bold uppercase tracking-tight">Ogłoszenia Systemowe</h3>
                <Bell className="w-5 h-5 opacity-30" />
              </div>
              <div className="space-y-4 max-h-[600px] overflow-y-auto">
                {announcements.map((ann) => (
                  <div key={ann.id} className="bg-white p-8 border border-[#141414] relative overflow-hidden group">
                    <div className={`absolute top-0 left-0 w-1 h-full ${
                      ann.type === 'warning' ? 'bg-red-600' : 
                      ann.type === 'procedure' ? 'bg-blue-600' : 'bg-[#141414]'
                    }`} />
                    <div className="text-[10px] font-mono uppercase tracking-widest opacity-50 mb-2">
                      {new Date(ann.created_at).toLocaleString()} • {ann.type}
                    </div>
                    <h4 className="text-xl font-bold uppercase tracking-tight mb-4">{ann.title}</h4>
                    <p className="text-sm opacity-70 leading-relaxed">{ann.content}</p>
                  </div>
                ))}
                {announcements.length === 0 && (
                  <div className="p-12 text-center border border-dashed border-[#141414]/20 text-xs font-mono uppercase opacity-50">Brak aktywnych ogłoszeń</div>
                )}
              </div>
            </>
          )}
        </div>

        {/* Internal Messenger */}
        <div className="space-y-6">
          <div className="flex items-center justify-between border-b border-[#141414] pb-4">
            <h3 className="text-lg font-bold uppercase tracking-tight">Wiadomości Służbowe</h3>
            <MessageSquare className="w-5 h-5 opacity-30" />
          </div>
          <div className="bg-white border border-[#141414] h-[600px] flex flex-col">
            <div className="flex-1 overflow-y-auto p-6 space-y-6 flex flex-col-reverse">
              {messages.map((msg) => {
                const isSentByMe = msg.sender_id === currentUser.id;
                return (
                  <div key={msg.id} className={`flex gap-4 ${isSentByMe ? 'flex-row-reverse' : ''}`}>
                    <div className="w-10 h-10 bg-[#141414]/5 border border-[#141414]/10 flex items-center justify-center shrink-0">
                      <UserIcon className="w-5 h-5 opacity-30" />
                    </div>
                    <div className={`flex flex-col ${isSentByMe ? 'items-end' : 'items-start'}`}>
                      <div className="flex items-center gap-3 mb-1">
                        <span className="font-bold text-xs uppercase">{isSentByMe ? 'Ja' : msg.sender_name}</span>
                        <span className="text-[10px] font-mono opacity-50">{new Date(msg.sent_at).toLocaleTimeString()}</span>
                      </div>
                      <div className={`p-4 text-xs leading-relaxed max-w-md ${isSentByMe ? 'bg-[#141414] text-[#E4E3E0]' : 'bg-[#141414]/5'}`}>
                        {msg.content}
                      </div>
                      {isSentByMe && <span className="text-[10px] font-mono opacity-50 mt-1">Wysłano</span>}
                    </div>
                  </div>
                );
              })}
              {messages.length === 0 && (
                <div className="h-full flex items-center justify-center text-xs font-mono uppercase opacity-30">Brak historii wiadomości</div>
              )}
            </div>
            <form onSubmit={handleSendMessage} className="p-4 border-t border-[#141414] space-y-3">
              {showSuccess && (
                <div className="flex items-center gap-2 text-emerald-600 text-xs font-bold uppercase tracking-widest bg-emerald-50 p-2 border border-emerald-200">
                  <CheckCircle2 className="w-4 h-4" /> Wiadomość została wysłana
                </div>
              )}
              <select 
                value={selectedReceiver} 
                onChange={e => setSelectedReceiver(e.target.value)}
                className="w-full bg-white border border-[#141414] px-4 py-3 text-xs font-mono uppercase focus:outline-none"
                required
              >
                <option value="">Wybierz odbiorcę...</option>
                {users.map(u => (
                  <option key={u.id} value={u.id}>{u.full_name} ({u.username})</option>
                ))}
              </select>
              <div className="flex gap-2">
                <input 
                  type="text" 
                  value={newMessage}
                  onChange={e => setNewMessage(e.target.value)}
                  placeholder="WPISZ WIADOMOŚĆ..." 
                  className="flex-1 bg-white border border-[#141414] px-4 py-3 text-xs font-mono uppercase focus:outline-none"
                  required
                />
                <button type="submit" className="bg-[#141414] text-[#E4E3E0] px-6 py-3 hover:bg-black transition-all">
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { Search, Filter, Plus, ChevronRight, User as UserIcon } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Inmate } from '../types';

export default function Inmates() {
  const [inmates, setInmates] = useState<Inmate[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchInmates();
  }, []);

  const fetchInmates = async () => {
    try {
      const response = await fetch('/api/inmates', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await response.json();
      setInmates(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const filteredInmates = inmates.filter(i => 
    `${i.first_name} ${i.last_name} ${i.inmate_number}`.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-4xl font-bold tracking-tighter uppercase mb-2">Kartoteka Osadzonych</h2>
          <p className="text-sm font-mono uppercase tracking-widest opacity-50">Zarządzanie bazą danych osób przebywających w jednostce</p>
        </div>
        <button className="px-6 py-3 bg-[#141414] text-[#E4E3E0] text-xs font-bold uppercase tracking-widest hover:bg-black transition-all flex items-center gap-2">
          <Plus className="w-4 h-4" /> Dodaj Osadzonego
        </button>
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 opacity-30" />
          <input
            type="text"
            placeholder="SZUKAJ PO NAZWISKU LUB NUMERZE ID..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-white border border-[#141414] py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-[#141414]/10 transition-all font-mono text-sm uppercase"
          />
        </div>
        <button className="px-8 py-4 bg-white border border-[#141414] flex items-center gap-3 text-xs font-bold uppercase tracking-widest hover:bg-[#141414]/5 transition-all">
          <Filter className="w-4 h-4" /> Filtry
        </button>
      </div>

      {/* Inmates List */}
      <div className="bg-white border border-[#141414] overflow-hidden">
        <div className="grid grid-cols-12 bg-[#141414] text-[#E4E3E0] p-4 text-[10px] font-mono uppercase tracking-widest">
          <div className="col-span-1">ID</div>
          <div className="col-span-3">Imię i Nazwisko</div>
          <div className="col-span-2">Oddział / Cela</div>
          <div className="col-span-2">Poziom Bezp.</div>
          <div className="col-span-3">Typ Przestępstwa</div>
          <div className="col-span-1 text-right">Akcja</div>
        </div>

        <div className="divide-y divide-[#141414]/10">
          {loading ? (
            <div className="p-12 text-center text-xs font-mono uppercase opacity-50">Pobieranie danych...</div>
          ) : filteredInmates.length === 0 ? (
            <div className="p-12 text-center text-xs font-mono uppercase opacity-50">Nie znaleziono osadzonych spełniających kryteria</div>
          ) : filteredInmates.map((inmate) => (
            <Link 
              key={inmate.id} 
              to={`/inmates/${inmate.id}`}
              className="grid grid-cols-12 p-6 hover:bg-[#141414]/5 transition-colors items-center group"
            >
              <div className="col-span-1 font-mono text-xs font-bold">{inmate.inmate_number}</div>
              <div className="col-span-3 flex items-center gap-3">
                <div className="w-10 h-10 bg-[#141414]/5 flex items-center justify-center border border-[#141414]/10">
                  <UserIcon className="w-5 h-5 opacity-30" />
                </div>
                <span className="font-bold uppercase tracking-tight">{inmate.first_name} {inmate.last_name}</span>
              </div>
              <div className="col-span-2">
                <div className="text-xs font-bold">{inmate.ward_name || 'BRAK'}</div>
                <div className="text-[10px] font-mono uppercase opacity-50">{inmate.cell_number || 'NIEPRZYPISANY'}</div>
              </div>
              <div className="col-span-2">
                <span className={`px-2 py-1 text-[10px] font-mono uppercase tracking-widest border ${
                  inmate.security_level === 'high' ? 'bg-red-50 border-red-200 text-red-700' :
                  inmate.security_level === 'medium' ? 'bg-amber-50 border-amber-200 text-amber-700' :
                  'bg-emerald-50 border-emerald-200 text-emerald-700'
                }`}>
                  {inmate.security_level}
                </span>
              </div>
              <div className="col-span-3 text-xs opacity-70 uppercase tracking-tight">{inmate.crime_type || 'BRAK DANYCH'}</div>
              <div className="col-span-1 text-right">
                <ChevronRight className="w-5 h-5 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

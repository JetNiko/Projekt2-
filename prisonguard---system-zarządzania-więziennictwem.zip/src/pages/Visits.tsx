import React, { useState, useEffect } from 'react';
import { Calendar, User as UserIcon, Clock, Plus, CheckCircle, XCircle } from 'lucide-react';
import { Visit } from '../types';

export default function Visits() {
  const [visits, setVisits] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchVisits();
  }, []);

  const fetchVisits = async () => {
    try {
      const response = await fetch('/api/visits', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await response.json();
      setVisits(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-4xl font-bold tracking-tighter uppercase mb-2">Rejestr Wizyt</h2>
          <p className="text-sm font-mono uppercase tracking-widest opacity-50">Zarządzanie odwiedzinami i weryfikacja gości</p>
        </div>
        <button className="px-6 py-3 bg-[#141414] text-[#E4E3E0] text-xs font-bold uppercase tracking-widest hover:bg-black transition-all">
          Zarejestruj Wizytę
        </button>
      </div>

      <div className="bg-white border border-[#141414] overflow-hidden">
        <div className="grid grid-cols-12 bg-[#141414] text-[#E4E3E0] p-4 text-[10px] font-mono uppercase tracking-widest">
          <div className="col-span-2">Data i Godzina</div>
          <div className="col-span-3">Odwiedzający</div>
          <div className="col-span-3">Osadzony</div>
          <div className="col-span-2">Relacja</div>
          <div className="col-span-2 text-right">Status</div>
        </div>

        <div className="divide-y divide-[#141414]/10">
          {loading ? (
            <div className="p-12 text-center text-xs font-mono uppercase opacity-50">Pobieranie rejestru...</div>
          ) : visits.length === 0 ? (
            <div className="p-12 text-center text-xs font-mono uppercase opacity-50">Brak zaplanowanych wizyt</div>
          ) : visits.map((visit) => (
            <div key={visit.id} className="grid grid-cols-12 p-6 hover:bg-[#141414]/5 transition-colors items-center">
              <div className="col-span-2">
                <div className="text-xs font-bold">{visit.visit_date}</div>
                <div className="text-[10px] font-mono uppercase opacity-50">{visit.visit_time}</div>
              </div>
              <div className="col-span-3 flex items-center gap-3">
                <div className="w-8 h-8 bg-[#141414]/5 flex items-center justify-center border border-[#141414]/10">
                  <UserIcon className="w-4 h-4 opacity-30" />
                </div>
                <span className="font-bold uppercase tracking-tight text-xs">{visit.visitor_name}</span>
              </div>
              <div className="col-span-3">
                <div className="text-xs font-bold uppercase">{visit.first_name} {visit.last_name}</div>
                <div className="text-[10px] font-mono uppercase opacity-50">{visit.inmate_number}</div>
              </div>
              <div className="col-span-2 text-[10px] font-mono uppercase tracking-widest opacity-50">{visit.relationship}</div>
              <div className="col-span-2 text-right">
                <span className={`inline-flex items-center gap-1 px-2 py-1 text-[10px] font-mono uppercase tracking-widest border ${
                  visit.verification_status === 'approved' ? 'bg-emerald-50 border-emerald-200 text-emerald-700' :
                  visit.verification_status === 'rejected' ? 'bg-red-50 border-red-200 text-red-700' :
                  'bg-amber-50 border-amber-200 text-amber-700'
                }`}>
                  {visit.verification_status === 'approved' && <CheckCircle className="w-3 h-3" />}
                  {visit.verification_status === 'rejected' && <XCircle className="w-3 h-3" />}
                  {visit.verification_status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { Grid, Shield, Users, Lock, Unlock, AlertCircle, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Cell, Inmate } from '../types';

export default function Cells() {
  const [cells, setCells] = useState<Cell[]>([]);
  const [inmates, setInmates] = useState<Inmate[]>([]);
  const [selectedCell, setSelectedCell] = useState<Cell | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const headers = { 'Authorization': `Bearer ${localStorage.getItem('token')}` };
      const [cellsRes, inmatesRes] = await Promise.all([
        fetch('/api/cells', { headers }),
        fetch('/api/inmates', { headers })
      ]);
      setCells(await cellsRes.json());
      setInmates(await inmatesRes.json());
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const wards = Array.from(new Set(cells.map(c => c.ward_name)));

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {selectedCell && (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-6 backdrop-blur-sm">
          <div className="bg-[#E4E3E0] w-full max-w-2xl p-8 border-t-8 border-[#141414] relative">
            <button onClick={() => setSelectedCell(null)} className="absolute top-6 right-6 p-2 hover:bg-[#141414]/5 rounded-full transition-colors">
              <X className="w-6 h-6" />
            </button>
            <h3 className="text-2xl font-bold tracking-tighter uppercase mb-6">Cela {selectedCell.cell_number} - Osadzeni</h3>
            <div className="space-y-2 max-h-[60vh] overflow-y-auto">
              {inmates.filter(i => i.cell_id === selectedCell.id).map(inmate => (
                <div key={inmate.id} className="bg-white p-4 border border-[#141414] flex justify-between items-center">
                  <div>
                    <div className="font-bold uppercase">{inmate.first_name} {inmate.last_name}</div>
                    <div className="text-[10px] font-mono opacity-50">{inmate.inmate_number}</div>
                  </div>
                  <Link to={`/inmates/${inmate.id}`} className="px-4 py-2 bg-[#141414] text-[#E4E3E0] text-[10px] font-bold uppercase tracking-widest hover:bg-black">
                    Profil
                  </Link>
                </div>
              ))}
              {inmates.filter(i => i.cell_id === selectedCell.id).length === 0 && (
                <div className="p-8 text-center text-xs font-mono uppercase opacity-50 border border-dashed border-[#141414]/20">Cela jest pusta</div>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-4xl font-bold tracking-tighter uppercase mb-2">Cele i Oddziały</h2>
          <p className="text-sm font-mono uppercase tracking-widest opacity-50">Zarządzanie przestrzenią i obłożeniem jednostki</p>
        </div>
        <div className="flex gap-2">
          <button className="px-6 py-3 bg-[#141414] text-[#E4E3E0] text-xs font-bold uppercase tracking-widest hover:bg-black transition-all">
            Blokada Wszystkich Cel
          </button>
        </div>
      </div>

      {wards.map(wardName => (
        <div key={wardName} className="space-y-6">
          <div className="flex items-center gap-4 border-b border-[#141414] pb-4">
            <Shield className="w-6 h-6" />
            <h3 className="text-2xl font-bold uppercase tracking-tighter">{wardName}</h3>
            <span className="text-[10px] font-mono uppercase tracking-widest opacity-50">
              {cells.filter(c => c.ward_name === wardName).length} Cel • {
                cells.filter(c => c.ward_name === wardName).reduce((acc, c) => acc + c.current_occupancy, 0)
              } Osadzonych
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {cells.filter(c => c.ward_name === wardName).map(cell => (
              <div 
                key={cell.id}
                onClick={() => setSelectedCell(cell)}
                className={`bg-white border border-[#141414] p-6 relative group transition-all cursor-pointer ${
                  cell.status === 'locked' ? 'bg-red-50 border-red-600' : 
                  cell.status === 'special' ? 'bg-amber-50 border-amber-600' : 'hover:bg-[#141414] hover:text-[#E4E3E0]'
                }`}
              >
                <div className="flex justify-between items-start mb-6">
                  <div className="text-2xl font-bold tracking-tighter">{cell.cell_number}</div>
                  {cell.status === 'locked' ? <Lock className="w-4 h-4 text-red-600" /> : <Unlock className="w-4 h-4 opacity-30" />}
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-end">
                    <div className="text-[10px] font-mono uppercase tracking-widest opacity-50 group-hover:opacity-70">Obłożenie</div>
                    <div className="font-bold text-lg">{cell.current_occupancy} / {cell.capacity}</div>
                  </div>
                  
                  {/* Capacity Bar */}
                  <div className="h-1 bg-[#141414]/10 group-hover:bg-[#E4E3E0]/20">
                    <div 
                      className={`h-full ${cell.current_occupancy >= cell.capacity ? 'bg-red-600' : 'bg-[#141414] group-hover:bg-[#E4E3E0]'}`}
                      style={{ width: `${(cell.current_occupancy / cell.capacity) * 100}%` }}
                    />
                  </div>

                  <div className="flex justify-between items-center pt-2">
                    <span className="text-[10px] font-mono uppercase tracking-widest opacity-50 group-hover:opacity-70">Status</span>
                    <span className="text-[10px] font-mono font-bold uppercase tracking-widest">{cell.status}</span>
                  </div>
                </div>

                {cell.current_occupancy >= cell.capacity && (
                  <div className="absolute top-2 right-2">
                    <AlertCircle className="w-3 h-3 text-red-600" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}

      {loading && <div className="p-12 text-center text-xs font-mono uppercase opacity-50">Pobieranie danych infrastruktury...</div>}
    </div>
  );
}

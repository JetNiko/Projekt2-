import React, { useState, useEffect } from 'react';
import { AlertTriangle, Plus, Search, Filter, ShieldAlert } from 'lucide-react';
import { Incident } from '../types';

export default function Incidents() {
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    fetchIncidents();
  }, []);

  const fetchIncidents = async () => {
    try {
      const response = await fetch('/api/incidents', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await response.json();
      setIncidents(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    try {
      const response = await fetch('/api/incidents', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          location: formData.get('location'),
          category: formData.get('category'),
          threat_level: formData.get('threat'),
          description: formData.get('description'),
          involved_inmates: []
        })
      });

      if (response.ok) {
        setShowForm(false);
        fetchIncidents();
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {showForm && (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-6 backdrop-blur-sm">
          <div className="bg-[#E4E3E0] w-full max-w-2xl p-12 border-t-8 border-red-600 relative">
            <button onClick={() => setShowForm(false)} className="absolute top-6 right-6 p-2 hover:bg-[#141414]/5 rounded-full transition-colors">
              <Plus className="w-6 h-6 rotate-45" />
            </button>
            <h3 className="text-3xl font-bold tracking-tighter uppercase mb-8">Zgłoszenie Incydentu</h3>
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Lokalizacja</label>
                  <input name="location" type="text" className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" placeholder="NP. ODDZIAŁ A, CELA 12" required />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Kategoria</label>
                  <select name="category" className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none">
                    <option value="BÓJKA">BÓJKA</option>
                    <option value="PRÓBA UCIECZKI">PRÓBA UCIECZKI</option>
                    <option value="PRZEMYT">PRZEMYT</option>
                    <option value="NARUSZENIE REGULAMINU">NARUSZENIE REGULAMINU</option>
                    <option value="ZAGROŻENIE ZDROWIA">ZAGROŻENIE ZDROWIA</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Poziom Zagrożenia</label>
                <div className="flex gap-4">
                  {['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'].map(level => (
                    <label key={level} className="flex-1">
                      <input type="radio" name="threat" value={level} className="hidden peer" defaultChecked={level === 'LOW'} />
                      <div className="p-4 border border-[#141414] text-center text-[10px] font-mono uppercase tracking-widest cursor-pointer peer-checked:bg-[#141414] peer-checked:text-[#E4E3E0] transition-all">
                        {level}
                      </div>
                    </label>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Opis Zdarzenia</label>
                <textarea name="description" className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none h-32" placeholder="OPISZ PRZEBIEG ZDARZENIA..." required></textarea>
              </div>
              <button type="submit" className="w-full bg-red-600 text-white py-5 font-bold uppercase tracking-widest hover:bg-red-700 transition-all">
                WYŚLIJ RAPORT DO CENTRUM DOWODZENIA
              </button>
            </form>
          </div>
        </div>
      )}

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-4xl font-bold tracking-tighter uppercase mb-2">Centrum Incydentów</h2>
          <p className="text-sm font-mono uppercase tracking-widest opacity-50">Monitorowanie i raportowanie zdarzeń nadzwyczajnych</p>
        </div>
        <button 
          onClick={() => setShowForm(true)}
          className="px-6 py-3 bg-red-600 text-white text-xs font-bold uppercase tracking-widest hover:bg-red-700 transition-all flex items-center gap-2"
        >
          <ShieldAlert className="w-4 h-4" /> Zgłoś Nowy Incydent
        </button>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-8 border border-[#141414]">
          <div className="text-4xl font-bold tracking-tighter mb-2">12</div>
          <div className="text-[10px] font-mono uppercase tracking-widest opacity-50">Zdarzenia w tym miesiącu</div>
        </div>
        <div className="bg-white p-8 border border-[#141414]">
          <div className="text-4xl font-bold tracking-tighter mb-2 text-red-600">2</div>
          <div className="text-[10px] font-mono uppercase tracking-widest opacity-50">Aktywne zagrożenia krytyczne</div>
        </div>
        <div className="bg-white p-8 border border-[#141414]">
          <div className="text-4xl font-bold tracking-tighter mb-2 text-amber-600">84%</div>
          <div className="text-[10px] font-mono uppercase tracking-widest opacity-50">Wskaźnik bezpieczeństwa</div>
        </div>
      </div>

      {/* Incident List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-[#141414] pb-4">
          <h3 className="text-lg font-bold uppercase tracking-tight">Rejestr Zdarzeń</h3>
          <div className="flex gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3 h-3 opacity-30" />
              <input type="text" placeholder="SZUKAJ..." className="bg-white border border-[#141414] py-2 pl-8 pr-4 text-[10px] font-mono uppercase focus:outline-none" />
            </div>
            <button className="p-2 border border-[#141414] hover:bg-[#141414]/5 transition-colors"><Filter className="w-4 h-4" /></button>
          </div>
        </div>

        <div className="space-y-4">
          {loading ? (
            <div className="p-12 text-center text-xs font-mono uppercase opacity-50">Pobieranie rejestru...</div>
          ) : incidents.length === 0 ? (
            <div className="p-12 text-center border border-dashed border-[#141414]/20 text-xs font-mono uppercase opacity-50">Brak zarejestrowanych incydentów</div>
          ) : incidents.map((incident) => (
            <div key={incident.id} className="bg-white border border-[#141414] overflow-hidden group hover:border-red-600 transition-colors">
              <div className="flex flex-col md:flex-row">
                <div className={`md:w-48 p-6 flex flex-col items-center justify-center border-b md:border-b-0 md:border-r border-[#141414] ${
                  incident.threat_level === 'critical' ? 'bg-red-600 text-white' : 
                  incident.threat_level === 'high' ? 'bg-orange-500 text-white' : 'bg-[#141414]/5'
                }`}>
                  <AlertTriangle className="w-8 h-8 mb-2" />
                  <span className="text-[10px] font-mono font-bold uppercase tracking-widest">{incident.threat_level}</span>
                </div>
                <div className="flex-1 p-8">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h4 className="text-xl font-bold uppercase tracking-tight mb-1">{incident.category.replace('_', ' ')}</h4>
                      <p className="text-[10px] font-mono uppercase tracking-widest opacity-50">{incident.location} • {new Date(incident.date).toLocaleString()}</p>
                    </div>
                    <span className="px-3 py-1 bg-[#141414] text-[#E4E3E0] text-[10px] font-mono uppercase tracking-widest">ID: {incident.id}</span>
                  </div>
                  <p className="text-sm opacity-70 leading-relaxed mb-6">{incident.description}</p>
                  <div className="flex items-center gap-4 pt-4 border-t border-[#141414]/10">
                    <div className="text-[10px] font-mono uppercase tracking-widest opacity-50">Zgłaszający: ID-{incident.reporter_id}</div>
                    <div className="text-[10px] font-mono uppercase tracking-widest opacity-50">Status: Zamknięty</div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

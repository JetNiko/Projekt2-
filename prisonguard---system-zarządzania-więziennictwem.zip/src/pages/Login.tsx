import React, { useState } from 'react';
import { Shield, Lock, User as UserIcon, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface LoginProps {
  onLogin: (token: string, user: any) => void;
}

export default function Login({ onLogin }: LoginProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });

      if (response.ok) {
        const data = await response.json();
        onLogin(data.token, data.user);
      } else {
        setError('Nieprawidłowy login lub hasło');
      }
    } catch (err) {
      setError('Błąd połączenia z serwerem');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#141414] flex items-center justify-center p-6 font-sans">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="bg-[#E4E3E0] p-12 shadow-2xl relative overflow-hidden">
          {/* Decorative elements */}
          <div className="absolute top-0 left-0 w-full h-1 bg-[#141414]" />
          <div className="absolute bottom-0 left-0 w-full h-1 bg-[#141414]" />
          
          <div className="flex flex-col items-center mb-12">
            <div className="w-16 h-16 bg-[#141414] flex items-center justify-center mb-6">
              <Shield className="w-10 h-10 text-[#E4E3E0]" />
            </div>
            <h1 className="text-3xl font-bold tracking-tighter text-[#141414] uppercase">PRISONGUARD</h1>
            <p className="text-xs font-mono uppercase tracking-widest mt-2 opacity-50">System Zarządzania Więziennictwem</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Identyfikator Pracownika</label>
              <div className="relative">
                <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 opacity-30" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-white border border-[#141414] py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-[#141414]/10 transition-all font-mono text-sm"
                  placeholder="LOGIN"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Hasło Dostępowe</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 opacity-30" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-white border border-[#141414] py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-[#141414]/10 transition-all font-mono text-sm"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            {error && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center gap-2 text-red-600 bg-red-50 p-3 border border-red-200 text-xs font-mono"
              >
                <AlertCircle className="w-4 h-4" />
                <span>{error}</span>
              </motion.div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-[#141414] text-[#E4E3E0] py-5 font-bold uppercase tracking-widest hover:bg-black transition-all disabled:opacity-50 flex items-center justify-center gap-3 group"
            >
              {isLoading ? 'AUTORYZACJA...' : 'ZALOGUJ DO SYSTEMU'}
              {!isLoading && <Shield className="w-4 h-4 group-hover:scale-110 transition-transform" />}
            </button>
          </form>

          <div className="mt-12 pt-8 border-t border-[#141414]/10 text-center">
            <p className="text-[10px] font-mono uppercase tracking-widest opacity-30">
              Dostęp wyłącznie dla upoważnionego personelu.<br />
              Wszystkie próby nieautoryzowanego dostępu są logowane.
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

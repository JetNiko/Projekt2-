import React, { useState, useEffect } from 'react';
import { UserCog, Shield, BadgeCheck, Mail, Phone, Search, X, Clock, Edit2 } from 'lucide-react';

export default function Staff() {
  const [staff, setStaff] = useState<any[]>([]);
  const [roles, setRoles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedStaff, setSelectedStaff] = useState<any>(null);
  
  // Create form state
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    full_name: '',
    role_id: '',
    badge_number: '',
    department: ''
  });

  const [editFormData, setEditFormData] = useState({
    username: '',
    password: '',
    full_name: '',
    role_id: '',
    badge_number: '',
    department: ''
  });

  const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
  const isAdmin = currentUser.role === 'Admin';

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const headers = { 'Authorization': `Bearer ${localStorage.getItem('token')}` };
      const [staffRes, rolesRes] = await Promise.all([
        fetch('/api/staff', { headers }),
        fetch('/api/roles', { headers })
      ]);
      setStaff(await staffRes.json());
      setRoles(await rolesRes.json());
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/staff', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(formData)
      });
      if (response.ok) {
        setShowCreateModal(false);
        fetchData();
      } else {
        alert('Błąd podczas tworzenia pracownika');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const openProfile = async (id: number) => {
    try {
      const response = await fetch(`/api/staff/${id}`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await response.json();
      setSelectedStaff(data);
    } catch (err) {
      console.error(err);
    }
  };

  const openEditModal = () => {
    if (!selectedStaff) return;
    setEditFormData({
      username: selectedStaff.username || '',
      password: '',
      full_name: selectedStaff.full_name || '',
      role_id: selectedStaff.role_id || '',
      badge_number: selectedStaff.badge_number || '',
      department: selectedStaff.department || ''
    });
    setShowEditModal(true);
  };

  const handleEditStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStaff) return;
    try {
      const response = await fetch(`/api/staff/${selectedStaff.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(editFormData)
      });
      if (response.ok) {
        setShowEditModal(false);
        fetchData();
        openProfile(selectedStaff.id); // Refresh profile data
      } else {
        const data = await response.json();
        alert(data.message || 'Błąd podczas edycji pracownika');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteStaff = async () => {
    if (!selectedStaff) return;
    if (!window.confirm('Czy na pewno chcesz usunąć profil tego pracownika? Tej operacji nie można cofnąć.')) return;
    try {
      const response = await fetch(`/api/staff/${selectedStaff.id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      if (response.ok) {
        setSelectedStaff(null);
        fetchData();
      } else {
        const data = await response.json();
        alert(data.message || 'Błąd podczas usuwania pracownika');
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Create Modal */}
      {showCreateModal && isAdmin && (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-6 backdrop-blur-sm">
          <div className="bg-[#E4E3E0] w-full max-w-2xl p-12 border-t-8 border-[#141414] relative">
            <button onClick={() => setShowCreateModal(false)} className="absolute top-6 right-6 p-2 hover:bg-[#141414]/5 rounded-full transition-colors">
              <X className="w-6 h-6" />
            </button>
            <h3 className="text-3xl font-bold tracking-tighter uppercase mb-8">Nowy Pracownik</h3>
            <form className="space-y-6" onSubmit={handleCreateStaff}>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Imię i Nazwisko</label>
                  <input type="text" value={formData.full_name} onChange={e => setFormData({...formData, full_name: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" required />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Nazwa Użytkownika (Login)</label>
                  <input type="text" value={formData.username} onChange={e => setFormData({...formData, username: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" required />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Hasło</label>
                  <input type="password" value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" required />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Rola</label>
                  <select value={formData.role_id} onChange={e => setFormData({...formData, role_id: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" required>
                    <option value="">Wybierz rolę...</option>
                    {roles.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Numer Odznaki</label>
                  <input type="text" value={formData.badge_number} onChange={e => setFormData({...formData, badge_number: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Wydział</label>
                  <input type="text" value={formData.department} onChange={e => setFormData({...formData, department: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" />
                </div>
              </div>
              <button type="submit" className="w-full bg-[#141414] text-[#E4E3E0] py-5 font-bold uppercase tracking-widest hover:bg-black transition-all">
                UTWÓRZ PROFIL
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {showEditModal && isAdmin && selectedStaff && (
        <div className="fixed inset-0 bg-black/80 z-[110] flex items-center justify-center p-6 backdrop-blur-sm">
          <div className="bg-[#E4E3E0] w-full max-w-2xl p-12 border-t-8 border-[#141414] relative">
            <button onClick={() => setShowEditModal(false)} className="absolute top-6 right-6 p-2 hover:bg-[#141414]/5 rounded-full transition-colors">
              <X className="w-6 h-6" />
            </button>
            <h3 className="text-3xl font-bold tracking-tighter uppercase mb-8">Edytuj Pracownika</h3>
            <form className="space-y-6" onSubmit={handleEditStaff}>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Imię i Nazwisko</label>
                  <input type="text" value={editFormData.full_name} onChange={e => setEditFormData({...editFormData, full_name: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" required />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Nazwa Użytkownika (Login)</label>
                  <input type="text" value={editFormData.username} onChange={e => setEditFormData({...editFormData, username: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" required />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Hasło (zostaw puste aby nie zmieniać)</label>
                  <input type="password" value={editFormData.password} onChange={e => setEditFormData({...editFormData, password: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Rola</label>
                  <select value={editFormData.role_id} onChange={e => setEditFormData({...editFormData, role_id: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" required>
                    <option value="">Wybierz rolę...</option>
                    {roles.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Numer Odznaki</label>
                  <input type="text" value={editFormData.badge_number} onChange={e => setEditFormData({...editFormData, badge_number: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest mb-2 opacity-50">Wydział</label>
                  <input type="text" value={editFormData.department} onChange={e => setEditFormData({...editFormData, department: e.target.value})} className="w-full bg-white border border-[#141414] p-4 text-xs font-mono uppercase focus:outline-none" />
                </div>
              </div>
              <button type="submit" className="w-full bg-[#141414] text-[#E4E3E0] py-5 font-bold uppercase tracking-widest hover:bg-black transition-all">
                ZAPISZ ZMIANY
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Profile Modal */}
      {selectedStaff && (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-6 backdrop-blur-sm">
          <div className="bg-[#E4E3E0] w-full max-w-3xl p-8 border-t-8 border-[#141414] relative max-h-[90vh] flex flex-col">
            <button onClick={() => setSelectedStaff(null)} className="absolute top-6 right-6 p-2 hover:bg-[#141414]/5 rounded-full transition-colors">
              <X className="w-6 h-6" />
            </button>
            <div className="flex items-center gap-6 mb-8">
              <div className="w-20 h-20 bg-[#141414] flex items-center justify-center text-[#E4E3E0]">
                <Shield className="w-10 h-10" />
              </div>
              <div className="flex-1">
                <h3 className="text-3xl font-bold tracking-tighter uppercase">{selectedStaff.full_name}</h3>
                <p className="text-xs font-mono uppercase tracking-widest opacity-50">{selectedStaff.role} • {selectedStaff.badge_number}</p>
              </div>
              <div className="text-right border-l border-[#141414]/20 pl-6">
                <div className="text-[10px] font-mono uppercase tracking-widest opacity-50">Suma Godzin Pracy</div>
                <div className="text-2xl font-bold font-mono">{selectedStaff.totalWorkHours || 0}h</div>
              </div>
            </div>
            
            {isAdmin && (
              <div className="flex gap-4 mb-8">
                <button onClick={openEditModal} className="flex-1 py-3 bg-[#141414] text-[#E4E3E0] text-[10px] font-bold uppercase tracking-widest hover:bg-black transition-all flex items-center justify-center gap-2">
                  <Edit2 className="w-4 h-4" /> Edytuj Profil
                </button>
                <button onClick={handleDeleteStaff} className="flex-1 py-3 bg-red-600 text-white text-[10px] font-bold uppercase tracking-widest hover:bg-red-700 transition-all flex items-center justify-center gap-2">
                  <X className="w-4 h-4" /> Usuń Profil
                </button>
              </div>
            )}
            
            <h4 className="text-lg font-bold uppercase tracking-tight mb-4">Logi Aktywności</h4>
            <div className="flex-1 overflow-y-auto bg-white border border-[#141414] p-4 space-y-2">
              {selectedStaff.logs?.map((log: any) => (
                <div key={log.id} className="flex gap-4 items-start p-3 border-b border-[#141414]/10 last:border-0">
                  <Clock className="w-4 h-4 opacity-30 shrink-0 mt-0.5" />
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <span className="font-bold text-xs uppercase">{log.action}</span>
                      <span className="text-[10px] font-mono opacity-50">{new Date(log.timestamp).toLocaleString()}</span>
                    </div>
                    <div className="text-xs opacity-70">{log.details}</div>
                  </div>
                </div>
              ))}
              {(!selectedStaff.logs || selectedStaff.logs.length === 0) && (
                <div className="text-center text-xs font-mono uppercase opacity-50 py-8">Brak logów aktywności</div>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-4xl font-bold tracking-tighter uppercase mb-2">Zarządzanie Personelem</h2>
          <p className="text-sm font-mono uppercase tracking-widest opacity-50">Ewidencja pracowników i harmonogramy służb</p>
        </div>
        {isAdmin && (
          <button onClick={() => setShowCreateModal(true)} className="px-6 py-3 bg-[#141414] text-[#E4E3E0] text-xs font-bold uppercase tracking-widest hover:bg-black transition-all">
            Dodaj Pracownika
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full p-12 text-center text-xs font-mono uppercase opacity-50">Pobieranie listy personelu...</div>
        ) : staff.map((member) => (
          <div key={member.id} className="bg-white border border-[#141414] p-8 space-y-6 group hover:bg-[#141414] hover:text-[#E4E3E0] transition-all duration-300">
            <div className="flex justify-between items-start">
              <div className="w-16 h-16 bg-[#141414]/5 border border-[#141414] group-hover:border-[#E4E3E0]/20 flex items-center justify-center">
                <Shield className="w-8 h-8 opacity-30 group-hover:opacity-100 transition-opacity" />
              </div>
              <div className="text-right">
                <div className="text-[10px] font-mono uppercase tracking-widest opacity-50 group-hover:opacity-70">Nr Służbowy</div>
                <div className="font-bold font-mono">{member.badge_number || 'N/A'}</div>
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-bold uppercase tracking-tighter mb-1">{member.full_name}</h3>
              <div className="flex items-center gap-2 text-[10px] font-mono uppercase tracking-widest opacity-50 group-hover:opacity-70">
                <BadgeCheck className="w-3 h-3" />
                {member.role} • {member.department || 'OGÓLNY'}
              </div>
            </div>

            <div className="pt-6 border-t border-[#141414]/10 group-hover:border-[#E4E3E0]/10 space-y-3">
              <div className="flex items-center gap-3 text-xs opacity-70">
                <Mail className="w-4 h-4" />
                <span>{member.username}@prison.gov.pl</span>
              </div>
              <div className="flex items-center gap-3 text-xs opacity-70">
                <Phone className="w-4 h-4" />
                <span>+48 000 000 000</span>
              </div>
            </div>

            <button onClick={() => openProfile(member.id)} className="w-full py-3 border border-[#141414] group-hover:border-[#E4E3E0] text-[10px] font-bold uppercase tracking-widest hover:bg-[#E4E3E0] hover:text-[#141414] transition-all">
              Zobacz Profil
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

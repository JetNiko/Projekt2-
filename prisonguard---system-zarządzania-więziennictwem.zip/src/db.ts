import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';

const dbPath = path.resolve('prison.db');
const db = new Database(dbPath);

// Initialize schema
db.exec(`
  CREATE TABLE IF NOT EXISTS roles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    permissions TEXT NOT NULL -- JSON string
  );

  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role_id INTEGER,
    badge_number TEXT UNIQUE,
    department TEXT,
    contact TEXT,
    last_login DATETIME,
    FOREIGN KEY (role_id) REFERENCES roles(id)
  );

  CREATE TABLE IF NOT EXISTS wards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    security_level TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS cells (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ward_id INTEGER,
    cell_number TEXT NOT NULL,
    capacity INTEGER NOT NULL,
    status TEXT DEFAULT 'active', -- active, locked, special
    FOREIGN KEY (ward_id) REFERENCES wards(id)
  );

  CREATE TABLE IF NOT EXISTS inmates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    inmate_number TEXT NOT NULL UNIQUE,
    birth_date DATE NOT NULL,
    citizenship TEXT NOT NULL,
    photo_url TEXT,
    fingerprint_url TEXT,
    sentence_details TEXT,
    sentence_duration_months INTEGER,
    sentence_start_date DATE,
    sentence_end_date DATE,
    crime_type TEXT,
    cell_id INTEGER,
    security_level TEXT,
    FOREIGN KEY (cell_id) REFERENCES cells(id)
  );

  CREATE TABLE IF NOT EXISTS behavior_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    inmate_id INTEGER,
    type TEXT NOT NULL, -- reward, punishment, report, incident
    description TEXT NOT NULL,
    reporter_id INTEGER,
    date DATETIME DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'pending',
    FOREIGN KEY (inmate_id) REFERENCES inmates(id),
    FOREIGN KEY (reporter_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS incidents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date DATETIME NOT NULL,
    location TEXT NOT NULL,
    description TEXT NOT NULL,
    threat_level TEXT NOT NULL, -- low, medium, high, critical
    category TEXT NOT NULL, -- fight, escape, smuggling, regulation_violation, health_hazard
    reporter_id INTEGER,
    involved_inmates TEXT, -- JSON array of IDs
    FOREIGN KEY (reporter_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    shift_start DATETIME NOT NULL,
    shift_end DATETIME NOT NULL,
    type TEXT NOT NULL, -- regular, overtime, on_call
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS announcements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    type TEXT NOT NULL, -- general, procedure, warning
    author_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id INTEGER,
    type TEXT NOT NULL, -- daily, incident
    content TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id INTEGER,
    receiver_id INTEGER,
    content TEXT NOT NULL,
    sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    read_at DATETIME,
    FOREIGN KEY (sender_id) REFERENCES users(id),
    FOREIGN KEY (receiver_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS visits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    inmate_id INTEGER,
    visitor_name TEXT NOT NULL,
    relationship TEXT NOT NULL,
    visit_date DATE NOT NULL,
    visit_time TIME NOT NULL,
    verification_status TEXT DEFAULT 'pending',
    notes TEXT,
    FOREIGN KEY (inmate_id) REFERENCES inmates(id)
  );

  CREATE TABLE IF NOT EXISTS medical_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    inmate_id INTEGER,
    diagnosis TEXT NOT NULL,
    treatment TEXT,
    prescriptions TEXT,
    hospitalizations TEXT,
    doctor_id INTEGER,
    date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (inmate_id) REFERENCES inmates(id),
    FOREIGN KEY (doctor_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    action TEXT NOT NULL,
    details TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
`);

try {
  db.prepare('ALTER TABLE inmates ADD COLUMN fingerprint_url TEXT').run();
} catch (e) {
  // Column might already exist
}
try {
  db.prepare('ALTER TABLE inmates ADD COLUMN height INTEGER').run();
  db.prepare('ALTER TABLE inmates ADD COLUMN weight INTEGER').run();
  db.prepare('ALTER TABLE inmates ADD COLUMN eye_color TEXT').run();
} catch (e) {
  // Columns might already exist
}

// Seed initial data if empty
const roleCount = db.prepare('SELECT COUNT(*) as count FROM roles').get() as { count: number };
const inmateCount = db.prepare('SELECT COUNT(*) as count FROM inmates').get() as { count: number };

if (roleCount.count === 0) {
  const roles = [
    { name: 'Admin', permissions: JSON.stringify(['all']) },
    { name: 'Director', permissions: JSON.stringify(['reports', 'staff_manage', 'decisions']) },
    { name: 'Guard', permissions: JSON.stringify(['inmates_view', 'incidents_report', 'duty_reports']) },
    { name: 'Medical', permissions: JSON.stringify(['medical_access', 'inmates_view']) },
    { name: 'Administrative', permissions: JSON.stringify(['docs_manage', 'schedules']) }
  ];
  const insertRole = db.prepare('INSERT INTO roles (name, permissions) VALUES (?, ?)');
  roles.forEach(r => insertRole.run(r.name, r.permissions));

  // Seed Wards
  const wards = [
    { name: 'Oddział A', security_level: 'low' },
    { name: 'Oddział B', security_level: 'medium' },
    { name: 'Oddział C', security_level: 'high' }
  ];
  const insertWard = db.prepare('INSERT INTO wards (name, security_level) VALUES (?, ?)');
  wards.forEach(w => insertWard.run(w.name, w.security_level));

  // Seed Cells
  const insertCell = db.prepare('INSERT INTO cells (ward_id, cell_number, capacity) VALUES (?, ?, ?)');
  for (let i = 1; i <= 3; i++) {
    for (let j = 1; j <= 5; j++) {
      insertCell.run(i, `${String.fromCharCode(64 + i)}-${j}`, 4);
    }
  }
}

if (inmateCount.count < 10) {
  const insertInmate = db.prepare(`
    INSERT OR IGNORE INTO inmates (first_name, last_name, inmate_number, birth_date, citizenship, cell_id, security_level, crime_type, height, weight, eye_color)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  insertInmate.run('Jan', 'Kowalski', 'INM-1001', '1985-05-12', 'Polska', 1, 'low', 'Kradzież', 180, 85, 'Niebieskie');
  insertInmate.run('Adam', 'Nowak', 'INM-1002', '1990-11-23', 'Polska', 1, 'low', 'Oszustwo', 175, 78, 'Brązowe');
  insertInmate.run('Marek', 'Zieliński', 'INM-1003', '1978-02-15', 'Polska', 6, 'medium', 'Rozbój', 182, 90, 'Szare');
  insertInmate.run('Piotr', 'Wiśniewski', 'INM-1004', '1992-08-30', 'Polska', 2, 'low', 'Kradzież', 170, 65, 'Zielone');
  insertInmate.run('Tomasz', 'Wójcik', 'INM-1005', '1983-12-05', 'Polska', 2, 'medium', 'Pobicie', 188, 95, 'Brązowe');
  insertInmate.run('Krzysztof', 'Kowalczyk', 'INM-1006', '1975-04-18', 'Polska', 3, 'high', 'Morderstwo', 190, 100, 'Niebieskie');
  insertInmate.run('Michał', 'Kamiński', 'INM-1007', '1995-07-22', 'Polska', 7, 'low', 'Oszustwo podatkowe', 178, 80, 'Szare');
  insertInmate.run('Andrzej', 'Lewandowski', 'INM-1008', '1988-09-14', 'Polska', 8, 'medium', 'Rozbój', 185, 88, 'Brązowe');
  insertInmate.run('Marcin', 'Zieliński', 'INM-1009', '1991-01-03', 'Polska', 12, 'high', 'Przemyt', 172, 70, 'Zielone');
  insertInmate.run('Jakub', 'Szymański', 'INM-1010', '1980-11-30', 'Polska', 13, 'medium', 'Kradzież z włamaniem', 181, 82, 'Niebieskie');
}

export default db;
